# Semantic Reflex Runtime｜架构书 v0.6：需求发现与验收隔离

**2026-09-18｜Draft｜仍为单类只读搜索 ADMIT＋原文 recall。**

这一轮停止调恢复微格式，增加可执行的相同观察反例，区分候选内延后、候选覆盖缺口、Required Reads 与无关变化。没有实际模型或外部宿主调用，不宣称解决需求发现。

| 入口 | 内容 |
|---|---|
| [当前设计快照](CURRENT.md) | 范围、证据与未决 |
| [整册](BOOK.md) | 总书、模块、实验、附录和历史 |
| [第六轮 bull／bear](docs/research/2026-09-18-offline-bull-bear-round-6.md) | 八个争点、推荐裁定与推翻条件 |
| [E3 需求诊断](docs/experiments/E3-discovery-counterexamples.md) | 相同观察的限定、反例设计与自然实验缺口 |
| [完整诊断记录](lab/discovery/diagnostics/REPORT.md) | 13 对的全部控制，不只列不利或有利样本 |
| [反例实验室](lab/discovery/README.md) | 代码、投影、来源与显式预期 |
| [交接](docs/plans/implementation-handoff-v0.6.md) | W0–W6 的增量与未完成项 |
| [验证记录](VALIDATION.md) | 实际运行与未证明范围 |

```bash
python lab/discovery/run_checks.py
python lab/discovery/run_diagnostics.py --out /tmp/srr-v06-discovery-new
python lab/recovery/run_checks.py
python lab/baseline/run_checks.py
python lab/analysis/run_checks.py
python lab/run_checks.py
python examples/check_contract_example.py
python tools/build_book.py
```

32 项新检查、13 对手工输入、52 份不同候选×世界检查记录，与旧 37/40/42/71/11 检查分别报告，不换算生产可靠性。当前是开发诊断，不能作为留出 benchmark。DEC01–DEC42 Proposed；E0–E5 未通过。
