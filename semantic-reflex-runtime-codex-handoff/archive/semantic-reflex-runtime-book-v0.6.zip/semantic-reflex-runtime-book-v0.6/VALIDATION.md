# v0.6 本轮验证记录

**2026-09-18｜已执行本地反例、固定候选、读取探针与文档检查。未联网，未调用宿主、agent 或语义模型。**

## 1. 本轮实际执行

| 项目 | 结果 | 实际支持 |
|---|---|---|
| 新有限需求反例与导出检查 | 32 项 unittest 方法通过，0 failures/errors | 相同投影、明确验收差异、保护与无关控制、allowlist 导出与读取 |
| 手工世界诊断 | 4 族、13 对、26 世界，52 份不同世界×候选检查记录 | 两份固定候选与显式例子的行为，不是 agent 修复 |
| 第二次同输入完整重跑 | 158 份诊断文件逐字节一致 | 同一确定性材料可复现，不是第二组独立样本 |
| v0.5 恢复合同回归 | 37 项通过 | 旧批量与原 D 局部合同 |
| v0.4 B 与文件回归 | 40 项通过 | 旧有限来源、视图与普通文件机制 |
| v0.3 描述分析回归 | 42 项通过 | 旧名册、费用闭合与算术检查 |
| v0.2 内存合同回归 | 71 项通过 | 旧有限交付／权限参数／召回模型 |
| v0.1 构造样例 | 11 项通过 | 旧源与划分静态一致性 |
| v0.5 输入继承 | 237 份选定参考、代码、源与历史诊断身份核验 | 原参考、冻结输入与既有实验代码未被改写 |

原始记录：[新检查](lab/discovery/check-results.json)、[逐项输出](lab/discovery/check-results.txt)、[反例报告](lab/discovery/diagnostics/report.json)、[同输入复现](lab/discovery/reproducibility.json)、[旧检查命令及日志](lab/discovery/regression-results.json)、[继承清单](lab/discovery/inherited-inputs.json)。

文档相对目标、表格、模块编号、JSON/JSONL、整册锚点、原引用副本与 ZIP 使用本包构建脚本核对；实际数量见 [BUILD_REPORT.json](BUILD_REPORT.json)。源码通过 Python 编译检查。SHA256SUMS 只证明文件身份，不证明内容真实或授权可信。

## 2. 32 项检查证明的范围

四个行为族在 deferred/outside_snapshot 控制下分别具备相同初始公开输入、相同目录、不同可访问契约与不相交的固定候选验收集合。deferred 的 selector 捕获不同，outside_snapshot 的 selector 捕获相同；protected 首次输入不同，无关变化保持验收集合相同。

两份固定候选都通过公共例子，区分例子能够检测契约差异。期望是手写值，不由候选或 selector 输出推导，但同一作者的预期不是外部独立 oracle。执行仅限模块内可信的固定函数，不接受外部代码。

初始导出只写 input.json；本地函数拒绝未知块、未授权映射路径和额外参数；读操作不改变原分区；输出目录已存在则拒绝覆盖。这里的映射权限来自可信测试设定，不是认证或 OS 沙箱。

## 3. 相同观察与数量的限定

本轮使用诊断会话 alias，不是 v0.5 的源 hash wire；不声称不同字节具有相同 hash。相同首次输入只在这个明确的投影上成立。真实协议的所有可见 ID、来源、长度、历史需要另验。

13 对来自 4 个手工族及控制，不是独立同分布样本。52 是不同的世界×候选组合记录，构建、audit 和 unittest 可重复调用同一函数，不能当全部函数调用总数，更不能当 52 次 agent 尝试。

相同观察下同一固定候选至多满足一个相反契约，只在有限菜单、不新增信息的条件下成立；有查询、弃权、自适应程序或其他可观察信息时不可直接外推。没有模型准确率或总体 50% 上限的测量。

## 4. 仍未证明

脚本选择了要读的路径，未测自然需求发现、对目录的理解或代码修复能力；提供的 26 世界都不是实际 coding benchmark。所有反例和答案已公开，不能作为未来留出数据。

没有真实搜索、host hook、下一次模型请求、实时权限、实际挂载、网络／并发故障、成本、tokenizer、缓存或维护经济性。目录分流不证明模型无法读到父目录；真实实验需宿主级 allowlist 与隔离证据。

捕获外反例有可访问仓库规范，因此不是不可解的秘密要求；实际任务若规范不可得，应保留信息不足／验收未知。完整快照未包含新资源不等于 recall 出错，也不能拿这个反例宣称语义选择普遍无效。

E0–E5 不晋升。新旧测试分别报告，不加总成生产可靠性或覆盖率。

## 5. 复验

```bash
python lab/discovery/run_checks.py
python lab/discovery/run_diagnostics.py --out /tmp/srr-v06-discovery-new
python lab/recovery/run_checks.py
python lab/baseline/run_checks.py
python lab/analysis/run_checks.py
python lab/run_checks.py
python examples/check_contract_example.py
python tools/build_book.py --export
```

新诊断目录必须不存在。运行只使用本地标准库，不存在后台执行承诺或未来自动抓取。书稿 Draft；DEC01–DEC42 Proposed。
