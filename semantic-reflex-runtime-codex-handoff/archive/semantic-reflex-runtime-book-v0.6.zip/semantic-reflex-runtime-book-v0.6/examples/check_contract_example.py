"""Check a constructed document fixture, not a Runtime implementation or benchmark.

Run with Python 3.10+: python examples/check_contract_example.py
Uses only the standard library. No network, model calls, or real host integration.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Any


class ContractError(ValueError):
    """The illustrative payload violates a checked static contract."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ContractError(message)


def validate(case: dict[str, Any], raw: bytes) -> None:
    source = case['source']
    envelope = case['envelope']
    blocks = case['blocks']
    require(source['content_hash'] == hashlib.sha256(raw).hexdigest(), 'source hash mismatch')
    require(source['byte_length'] == len(raw), 'source length mismatch')
    require(source['source_id'] == envelope['source_id'], 'wrong source identity')
    require(source['complete'] is True and envelope['source_status']['complete'] is True,
            'selected fixture requires a complete captured source')
    ids = [b['block_id'] for b in blocks]
    require(len(set(ids)) == len(ids), 'duplicate block IDs')
    index = {b['block_id']: b for b in blocks}
    cursor = 0
    for b in blocks:
        require(b['source_id'] == source['source_id'], 'cross-source block')
        start, end = b['byte_start'], b['byte_end']
        require(isinstance(start, int) and isinstance(end, int) and start == cursor
                and start < end <= len(raw), 'invalid source partition')
        try:
            raw[start:end].decode('utf-8')
        except UnicodeDecodeError as error:
            raise ContractError('invalid UTF-8 boundary') from error
        cursor = end
    require(cursor == len(raw), 'source not fully partitioned')
    kept = [x['block_id'] for x in envelope['included']]
    deferred = [x['block_id'] for x in envelope['deferred_manifest']]
    require(len(kept) == len(set(kept)) and len(deferred) == len(set(deferred)), 'repeated view block')
    require(not (set(kept) & set(deferred)), 'included/deferred overlap')
    require(set(kept) | set(deferred) == set(ids), 'not an exhaustive view partition')
    require(set(case['protection']['must_keep']) <= set(kept), 'protected block deferred')
    for x in envelope['included']:
        b = index[x['block_id']]
        require(x['text'] == raw[b['byte_start']:b['byte_end']].decode('utf-8'), 'rewritten excerpt')
    handles = envelope['recall_entry']['handle_table']
    for item in envelope['deferred_manifest']:
        require(item['recall_handle'] in handles, 'missing recall mapping')
        ref = handles[item['recall_handle']]
        require(ref['source_id'] == source['source_id'] and ref['block_id'] == item['block_id'],
                'incorrect recall reference')
        require(item['origin'] == index[item['block_id']]['origin'], 'wrong manifest origin')


def main() -> None:
    base = Path(__file__).resolve().parent
    case = json.loads((base / 'admission-case.json').read_text(encoding='utf-8'))
    raw = (base / 'source.txt').read_bytes()
    validate(case, raw)
    checks: list[str] = ['valid_fixture: PASS']
    index = {b['block_id']: b for b in case['blocks']}
    b = index['b02']
    restored = raw[b['byte_start']:b['byte_end']].decode('utf-8')
    require(restored.startswith('docs/archive/auth_notes.md:'), 'unexpected recalled range')
    checks.append('exact_fixture_range_read: PASS (not a real host recall)')

    tests: list[tuple[str, dict[str, Any], bytes]] = []
    bad = copy.deepcopy(case); bad['source']['content_hash'] = '0' * 64
    tests.append(('reject_bad_hash', bad, raw))
    bad = copy.deepcopy(case); bad['envelope']['included'][0]['text'] += 'invented'
    tests.append(('reject_rewritten_excerpt', bad, raw))
    bad = copy.deepcopy(case); bad['protection']['must_keep'].append('b02')
    tests.append(('reject_deferred_protected_block', bad, raw))
    bad = copy.deepcopy(case); bad['envelope']['deferred_manifest'] = []
    tests.append(('reject_missing_partition_member', bad, raw))
    bad = copy.deepcopy(case); bad['blocks'][1]['byte_start'] += 1
    tests.append(('reject_broken_byte_partition', bad, raw))
    bad = copy.deepcopy(case); bad['envelope']['source_id'] = 'other-source'
    tests.append(('reject_wrong_source', bad, raw))
    bad = copy.deepcopy(case); bad['envelope']['recall_entry']['handle_table'] = {}
    tests.append(('reject_missing_handle_mapping', bad, raw))
    bad = copy.deepcopy(case); bad['source']['complete'] = False
    tests.append(('reject_partial_source_for_this_fixture', bad, raw))
    bad = copy.deepcopy(case); bad['envelope']['deferred_manifest'][0]['origin'] = 'wrong-file'
    tests.append(('reject_wrong_manifest_origin', bad, raw))

    for name, mutated, content in tests:
        try:
            validate(mutated, content)
        except ContractError:
            checks.append(f'{name}: PASS (invalid fixture rejected)')
        else:
            raise ContractError(f'{name}: invalid fixture unexpectedly accepted')
    print('\n'.join(checks))
    print(f'Total: {len(checks)} constructed checks passed. No semantic, ACL, host, or outcome test performed.')


if __name__ == '__main__':
    try:
        main()
    except (ContractError, OSError, KeyError, TypeError, json.JSONDecodeError) as error:
        raise SystemExit(f'Fixture check failed: {error}') from error
