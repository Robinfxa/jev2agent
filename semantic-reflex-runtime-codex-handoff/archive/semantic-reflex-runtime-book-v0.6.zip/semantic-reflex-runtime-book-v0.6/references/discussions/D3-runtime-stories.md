会。**如果 Jev 是在 LLM 已经完成“想清楚 → 选工具”之后，再问一遍“这个工具选得对不对”，很多情况下确实是脱裤子放屁。**

关键不是“Jev 能不能判断”，而是：

> **它有没有在主模型尚未花掉那笔推理成本、尚未锁定动作之前，改变信息结构或决策路径。**

### 最容易做错的架构

```
```

```
LLM reasoning
    ↓
“我要用 grep”
    ↓
Jev：grep 合适吗？
    ↓
是
    ↓
grep
```

这里 Jev 大部分时间只是在重复已经完成的判断：

- &#x20;多一次延迟；&#x20;
- &#x20;多一次 API；&#x20;
- &#x20;可能还制造冲突；&#x20;
- &#x20;主模型已经为工具选择付过 reasoning 成本。&#x20;

这种 `PreToolUse semantic approval` 如果所有动作都跑，我现在反而**不看好**。

---

## 真正有价值的是把 Jev 放到“思考之前”

比如原来：

```
```

```
100 tools
   ↓
LLM 阅读 100 个 schema
   ↓
reasoning
   ↓
选 tool A
```

变成：

```
```

```
100 tool metadata
   ↓
Jev
   ↓
候选 A / B / C
   ↓
LLM reasoning
   ↓
选 A + 填参数
```

这里 Jev 做的事情主模型**还没做**。

这才创造净收益。

所以 skill/tool/file disclosure 是成立的，因为它发生在 expensive reasoning **之前**。

---

# 第二种有价值情况：Jev 看的是 LLM 没有显式考虑的维度

例如 Codex 已经决定：

```
```

```
Edit cache.py
```

如果再问：

> “cache.py 是不是该改？”

意义不大。

但问：

```
```

```
当前是否存在明显未读取的 caller？
当前动作是否已经连续第三次低信息增益？
这个改动是否扩大到了原任务之外？
```

就不完全是重复。

因为主模型的优化目标通常是：

> **完成当前任务**

而 Reflex layer 可以专门盯：

> **过程健康度**

类似开车：

```
```

```
司机已经决定向左转
```

你不需要另一个人再说：

> “左转对不对？”

但车辆系统仍然值得检查：

```
```

```
盲区里有车吗？
车道偏离了吗？
前方距离安全吗？
```

这是**正交信号**，才值得单独存在。

---

# 所以我们刚才那些 User Story 应该重新筛一次

我现在会这样分：

| 场景                              | Jev价值 | 原因                              |
| ------------------------------- | ----- | ------------------------------- |
| **Skill 预筛选**                   | ★★★★★ | 主模型还没读完整 skill                  |
| **Tool progressive disclosure** | ★★★★★ | 主模型还没承担 100 tools 的选择成本         |
| **File/context 预披露**            | ★★★★★ | 在主模型阅读源码前发生                     |
| **Tool output sieve**           | ★★★★★ | 在噪声进入主 context 前发生              |
| **Progress / 梦游检测**             | ★★★★☆ | 检查的是 trajectory，不重复当前 action 判断 |
| **Completion check**            | ★★★★☆ | 主模型有明显 self-certification bias  |
| **是否升级 reviewer**               | ★★★★☆ | 可以避免一次昂贵 System-2 调用            |
| **PreEdit“这个 edit 对不对”**        | ★★☆☆☆ | 非常容易重复主模型已经做过的 reasoning        |
| **每次 tool call 都问“这个 tool 对吗”** | ★☆☆☆☆ | 大概率纯 overhead                   |

这其实帮我们砍掉了很多没必要的设计。

---

# 我现在甚至不太喜欢 `PreAction` 这个名字了

因为容易诱导我们做：

```
```

```
每个动作 → Jev 审批
```

更好的几个位置是：

### 1. `PreReasoning Disclosure`

在主模型真正 reasoning 前：

```
```

```
选 skill
选 tool namespace
选 repo context
选 memory
```

这是最值钱的。

### 2. `PreContext Admission`

任何东西**进入模型 context 前**：

```
```

```
grep result
web result
subagent report
memory
大文件
```

先判断值不值得进入。

这也没有重复 LLM 思考，因为它还没看到。

### 3. `Trajectory Monitor`

完全旁路：

```
```

```
LLM正常工作
       │
       └→ Jev观察 action/evidence trajectory
```

平时不打扰。

只有：

```
```

```
连续无进展
重复
明显 scope drift
```

才 interrupt。

这样调用很多，但**绝大多数返回不会进入主 context**。

### 4. `PreExit`

结束是一个特殊情况。

因为 agent 在决定：

> “我已经完成了。”

这时独立 judge 本来就很有意义，就像：

```
```

```
作者 ≠ reviewer
开发者 ≠ CI
```

---

# 一个更干净的整体架构

我现在觉得最合理的是：

```
```

```
                     ┌──────────────┐
Resources ──────────→│ Jev          │
skills/tools/files   │ Disclosure   │
                     └──────┬───────┘
                            ↓
                      small working set
                            ↓
                      ┌──────────┐
                      │ System-2 │
                      │ LLM      │
                      └────┬─────┘
                           │
                     action / result
                           │
                 ┌─────────┴─────────┐
                 ▼                   ▼
          main agent loop       Jev observer
                                  │
                           only interrupt when
                            anomaly detected
```

这里 Jev 不再每次站在 LLM 面前说：

> “你确定吗？”

而是两种角色：

**前面是注意力分配器。**

**旁边是反射监控器。**

这就合理很多。

---

# 甚至可以定一条非常简单的原则

> **如果主模型已经看过同样的信息，并且刚刚为了同一个问题做过 reasoning，就不要再调用 Jev 判断同一件事。**

Jev 应该满足至少一个条件：

1. **它发生在主模型看到信息之前；**&#x20;
2. **它检查的是主模型没有专门优化的正交维度；**&#x20;
3. **它能避免一次更贵的 System-2 reasoning；**&#x20;
4. **它只在异常时打断主模型。**&#x20;

否则不调用。

我觉得你这个质疑其实非常重要，因为它把项目从“到处挂 Jev hook”拉回了更合理的方向。

**真正值得做的不是 System-2 做完决策以后再让 System-1点评，而是让 System-1负责 System-2 不应该浪费智力去做的事情。**

现在重新想一想userstory

重新想以后，我会把 user story 大幅收缩，不再围绕“每个 agent 动作都让 Jev 检查一次”，而只保留 **Jev 能在 System-2 尚未做这件事之前，或者能观察 System-2 没有专门关注的维度** 的场景。

核心原则变成：

> **Jev 不复核 LLM 刚刚已经想过的决定；Jev 要么提前塑造 LLM 看到的世界，要么旁路观察整个轨迹，要么承担独立验收。**

这样 user story 会干净很多。

| #       | User Story                                                                                                | Jev 出现的位置             | 为什么不是重复劳动                                 | Jev 输出什么                                        |
| ------- | --------------------------------------------------------------------------------------------------------- | --------------------- | ----------------------------------------- | ----------------------------------------------- |
| **US1** | **作为 coding agent，我希望在开始深入推理前，只看到当前任务最可能需要的 skill / tool family / repo 区域，以免先花大量 token 理解整个能力空间。**        | Pre-reasoning         | LLM 还没看完整 catalogue                       | relevance / need / ambiguity                    |
| **US2** | **作为 coding agent，我希望大文件、grep、subagent report 等内容在第一次进入我的 context 前先被筛选，让低价值内容保持可召回但不占 working context。** | Pre-context-admission | LLM 尚未看到这些内容                              | relevance / novelty / must-keep                 |
| **US3** | **作为 coding agent，我希望当我主动表达“缺信息”时，系统能从更大的 repo / docs / tools 中选择下一批最值得展开的内容，而不是把全部东西重新暴露给我。**            | Explicit expand       | LLM知道“缺东西”，但没必要亲自扫完整空间                    | candidate relevance / information gain          |
| **US4** | **作为 Director，我希望有一个旁路观察器监测 agent 最近几步是否真正减少了不确定性，而不是仅仅持续产生动作。**                                          | Trajectory observer   | 检查的是跨步骤趋势，不是复核单个 action                   | progress / repetition / uncertainty reduction   |
| **US5** | **作为 Director，我希望只有在 agent 明显陷入循环、scope drift 或长期无进展时才打断它，让它重新规划。**                                       | Conditional interrupt | 平时完全不打扰主模型                                | stuck / drift / replan-needed                   |
| **US6** | **作为系统，我希望 cheap semantic layer 先判断当前状态是否真的值得调用一个昂贵 reviewer / stronger model / subagent。**               | Pre-escalation        | 目的就是避免昂贵 System-2 调用                      | uncertainty / risk / expected review value      |
| **US7** | **作为 Director，我希望 agent 申请完成时，有一个独立语义观察者检查“是否还有实质工作未完成”，再结合 tests/spec/diff 等硬证据决定是否放行。**                 | Pre-exit              | self-review 和 independent review 本来就不是一回事 | material work remaining / semantic completeness |
| **US8** | **作为系统，我希望经过很多真实运行后，把哪些上下文被披露、哪些后来被召回、哪些从未使用记录下来，从而持续校准 disclosure policy。**                              | Offline learning      | 不参与主 agent reasoning                      | regret / waste / hit rate                       |

我现在最看好的，其实不是以前那个 `PreEdit`。

## US1：在“思考成本发生前”缩小世界

例如用户说：

```
```

```
修复 OAuth refresh 偶发失败。
```

系统本地先知道有：

```
```

```
37 skills
14 tool namespaces
4800 files
```

不要直接交给 Codex。

本地 retrieval 先缩成：

```
```

```
skills: bugfix / concurrency-debug / auth-debug
tools: lsp / codegraph / tests / git
repo areas:
  auth/
  session/
  oauth/
  tests/auth/
```

再让 Jev 判断：

```
```

```
auth-debug       .91
bugfix           .88
concurrency      .64

auth/            .96
session/         .81
oauth/           .73
tests/auth/      .90
```

最后 Codex 第一次真正 reasoning 时，只看到：

```
```

```
bugfix + auth-debug
LSP + codegraph + tests
4 个 repo regions
```

这是真正的节省。

因为原来 Codex 要自己先理解：

> “我有哪些东西可用？”

现在这部分认知负担被挪走了。

---

## US2：信息还没进入脑子之前就筛

这个我现在认为可能是最强的。

例如：

```
```

```
rg "refresh_token" → 2400 行
```

如果 2400 行已经进入 Codex，再让 Jev说：

> 其中只有 200 行有用。

已经晚了。

正确位置是：

```
```

```
tool result
     ↓
Reflex Runtime
     ↓
Jev / deterministic filter
     ↓
200 lines full
10 blocks summarized
rest → recall handles
     ↓
Codex sees result
```

它本质上类似：

> **sensory gating**

不是监督 reasoning。

这类场景尤其适合 Jev，因为一次可以并行判断几十个 block。

---

## US3：Agent 主动要求扩大视野

这个是对 disclosure 最大的安全补偿。

Codex发现：

> “目前证据不足，我需要知道谁还会修改这个 token。”

它不需要自己：

```
```

```
grep 全 repo → 看 500 个结果
```

它可以发出：

```
```

```
expand_context:
  need = "writers of refresh state outside TokenCache"
```

Reflex Runtime：

```
```

```
CodeGraph / LSP
→ 27 candidates
→ Jev rerank
→ 4 candidates
```

然后增量披露。

这里 System-2 决定：

> **我缺什么。**

System-1 决定：

> **从哪里最便宜地找到它。**

这个职责划分我觉得非常合理。

---

# US4/5：真正的“反射监控”

这个和工具选择是完全不同的一类价值。

假设 agent：

```
```

```
Step 8  grep SessionManager
Step 9  read session.py
Step 10 grep refresh
Step 11 read session.py again
Step 12 grep TokenCache
```

单看每一步：

> 都“有道理”。

所以 `PreAction` 判断很可能每次都会放行。

但从 trajectory 看：

```
```

```
new evidence        ↓
open questions      不变
same files          ↑
same search family  ↑
test state          不变
```

Jev 可以判断：

```
```

```
progress        .14
repetition      .89
stuck           .82
scope_alignment .91
```

这时候系统才插一句：

```
```

```
Re-plan. Recent steps have not reduced the main uncertainty.
State the current hypothesis and choose the next action with the highest expected information gain.
```

这里 Jev没有说：

> “你刚刚那个 grep 错了。”

而是在说：

> **“你五步加起来没有前进。”**

这才是旁路 observer 真正有价值的地方。

---

# US6：昂贵 reasoning 的 gatekeeper

例如 agent 想：

```
```

```
spawn architecture reviewer
```

这个决定本身可能已经想过了。

但我们可以不问：

> “该不该 spawn？”

而问另一个问题：

```
```

```
current unresolved uncertainty?
blast radius?
evidence conflict?
independent review likely to change decision?
```

如果：

```
```

```
uncertainty .18
risk        .14
conflict    .05
review_gain .11
```

普通 policy：

```
```

```
skip expensive reviewer
```

如果：

```
```

```
uncertainty .72
risk        .84
conflict    .66
review_gain .81
```

才调用 System-2 reviewer。

所以 Jev 是：

> **metareasoning budget allocator**

不是 reviewer 本身。

我认为这是很重要的一个场景。

---

# US7：结束判断仍然成立

这个并不会因为“LLM已经想过了”而失去价值。

因为这里恰恰需要 independence。

开发者写完代码以后觉得：

> “已经好了。”

Reviewer / CI 再检查，本来就不是重复。

可以有：

```
```

```
Hard facts:
tests = green
lint = green
OpenSpec tasks = complete
no unresolved compiler error
```

然后 Jev只负责模糊部分：

```
```

```
does evidence address original goal?      .94
material work appears unfinished?         .12
known gap omitted from completion claim?  .08
semantic acceptance looks satisfied?      .91
```

之后 Director 才能：

```
```

```
candidate_complete → complete
```

这类独立终局判断我仍然很看好。

---

# 反而应该删除的旧 User Stories

我们之前提过的几个，我现在会明确删掉或降级：

```
```

```
❌ 每次 tool call 后问 Jev：这个 tool 选对了吗？
❌ 每次 edit 前问：这个 edit 对吗？
❌ 每次 shell command 前问：这个 action 是否合理？
❌ 每一步让 Jev 推荐“下一步是什么？”
```

这些非常容易变成：

```
```

```
System-2 thinking
+
System-1 repeating System-2
```

没有净收益。

除非涉及独立安全规则，否则不值得默认进入 hot path。

---

## 所以第一版我现在只会做 4 个能力

如果我们真的开项目，我甚至会比之前更克制：

```
```

```
1. DISCLOSE
   在 reasoning 前选择初始 soft context

2. ADMIT
   tool/subagent/search output 进入 context 前过滤

3. EXPAND
   System-2 主动缺信息时，选择下一批 context

4. OBSERVE
   旁路监测 progress / repetition / stuck
```

暂时甚至不做 completion。

结构会特别清楚：

```
```

```
                    ┌──────────────┐
Resources ─────────▶│ DISCLOSE     │
                    └──────┬───────┘
                           ▼
                        System-2
                           │
                    asks / acts
                     ┌─────┴─────┐
                     ▼           ▼
                  EXPAND        tool
                     │           │
                     │         result
                     │           ▼
                     │        ADMIT
                     │           │
                     └─────┬─────┘
                           ▼
                        System-2
                           │
                           │ events
                           ▼
                       OBSERVE
                           │
                    normal → silent
                    stuck  → replan
```

这里四个能力都满足刚才的原则：

- `DISCLOSE`：发生在 LLM 推理前。&#x20;
- `ADMIT`：发生在信息被 LLM 看到前。&#x20;
- `EXPAND`：System-2 只定义需求，不负责大规模搜索。&#x20;
- `OBSERVE`：检查跨步骤 trajectory，而不是重复单步判断。&#x20;

我现在认为，这比我们前两轮的 Reflex Runtime 设计更干净。

**一句话重新定义项目：不是“给 agent 增加一个小模型监督员”，而是“给 System-2 配一个负责 attention、sensory gating 和 trajectory awareness 的 System-1 runtime”。**

这个版本我会更愿意真的去做。

我有两个困惑：

1. 有哪些能力其实是harness自带/一般agent.md会参与的（比如开发原则啊什么的；我想知道我们做出来的东西如果和这些重叠了会更优秀吗？）

2.我看有几个story更多说的是那种一问一答的感觉，但是在长思维链当中其实用户会说话参与的机会已经越来越少了，基本都是agenet to agent 或者agent to tool

这两个困惑其实把项目边界进一步想清楚了。

我的结论是：

> **我们不应该再做一个“更聪明的 AGENTS.md / 更聪明的 harness”。**
>
> Harness 已经负责执行机制，AGENTS.md/CLAUDE.md 已经负责原则和约束。真正还缺的一层，是**在长时间 agent→tool、agent→agent 的机器轨迹上，根据“当前状态”动态判断：什么值得进入上下文、什么时候轨迹异常、什么时候需要扩大视野或升级。**

而且你第二点很重要：以后这个东西的主体根本不是 `User → Agent`，而应该是 **Agent Runtime → Agent Runtime**。

---

# 1. 先把现有东西各自负责什么说清楚

今天一个相对成熟的 coding harness，其实已经至少有五层。

| 层                | 已经负责什么                                                                          | 典型载体                               |
| ---------------- | ------------------------------------------------------------------------------- | ---------------------------------- |
| **Harness**      | session、model loop、tool execution、subagent、权限、sandbox、compaction、tool discovery | Codex / Claude Code / Copilot CLI  |
| **Instructions** | 开发原则、代码风格、测试要求、架构禁线                                                             | `AGENTS.md` / `CLAUDE.md`          |
| **Skills**       | 某一类任务应该怎么做                                                                      | `SKILL.md`                         |
| **Hooks**        | 在生命周期节点运行程序，机械拦截、logging、validation                                             | Pre/Post Tool、Stop 等               |
| **Agent roles**  | 不同 agent 的职责、工具、边界                                                              | `.agent.md` / subagent definitions |

这已经很多了。

Codex 的 `AGENTS.md` 本身就是在任务开始时构建 instruction chain；它适合放项目约束、开发规则、测试命令等，并不是一个实时状态机。

GitHub Copilot CLI 现在甚至同时支持：

- &#x20;custom instructions；&#x20;
- &#x20;hooks；&#x20;
- &#x20;skills；&#x20;
- &#x20;custom agents；&#x20;
- &#x20;MCP；&#x20;
- &#x20;deferred tool loading；&#x20;

所以“给 agent 加规则”“给 agent选工具”“加 hook”这些能力本身已经越来越成为 harness 原生能力。

你现在自己的 workflow，其实已经很正确地把这些层拆开了：`CLAUDE.md` 放通用纪律，overlay 放项目地图/铁律，skills 放流程，agent 文件放角色契约，而 hooks 明确只处理机械可判定事项，不负责架构判断。

---

# 那我们的东西如果和 AGENTS.md 重叠，会不会更优秀？

**有一种重叠很有价值，另一种完全没价值。**

### 没价值的重叠

AGENTS.md 已经写：

```
```

```
先看清楚再改。
不要过度工程。
修改 signature 前检查 caller。
```

然后每次 edit 前 Jev 又问：

```
```

```
你有没有先看清楚？
你是不是过度工程？
```

这只是：

```
```

```
静态规则
+
语义复读机
```

不值得。

---

## 有价值的是：把“原则”变成“运行时信号”

例如你的 workflow 已经规定：

> 修改方法 signature / return arity 时，要 grep 全树 caller。

AGENTS.md 能告诉模型：

```
```

```
记得做。
```

但 runtime 能看到：

```
```

```
event:
Edit function signature

trajectory:
- read implementation
- edited function
- no references/caller search observed
```

于是产生：

```
```

```
prerequisite_satisfied = .08
```

然后触发：

```
```

```
EXPAND:
caller references
```

这就不是重复了。

这是：

> **把 declarative policy 编译成 runtime monitor。**

我觉得这个方向其实很有意思。

---

# 所以三者应该是这样的关系

```
```

```
AGENTS.md / CLAUDE.md
        │
        │ declares
        ▼
  “应该怎么做”
        │
        │
        ▼
Semantic Runtime
        │
        │ observes
        ▼
 “现在实际上发生了什么？”
        │
        ▼
   only intervene
   when mismatch
```

例如：

```
```

```
AGENTS.md:
新行为应有验证证据

Runtime:
当前已改 production code
但 trajectory 中：
tests_seen = false
verification_evidence = false

→ anomaly
```

这才是增强。

---

# Harness 更不能重新做

比如 Copilot CLI 现在已经自己会做 Tool Search。

大约工具足够多时，它初始不加载所有 external tools，而是在需要时搜索；加载后的工具还会在后续 conversation 中保留。

所以我们没必要写：

```
```

```
自己的 MCP tool loader
自己的 tool registry
自己的 invocation engine
```

我们应该做：

```
```

```
Harness Tool Search
        ↑
     semantic hint
        ↑
 Reflex Runtime
```

例如：

```
```

```
当前 trajectory:
正在调查 auth concurrency

semantic hint:
prefer namespaces:
- codegraph
- test
- git
```

让 harness 原生 tool search 真正加载工具。

---

# Hooks 也是 substrate，不是我们的产品

GitHub 当前 hooks 已经有：

```
```

```
sessionStart
userPromptSubmitted
preToolUse
postToolUse
agentStop
subagentStop
...
```

而且 hook 可以同步 approve/deny tool。

这非常适合我们：

```
```

```
Harness
   │
   ▼
Hook/Event
   │
   ▼
Reflex Runtime
```

但不是：

```
```

```
Reflex Runtime
自己实现一个 agent loop
```

你自己的 workflow 当前也明确要求 hooks 只做确定性 guardrail，而不做架构判断。

我反而觉得这个原则应该保留，只是稍微扩充：

```
```

```
Deterministic Hook
→ 可以 block

Semantic Hook
→ 默认 observe / annotate / request expansion
→ 高置信异常才 interrupt
```

---

# 2. 你第二个困惑更重要：我们不应该围绕“用户回合”设计

你说得完全对。

我们之前用 User Story 来描述，很容易产生一个错觉：

```
```

```
User asks
↓
Agent answers
↓
Jev checks
```

但真正的长任务越来越像：

```
```

```
User
 │
 │ 只出现一次
 ▼
Main Agent
 │
 ├── Tool
 │      │
 │      └→ result
 │
 ├── Subagent A
 │      ├→ Tool
 │      ├→ Tool
 │      └→ report
 │
 ├── Subagent B
 │      ├→ Tool
 │      └→ report
 │
 ├── tests
 │
 ├── edit
 │
 ├── reviewer
 │
 └── final
```

用户可能半小时都没有再次说话。

所以我们的真正输入，不应该叫：

```
```

```
user turn
```

而应该叫：

# **Agent Event Stream**

---

# 真实的 runtime 应该监听这些事件

```
```

```
GOAL_START

AGENT_SPAWN
AGENT_HANDOFF

MODEL_STEP_START
MODEL_STEP_END

TOOL_CALL
TOOL_RESULT

CONTEXT_REQUEST
CONTEXT_ADMISSION

SUBAGENT_RETURN

CHECKPOINT

COMPACTION

AGENT_STOP
SUBAGENT_STOP
```

也就是说：

```
```

```
             Agent A
               │
        ┌──────┼───────┐
        ▼      ▼       ▼
      tool   agent B   agent C
        │      │       │
        ▼      ▼       ▼
      result  report   report
        │      │       │
        └──────┼───────┘
               ▼
          Event Stream
               │
               ▼
        Semantic Runtime
```

用户完全可以不在场。

---

# 这样一来，User Story 应该改叫 Runtime Story

举几个更准确的。

---

## RS1：Tool result → Agent

> 当一个工具产生大量结果时，在结果第一次进入任何 model context 前，runtime 应判断哪些部分值得进入 working context。

流程：

```
```

```
Agent
 ↓
grep
 ↓
2500 lines
 ↓
CONTEXT_ADMISSION EVENT
 ↓
Reflex Runtime
 ↓
300 lines + summaries + recall handles
 ↓
Agent
```

这里没有用户。

也没有重复主模型的 reasoning。

---

# RS2：Subagent → Main Agent

这个我现在觉得非常有价值。

假设 Director 派：

```
```

```
Researcher
Validation
Code Reader
```

三个 agent。

它们返回：

```
```

```
Researcher: 9000 tokens
Validation: 4000 tokens
Code Reader: 7000 tokens
```

传统：

```
```

```
20K tokens
   ↓
Main Agent
```

更合理：

```
```

```
subagent reports
       ↓
Semantic Admission
       ↓
   preserve:
   - decisions
   - conflicts
   - evidence
   - blockers

   defer:
   - browsing narrative
   - repeated code summaries
   - low-value background
       ↓
Main Agent
```

这实际上比用户输入 filtering 更重要。

因为长 agent workflow 的上下文污染，大量来自 **agent-to-agent handoff**。

你自己现在已经要求 Worker Report 只返回状态、改动、证据、风险和下一步，而不是大段叙事。

Semantic Runtime 可以把这个原则进一步运行时化。

---

# RS3：多个 Subagent 返回矛盾结果

例如：

```
```

```
Researcher:
方案 A 与架构一致。

Code Reader:
现有代码根本不支持 A。

Validation:
A 会破坏 invariant X。
```

现在 Main Agent 必须自己先读完三份再发现冲突。

Runtime 可以先判断：

```
```

```
cross_agent_conflict = .93
```

然后不是替 Main Agent裁决，而是构造：

```
```

```
<conflict>
Research: A recommended
Code evidence: capability absent
Validation: invariant violation
</conflict>
```

再交给 System-2。

这里 Reflex Runtime 做的是：

> **发现“值得思考的地方”。**

不是替它思考。

---

# RS4：Agent trajectory monitoring

整个过程：

```
```

```
agent
→ grep
→ read
→ subagent
→ read
→ grep
→ test
→ grep
```

Runtime 一直旁路看：

```
```

```
goal progress
uncertainty
novel evidence
repeat patterns
```

平时：

```
```

```
silent
silent
silent
silent
```

直到：

```
```

```
progress .11
repetition .87
```

才注入：

```
```

```
REPLAN_REQUIRED
```

用户不需要出现。

---

# RS5：Subagent 的 context disclosure

Main Agent 已经决定：

```
```

```
spawn security reviewer
```

不用 Jev 再问：

> 要不要 spawn？

这个决定已经想过了。

但在 **agent B 开始 reasoning 前**，runtime 可以决定：

```
```

```
给 security reviewer 看什么？
```

例如：

```
```

```
Hard:
- original goal
- current diff
- relevant invariant

Soft:
- auth ADR
- two related files
- prior security finding

Not disclose:
- unrelated frontend docs
- full project history
```

这和我们之前的 disclosure 概念完全一致，只不过对象从：

```
```

```
User → Agent
```

变成：

```
```

```
Agent A → Agent B
```

我觉得这反而更加重要。

---

# RS6：Subagent return contract

Subagent 说：

```
```

```
done
```

runtime 检查的不是：

> 你这个结论正确吗？

而是：

```
```

```
brief asked:
- root cause
- caller impact
- evidence
- risk

report contains:
- root cause ✓
- caller impact ✗
- evidence ✓
- risk ✗
```

于是：

```
```

```
handoff_sufficiency = .42
```

可以让 subagent 补齐后再返回 Main Agent。

这个动作发生在：

```
```

```
SUBAGENT_STOP
```

甚至不用污染 Main Agent context。

GitHub Copilot 当前 hooks 已经明确有 `subagentStop` 这样的生命周期点。

---

# 这让我重新认识这个项目真正的核心

原来我们一直在说：

> 给 Agent 增加 System-1。

现在我觉得更准确是：

> **给整个 multi-agent runtime 增加 System-1。**

不是每个 agent 身边放一个 Jev。

而是：

```
```

```
             Agent Runtime

 Main ─── Tool
   │       │
   ├─ A ─ Tool
   │
   ├─ B ─ Tool
   │
   └─ C
       │
       ▼
 ───── Event Bus ─────
       │
       ▼
 Semantic Reflex Layer
```

它观察的是**系统轨迹**。

---

# 所以它和 AGENTS.md 的关系也更清楚了

AGENTS.md 可能说：

```
```

```
Researcher 不改代码。
Validation 不拍板。
arc-imp 先 spec 后 implementation。
```

这是组织原则。

Runtime 可以看到：

```
```

```
Researcher → Edit production code
```

这不需要 Jev：

```
```

```
deterministic BLOCK
```

但如果：

```
```

```
Researcher report
```

和：

```
```

```
Validation report
```

在语义上冲突，

这才需要：

```
```

```
semantic conflict detector
```

所以正确的优先顺序应该是：

```
```

```
1. Harness-native
2. Static instructions
3. Deterministic policies
4. Semantic Reflex
5. Frontier reasoning
```

能在上层解决的，绝不往下层推。

---

# 我现在会用一个特别简单的判断标准

每当想到一个 Reflex feature，就问：

### 问题 A

**Harness 已经原生解决了吗？**

是：

> 不做。

### 问题 B

**AGENTS.md / CLAUDE.md 写一条规则就够了吗？**

是：

> 写规则。

### 问题 C

**能用 deterministic code 判断吗？**

是：

> 写 hook/rule。

### 问题 D

**它是否需要理解“当前多步状态的语义”？**

只有这里：

> **Reflex Runtime。**

例如：

```
```

```
这两个 agent 的报告是不是实质冲突？

最近五步有没有真正推进目标？

这份 tool result 哪部分会改变当前 hypothesis？

这个 subagent 返回的信息是否足以满足 brief？

这个新 context 是否与已有证据重复？

现在是否存在值得调用昂贵 System-2 的不确定性？
```

这些才是甜蜜点。

---

## 所以你这两个问题反而让我觉得，项目应该比之前更窄

不是：

> “增强 Agent 的所有方面。”

而是：

> **填补 static instructions / deterministic hooks / full System-2 reasoning 三者之间的空档。**

这个空档就是：

```
```

```
       deterministic
            ↑
            │
    semantic reflex
            │
            ↓
      full reasoning
```

而且 runtime 主要工作在：

```
```

```
Agent → Tool
Tool → Agent
Agent → Agent
Agent → Subagent
Subagent → Agent
Agent → Stop
```

而不是：

```
```

```
User → Agent
```

**我认为这版定义明显比我们前面“从 User Story 想功能”的方向成熟了一步。**