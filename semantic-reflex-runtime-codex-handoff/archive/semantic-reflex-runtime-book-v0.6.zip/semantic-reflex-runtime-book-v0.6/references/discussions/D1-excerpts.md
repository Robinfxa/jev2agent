# D1：前序 Control Plane / Disclosure Plane 讨论摘录

这是对当前会话已提供来源的局部摘录，不是完整原文，也不是外部研究。
原文引用基准：本轮上下文 `turn0file1`。下列 L 号为该来源原始行号，不是本文件行号。

## 确定性事实与判断权

L115–117：这些都是确定性事实。**能用代码知道答案，就绝对不要问 AI。**

L173–179：**我不建议把 Jev 塞进 hook，然后让 hook 自己决定项目完成。** 这会破坏你现在非常正确的权力分层。**Jev Decision Bus 是 Director 的 cheap semantic sensor，而不是新的 Director。**

L533–536：程序计算 `ready_for_acceptance`，最后还是 Director / CI gate 做最终 `COMPLETE`。

## Hard Context

L864–880：Hard Context —— Jev 永远不能藏。示例包括用户当前要求、active OpenSpec change、Director Plan 当前 slice、Agent Brief 的 Required Reads、Allowed / Forbidden Writes、项目核心 invariant、当前失败测试/编译错误、当前 diff、用户明确点名的文件。**Jev 不碰 Required Reads。**

## 可恢复披露

L1204–1208：**“藏起来”绝对不能等于删除。任何没披露的资源，都必须可恢复。**

L1272–1276：这是 progressive disclosure，而不是 context censorship。

## 采用边界

以上是上传讨论提出的原则，不证明任何宿主、产品或插件已经支持这些能力。摘录为本轮离线成书提供可读的来源定位；完整上下文以原会话附件为准。
