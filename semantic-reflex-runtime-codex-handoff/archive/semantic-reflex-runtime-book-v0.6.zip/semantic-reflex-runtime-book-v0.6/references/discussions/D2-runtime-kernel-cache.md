会有创新空间，但不是“没人想过在 agent 外面加一层判断”。这一点已经有人做了。更准确地说：

> **原子零件大多已经存在；把它们统一成一个面向 agent 生命周期的“通用语义反射运行时”，目前仍有明显的产品和工程创新空间。**

而且抛开 Jev，完全可以实现。**Jev 更像让这个想法突然变得经济可行的一种 backend，不应该成为项目本身。**

### 先看哪些部分已经不新了

现在已经有几条很接近的技术线：

- **Hook / Event Bus 已经存在。** HookBus 已经把 Claude Code、Codex、Hermes 等 agent 的 `PreToolUse / PostToolUse / PreLLMCall / PostLLMCall / SessionStart...` 统一成事件总线，subscriber 可以同步返回 allow/deny/ask。Microsoft 也刚发布 framework-neutral Agent Hooks。&#x20;
- **动态工具披露已经存在。** LangChain 有 `LLMToolSelectorMiddleware`，直接用另一个 LLM 在主模型调用前筛工具；也支持 middleware 每轮动态改主模型能看到的 tools。&#x20;
- **上下文/skill progressive disclosure 已经存在。** Ratel、winnow、OpenAI/Anthropic 原生 Tool Search 都属于这一条。甚至研究已经开始比较一层、两层 progressive disclosure。&#x20;
- **小模型/第二模型做 guardrail 也不新。** OpenAI Agents SDK 可以在 input/output/tool invocation 周围挂轻量模型；Agent Guard 甚至明确允许模糊区间调用第二个 LLM judge。&#x20;
- **通用 agent runtime layer 已经有人提出。** 2026 年 5 月的论文甚至直接抽象成 `observe → score → predict → act`。&#x20;
- **Signal → Decision 架构也已经很成熟。** vLLM Semantic Router 已经把 keyword、embedding、classifier、安全、difficulty 等 signal 分离出来，再形成 projection / decision / route；而且它明确正在向 agent tool calls、memory writes、model invocations 扩展。&#x20;

所以如果我们做：

```
```

```
Agent
↓
Hook
↓
Jev
↓
ALLOW / BLOCK
```

这不能称为明显创新。

---

## 但我们刚才讨论的东西其实比这些多了一步

我认为真正值得做的是这个抽象：

```
```

```
             Agent lifecycle
                    │
        ┌───────────┼───────────┐
        ▼           ▼           ▼
   PreAction   PostObservation  StepEnd ...
        │           │           │
        └───────────┼───────────┘
                    ▼
              State Capsule
                    │
                    ▼
          Semantic Predicate Kernel
         ┌──────────┼──────────┐
         ▼          ▼          ▼
     relevance   progress   sufficiency
     novelty     risk       uncertainty
     scope       completeness ...
         └──────────┼──────────┘
                    ▼
               Policy Engine
                    │
       ┌────────────┼────────────┐
       ▼            ▼            ▼
    disclose       expand       allow
    replan         review       escalate
    candidate_complete
```

这里潜在的新意不是某一个 classifier。

而是：

> **把 agent 运行过程中大量“模糊但高频的小判断”抽象成一组可复用的 semantic signals/predicates，然后让不同事件共享它们。**

现在大部分系统还是：

```
```

```
Tool selector 有自己的 prompt
Safety judge 有自己的 prompt
Completion judge 有自己的 prompt
Context filter 有自己的 prompt
Review judge 有自己的 prompt
```

五套独立 feature。

我们想做的是：

```
```

```
              Semantic Kernel

relevance ───────────┬─ file disclosure
                     ├─ tool selection
                     ├─ review finding
                     └─ memory retrieval

sufficiency ─────────┬─ pre-edit
                     ├─ pre-finish
                     └─ call reviewer?

progress ────────────┬─ step end
                     └─ stuck detection

uncertainty ─────────┬─ widen context
                     ├─ escalation
                     └─ human review
```

**这个统一性，我目前没有找到一个已经成熟做到的 coding-agent runtime。**

---

# 最接近我们的其实是 vLLM Semantic Router

这个必须认真研究。

它现在的核心已经不是简单：

```
```

```
request → classifier → model
```

而是：

```
```

```
Signals
   ↓
Projections
   ↓
Decisions
   ↓
Algorithms
   ↓
Execution path
```

它强调 detection 和 policy 分离，同一个 signal 可以被多个 policy 复用。

这和我们：

```
```

```
Predicate
   ↓
Policy
   ↓
Agent action
```

非常接近。

但目前主要差别是：

### vLLM Semantic Router 控制

```
```

```
一个请求应该走：
哪个模型
哪个 provider
什么 retrieval
什么 safety
什么 tool surface
```

### 我们想控制

```
```

```
一个已经运行中的 agent：

这一步上下文够了吗？
这次 observation 值不值得留下？
这个动作推进任务了吗？
是不是开始重复？
这个 finding 值得修吗？
应该扩大 disclosure 吗？
应该 replan 吗？
可以申请结束了吗？
```

也就是：

> **他们偏 request/inference routing；我们偏 trajectory/lifecycle regulation。**

这是一个真实区别。

---

# HookBus 反而可以直接借，而不是竞争

这是我现在觉得非常重要的一点。

HookBus 已经帮我们解决：

```
```

```
Claude Code ──┐
Codex ────────┤
Hermes ───────┼→ normalized event
OpenCode ─────┤
              ▼
          Event Bus
```

而且它本身明确说：

> bus 对事件内容没有意见，只负责 transport / fan-out / consolidation。

非常好。

我们完全可以不重新发明 Event Bus。

我们的东西可以只是一个 subscriber：

```
```

```
                    HookBus
                       │
                  PreToolUse
                  PostToolUse
                  PostLLMCall
                       │
                       ▼
          ┌────────────────────┐
          │ Semantic Reflex    │
          │ Runtime            │
          └─────────┬──────────┘
                    │
          judgments + steering
```

这反而让产品定位更清晰。

---

# 那抛开 Jev，可以用什么？

很多。

### 1. 普通便宜 LLM

比如：

```
```

```
GPT Luna
Gemini Flash
small Claude
Qwen small
```

Structured Output：

```
```

```
{
  "progress": 0.7,
  "sufficiency": 0.4,
  "risk": 0.2
}
```

优点是最通用。

缺点：

- &#x20;latency 更高；&#x20;
- &#x20;token generation 成本；&#x20;
- &#x20;calibration 往往不稳定；&#x20;
- &#x20;高频 hook 不够漂亮。&#x20;

但完全能做 MVP。

事实上 LangChain 的 `LLMToolSelectorMiddleware` 就已经是这个思路。

---

### 2. Embedding / cross-encoder

特别适合：

```
```

```
relevance
similarity
novelty
redundancy
```

例如：

```
```

```
task ↔ file
subgoal ↔ tool
observation ↔ existing evidence
```

根本不需要 Jev。

Ratel / Tool RAG 等现在大量采用 BM25 + embedding。

但它不擅长：

```
```

```
context sufficient?
scope creep?
material work remains?
did we actually progress?
```

这些涉及关系和状态。

---

### 3. 传统 classifier / NLI model

比如训练：

```
```

```
on_goal / off_goal
progress / no_progress
sufficient / insufficient
```

甚至一个 300M 模型就可能够。

vLLM Semantic Router 已经大量使用 sequence classifier / embedding / keyword 等混合 signal，而不是所有判断都交给大 LLM。

如果以后我们有几万条真实 agent trace：

> **把高频 predicate distill 成本地 classifier**

可能比 Jev 更漂亮。

---

### 4. 纯 deterministic signal

大量 predicate 根本不需要 AI。

例如：

```
```

```
重复打开同一文件
连续三次相似 grep
测试数量变化
diff 是否扩大
caller 是否已经读取
是否访问 forbidden path
token 消耗
同一 error 是否连续出现
```

全部可以代码算。

然后：

```
```

```
semantic progress
```

可以由：

```
```

```
deterministic signals
+
Jev/LLM signal
```

共同决定。

这才是成熟版本。

---

### 5. Reward / verifier model

以后甚至可以训练：

```
```

```
trajectory prefix
      ↓
is this agent making progress?
```

这就是 process reward/verifier 的方向。

那时候 `progress` 不再需要写 prompt。

---

# 所以最好的设计反而应该是 backend-agnostic

不要：

```
```

```
jev.progress(...)
jev.risk(...)
```

而应该：

```
```

```
signal("progress", state)
signal("risk", state)
```

然后 config：

```
```

```
predicates:

  relevance:
    backend: embedding

  redundancy:
    backend: deterministic

  progress:
    backend: jev

  sufficiency:
    backend: jev

  risk:
    backend: rules_then_jev

  completeness:
    backend: hard_facts_plus_jev
```

以后：

```
```

```
Jev
↓
local classifier
↓
GPT Luna
↓
trained verifier
```

都能换。

这时项目的价值就完全不依赖 Jev 了。

---

# 甚至 Predicate 不一定只有一个 backend

可以做 ensemble：

```
```

```
progress =
    deterministic_delta      .35
  + semantic_judge           .45
  + task_completion_delta    .20
```

或者：

```
```

```
cheap classifier confident
→ use it

classifier uncertain
→ Jev

Jev uncertain
→ System-2
```

形成：

```
```

```
rules
 ↓
local model
 ↓
Jev
 ↓
frontier LLM
 ↓
human
```

一个真正的 **semantic escalation ladder**。

这比“所有东西都调用 Jev”有价值得多。

---

# 所以创新点应该重新表述

千万不要说：

> “我们发明了一种用小模型监控 agent 的方法。”

不成立。

也不要说：

> “我们发明 progressive disclosure。”

当然也不成立。

如果最终证明有效，我认为比较有意思的 claim 是：

> **A framework-neutral semantic reflex runtime that converts agent lifecycle state into reusable probabilistic signals, and composes those signals into context, steering, escalation, and completion policies.**

中文：

> **一个框架无关的 agent 语义反射运行时：把 agent 生命周期状态转换成可复用的概率语义信号，再将这些信号组合成上下文披露、过程纠偏、升级和完成策略。**

这个才比较准确。

---

# 其中最有价值的创新，我认为其实是 Predicate Registry

比如定义：

```
```

```
relevance
sufficiency
progress
novelty
uncertainty
risk
scope_alignment
completeness
```

不是 prompt 文本。

而是有统一 contract：

```
```

```
predicate: sufficiency

input:
  goal
  subgoal
  evidence
  candidate_action

output:
  probability: 0..1
  confidence: optional
  evidence_refs: optional

semantics:
  "Current evidence is sufficient to responsibly take candidate_action."
```

然后这个东西：

```
```

```
PreEdit 用
PreTool 用
PreReview 用
PreFinish 也用
```

这会比每个 hook 写一个 prompt 强很多。

值得注意的是，现在甚至已经出现 **Judgment Pack Specification**，试图把 evidence、rules、exceptions、uncertainty、escalation 等判断做成独立可测试的结构化 artifact。它目前是 0.2 draft，而且主要面向业务决策而非 agent reflex loop，但说明“判断本身成为一等对象”已经开始成为一个方向。

所以我们最好也不要把自己的东西叫 `Judgment Pack`。

---

## 我现在对这个项目的判断

我会分成三个层次：

**学术原理创新：中低。**\
&#x20;event hooks、semantic routing、judge、progressive disclosure、runtime policy 都已有扎实先例。

**架构组合创新：中高。**\
&#x20;如果真正做成 **State Capsule → reusable predicates → event packs → policy actions**，并且同一组 predicates 横跨 disclosure / progress / review / finish，我目前没看到成熟 coding-agent 项目把这一整套统一起来。

**产品创新：高潜力，但必须用数据证明。**\
&#x20;真正重要的问题不是“架构看起来新不新”，而是：

```
```

```
同一个 Codex
+
Reflex Runtime
```

能不能稳定做到：

```
```

```
更少无效 read/grep
更少错误工具
更少 context
更少梦游 step
更少昂贵 reviewer call
不降低 solve rate
```

如果能做到，这个项目就有独立价值，即使明天 Jev 消失。

---

我现在甚至会建议我们**不要做&#x20;****`jev-agent`**。

而是做：

```
```

```
agent-reflex-runtime
```

或者类似定位。

Jev 只是：

```
```

```
providers/
    deterministic
    embedding
    jev
    llm
```

中的一个 provider。

这样就从：

> “Jev 很便宜，我们找点场景用它”

变成：

> **“agent 缺少一个 System-1 runtime，而 Jev 恰好是目前非常适合给它供能的 backend。”**

这两者的项目价值差很多。

而且从刚才这轮 prior-art 扫描看，**后者才是还有真正空间的方向。**

除去这些问题，还有一个需要考虑的是缓存命中。如果真的做了披露控制器缓存命中会不会大降，我也很好奇刚刚的哪些userstory会不会影响

会，而且这是披露控制器里一个很容易被低估的“反向成本”：**披露越动态，主模型 prompt/KV cache 越可能碎。** 但影响不是必然的，主要取决于“你怎么披露”。

OpenAI 当前的提示缓存就是复用**完全一致的前缀**，而工具定义本身属于被缓存的上下文；工具名称、描述、schema 或顺序变化，都可能让后续前缀失配。官方现在甚至专门建议：保持工具定义稳定，用 `allowed_tools` 限制可调用范围，或者用 `tool_search + defer_loading` 把新工具追加到上下文末尾，以保留前面的缓存。

所以刚才那个 `jev-eval-agent` 的方式：

```
```

```
step 1: tools = [A]
step 2: tools = [B]
step 3: tools = [C]
```

对缓存其实很不友好。它每一步都改变模型看到的 tool schema。这个项目自己的数据里也能看到这个迹象：例如同一个 GPT-5.6 Luna 的 `p3-orcamento`，`llm-direct` 记录了 **15,366 input tokens、其中 14,891 cache-read tokens**；Jev 每步只暴露一个工具的模式只有 **2,798 input tokens，但 cache-read = 0**。这只是一个样本，不能泛化，但它很好地说明：**raw tokens 降很多，不代表 cache-adjusted cost 一定更低。** [jev-eval-agent](https://github.com/vinilana/jev-eval-agent?utm_source=chatgpt.com)

更极端一点算：GPT-5.6 当前缓存读取价格是普通输入的 0.1 倍。按这个比例粗算，那次 direct 模式的输入成本等价约是：

```
```

```
475 未缓存
+
14,891 × 0.1 缓存

≈ 1,964 个普通输入 token
```

反而低于 Jev 模式的 2,798 个全未缓存 token。这里还没有算 Jev 自己的调用成本，也没算 reasoning 差异，所以这不是最终账单比较，只说明**缓存完全可能反转表面的 token 优势**。

### 刚才那些 user story，影响其实差别很大

| User story                     | 对主模型 cache 的潜在影响 | 原因                                        |
| ------------------------------ | ---------------- | ----------------------------------------- |
| 找对文件再开工                        | 🟢 低             | 文件作为新 context 追加即可，不需要重写旧前缀               |
| 防止过早 Edit                      | 🟢 很低            | Jev 在 sidecar 判断；需要更多 context 时只追加搜索结果    |
| 大搜索结果瘦身                        | 🟢 **可能提高整体效率**  | 在结果第一次进入模型前就过滤，减少动态后缀                     |
| 梦游 / progress watchdog         | 🟢 接近零           | 判断发生在模型外；只有需要 replan 时追加一条消息              |
| reviewer finding 修不修           | 🟢 接近零           | 可在独立 reviewer/reflex context 内运行          |
| 真修复还是 mask                     | 🟢 很低            | 读 diff/evidence 做 sidecar 判断，不必改变主 prompt |
| 要不要升级重模型                       | 🟢 零\~低          | 主要影响是否创建另一个 inference                     |
| PreFinish / done               | 🟢 很低            | sidecar judge；需要继续时只追加 reopen 指令          |
| **每步只披露一个 tool**               | 🔴 **高**         | tool definitions 每轮变化                     |
| **每轮重新生成 system context pack** | 🔴 **极高**        | 前缀不断改变                                    |
| **每轮删掉/重排已经披露的文件**             | 🔴 高             | 破坏 append-only history                    |
| Skill 加载后一直保留                  | 🟢 低             | 首次加载有变化，以后前缀可继续复用                         |

所以真正要避免的不是 Disclosure，而是：

> **mutable-prefix disclosure。**

---

# 我会因此修改我们之前的架构

之前我们说：

```
```

```
Jev
 ↓
Disclosure Envelope
 ↓
Agent sees selected tools/files/skills
```

现在我会加一个非常重要的约束：

## `Disclosure MUST be append-only whenever possible`

也就是：

```
```

```
Stable Prefix
├── system / developer rules
├── core tools
├── project invariants
└── stable capability index
        │
        │  ← cache breakpoint
        ▼
Dynamic Suffix
├── user task
├── disclosed file A
├── tool result
├── disclosed file B
├── new skill
└── observation
```

Jev 可以不断决定：

```
```

```
ADD A
ADD B
ADD C
```

但尽量不要：

```
```

```
REMOVE A
REPLACE A WITH C
REORDER B/A/C
```

这样：

```
```

```
step 1:
PREFIX + A

step 2:
PREFIX + A + observation + B

step 3:
PREFIX + A + observation + B + C
```

前面的缓存仍然可以连续复用。

这其实正是 OpenAI 新版 `tool_search` 的设计：**新发现的工具放到上下文末尾，而不是重新生成开头的工具目录，目的之一就是保留缓存。**&#x20;

---

# Tool disclosure 应该尤其改变设计

不要学 `jev-eval-agent`：

```
```

```
100 tools
 ↓
Jev
 ↓
重新把 tools 参数变成 [ONE_TOOL]
```

更好的两个方案之一是：

```
```

```
所有 tool definitions 保持稳定
        ↓
Jev
        ↓
allowed_tools = [A, B]
```

OpenAI 当前文档明确建议这样做：要限制本轮可调用工具时，优先用 `allowed_tools`，而不是删除原工具定义，从而保留缓存前缀。

或者更理想：

```
```

```
稳定可见：
tool_search
code_tools namespace
git_tools namespace
test_tools namespace

           ↓

Jev 推荐 code_tools

           ↓

tool_search 动态加载
lsp.references
codegraph.callers

           ↓

append 到末尾
```

这和我们的 Disclosure Plane 简直天然兼容。

Jev 甚至不应该直接“加载 tool”。

它可以只是给 native Tool Search 提供：

```
```

```
preferred namespaces
candidate shortlist
semantic relevance
```

然后真正加载由平台做。

---

# File disclosure 反而很 cache-friendly

这是个好消息。

例如：

```
```

```
Codex 已经缓存：

system
AGENTS.md
task
conversation up to step 6
```

Jev 判断：

```
```

```
cache.py 有用
session.py 有用
config.py 暂时不用
```

只要我们把：

```
```

```
cache.py excerpt
session.py excerpt
```

**追加在现有 history 后面**，

不会破坏前面已经存在的缓存。

所以文件披露完全值得做。

真正不能干的是每轮生成：

```
```

```
CURRENT_CONTEXT.md
```

然后：

```
```

```
step 1 → 文件 A/B/C 摘要
step 2 → 文件 B/D/E 摘要
step 3 → 文件 A/F/G 摘要
```

再拿这整个东西去替换之前的 context。

那缓存会惨不忍睹。

---

# Observation sieve 甚至可能特别适合缓存

刚才那个 User Story：

> grep 返回 1800 行，只让有用的部分进入 context。

如果是在**第一次把 tool result 返回给模型之前**做：

```
```

```
tool
 ↓
1800 lines
 ↓
Jev sieve
 ↓
250 lines + recall handles
 ↓
append to model history
```

非常好。

你从来没有把 1800 行放进主模型缓存。

之后那 250 行又成为稳定 history。

所以这是：

```
```

```
cache friendly
+
context friendly
+
token friendly
```

我现在甚至觉得它可能是第一批最好验证的场景之一。

但是千万不要：

```
```

```
先把 1800 行给 Codex
↓
下一轮觉得太多
↓
重写历史成 250 行 summary
```

OpenAI 文档明确指出这种 context compaction/替换会从修改点开始降低缓存复用。

---

# Progress watchdog 几乎完全不影响 cache

这是为什么我越来越喜欢这个 User Story。

它可以完全旁路运行：

```
```

```
Agent action
 ↓
Tool result
 ↓
State Capsule
 ↓
Jev
 ↓
progress=.12
redundancy=.91
```

这些结果甚至**不需要每轮告诉主模型**。

只有达到 policy：

```
```

```
3 consecutive low-progress steps
```

才追加：

```
```

```
<runtime_feedback>
Progress has remained low for three steps.
Re-plan around the largest unresolved uncertainty.
</runtime_feedback>
```

于是绝大多数轮：

```
```

```
主模型 prompt 完全没变化
```

但是 runtime 一直在监控。

这正是 System-1 sidecar 最漂亮的地方。

---

# 所以最终应该把 Cache 变成一等设计目标

我甚至会把我们的 Reflex Runtime contract 加一个字段：

```
```

```
event: PRE_ACTION

judgments:
  sufficiency: 0.42
  risk: 0.13

policy:
  action: EXPAND_CONTEXT

cache_policy:
  mutation: append_only
  prefix_safe: true
```

每个 policy action 都标：

```
```

```
NO_PROMPT_CHANGE
APPEND_ONLY
TOOL_ALLOWLIST_ONLY
NEW_TOOL_APPEND
PREFIX_MUTATION
HISTORY_REWRITE
```

然后默认禁止最后两个。

最后体系就变成：

```
```

```
                Semantic Runtime
                       │
          ┌────────────┴────────────┐
          ▼                         ▼
   semantic quality             cache cost
          │                         │
          └────────────┬────────────┘
                       ▼
                    Policy
```

也就是不再只优化：

```
```

```
少给模型 token
```

而优化：

> **effective uncached tokens。**

这个指标比 raw input tokens 更重要。

我甚至会在 benchmark 里直接增加：

```
```

```
raw_input_tokens
cached_input_tokens
uncached_input_tokens
cache_hit_ratio
cache_write_tokens
effective_input_cost
context_disclosed
task_success
```

---

所以你这个提醒实际上改变了 Disclosure Plane 的一个核心原则：

> **最好的披露控制器不是不断重建一个“小 context”，而是保持一个高度可缓存的稳定前缀，然后以 append-only 的方式逐步扩展 agent 的可见世界。**

这会让我们之前说的几个 User Story 分成两大类：**PreAction / Progress / Review / Finish 这种 sidecar judgment 几乎是“免费”的缓存层面；真正需要谨慎设计的是 Tool/Skill/File Disclosure，而其中 Tool 动态 schema 是最大雷区。**

而且有意思的是，OpenAI 当前的 `tool_search` 已经明确按照“动态能力加载 + 缓存保留”这个方向设计了，所以我们的 Reflex Runtime 最好**利用平台的 deferred loading，而不是自己暴力替换 tools 列表**。

最终这个项目可能带来的提升会是什么

如果这个项目最后真的做成，我觉得它带来的核心提升不会是“让 Codex 变聪明”，而是：

> **让同一个 Codex/Claude，在更少上下文、更少无效动作、更少昂贵推理、更少误操作的情况下，表现得像一个更成熟的 agent。**

也就是提升的是 **effective intelligence（有效智能）**，不是 base model intelligence。

我会把潜在收益分成六类。

## 1. 更少的无效步骤

这是最直接的。

现在 coding agent 很多成本浪费在：

```
```

```
读错文件
→ grep 太宽
→ 再读几个文件
→ 提前 edit
→ test
→ 发现 caller 漏了
→ 回头重做
```

Reflex Runtime 可以在中间不断问：

```
```

```
context够了吗？
这一步有信息增益吗？
是不是重复？
是不是偏离目标？
```

最终可能把：

```
```

```
20 steps
```

压成：

```
```

```
12–15 meaningful steps
```

真正重要的指标不是“总 step 少多少”，而是：

> **每一步实际降低了多少 uncertainty。**

如果做到这一点，长任务的稳定性会明显改善。

---

## 2. 更高质量的 context

这可能是最大的收益。

今天的大模型不是单纯“context 越多越聪明”。

更多时候：

```
```

```
太多文件
+ 太多工具
+ 太多旧文档
+ 太多 grep output
=
注意力稀释
```

披露层的目标是让每一轮 working context 更像：

```
```

```
goal
+
当前 relevant evidence
+
真正有用的 tools
+
必要 files
```

而不是：

```
```

```
整个世界
```

所以最终提升可能表现为：

- &#x20;更快找到 root cause；&#x20;
- &#x20;更少误用旧 API；&#x20;
- &#x20;更少被邻近代码带偏；&#x20;
- &#x20;更少 tool confusion；&#x20;
- &#x20;更少 context compaction 后失忆。&#x20;

我会把这个指标叫：

## Context Precision

```
```

```
真正有用的 context tokens
────────────────────
进入模型的 context tokens
```

这个比单纯 token reduction 更值得优化。

---

## 3. 把昂贵 System-2 调用留给真正困难的问题

现在很多判断其实都是：

```
```

```
这个文件相关吗？
要不要再搜？
这一步有进展吗？
这个 finding 属于当前 scope 吗？
现在是不是可以结束？
```

却常常由 GPT-5.6 / Opus 这种完整 reasoning 模型来做。

如果 Reflex Runtime 能把这些判断大量吸收：

```
```

```
rules / embeddings / Jev / local classifier
```

只在：

```
```

```
高风险
高不确定
semantic disagreement
```

时才调用 frontier model。

那么 agent 的成本结构会从：

```
```

```
所有决定
  ↓
昂贵 reasoning
```

变成：

```
```

```
90% 小判断 → cheap reflex

10% 真难题 → System-2
```

这个可能比单纯节省 context token 更值钱。

---

## 4. 降低“梦游”和局部最优

我觉得这是这个项目真正可能让 agent **看起来更聪明** 的地方。

今天 agent 很常见：

```
```

```
有动作
≠
有进展
```

它会不断：

```
```

```
grep
read
edit
test
grep
read
```

所以用户看起来会觉得：

> “它怎么一直在忙，但脑子没重新想？”

Progress Reflex 如果能识别：

```
```

```
progress ↓
redundancy ↑
uncertainty 没下降
```

就触发：

```
```

```
REPLAN
```

这可能显著减少：

- &#x20;yak shaving；&#x20;
- &#x20;无限 reviewer loop；&#x20;
- &#x20;局部 patch；&#x20;
- &#x20;无效搜索；&#x20;
- &#x20;同一路径重复尝试。&#x20;

也就是说提升的是：

> **trajectory quality。**

这很难单靠更大的模型解决。

---

## 5. Completion 会更可信

今天：

```
```

```
agent says done
```

经常只是：

```
```

```
agent feels done
```

最终体系如果做到：

```
```

```
hard facts
+
semantic completeness
+
progress state
+
review evidence
```

再允许：

```
```

```
candidate_complete
```

那么用户体验会从：

```
```

```
“它说做完了，我还得自己检查”
```

变成：

```
```

```
“系统能解释为什么现在认为可以结束”
```

尤其在你的工作流里，这意味着：

- &#x20;worker 更少假 done；&#x20;
- &#x20;Director 更少重新审整轮；&#x20;
- &#x20;Validation 更精准触发；&#x20;
- &#x20;OpenSpec closeout 更可靠。&#x20;

这属于 **trust improvement**，不只是性能。

---

## 6. 最终可能变成一个真正的 agent runtime abstraction

这是长期价值最大的一点。

如果做成 backend-agnostic：

```
```

```
Predicate Registry
    ↓
Event Packs
    ↓
Policy Engine
```

以后不仅 Coding agent 能用。

同样一套：

```
```

```
relevance
sufficiency
progress
risk
uncertainty
completeness
```

可以用在：

```
```

```
Coding Agent
Research Agent
ValueHermes
Personal Assistant
Data Analyst
Browser Agent
```

只是 State Capsule 不同。

所以最终产品不一定是：

> “Codex 优化插件”

而可能是：

> **给任何 agent 增加一个 System-1 runtime。**

---

# 如果一定要给一个最核心的目标指标

我不会选：

```
```

```
token ↓
```

也不会选：

```
```

```
steps ↓
```

我会定义一个类似：

## Cost per Successful Task

或者更完整一点：

```
```

```
successful task
────────────────────────
uncached tokens
+ reasoning cost
+ tool calls
+ latency
+ human intervention
```

Reflex Runtime 真正成功应该是：

```
```

```
task success >= baseline
```

同时：

```
```

```
uncached tokens ↓
unnecessary steps ↓
wrong tool/file reads ↓
expensive reviewer calls ↓
human corrections ↓
```

而不是只追求其中一个。

---

# 我认为比较现实的潜在收益区间

这部分目前只是**工程目标，不是已有证据**。

如果做得好，我会希望真实 coding benchmark 最后看到：

```
```

```
无效 read/search        ↓ 20–40%
无价值 context          ↓ 30–60%
昂贵 reasoning/escalate ↓ 15–40%
重复/无进展 steps       ↓ 30%+
tool/file selection time ↓ 明显
solve rate              不下降，最好提高 5–10%
```

最大的胜利不是：

> “省了 40% token。”

而是：

> **在省 token 的同时，成功率反而提高。**

那就说明它真的在改善 agent cognition，而不是单纯压缩 context。

---

## 最终我会这样描述它的价值

普通 agent：

```
```

```
Think
→ Act
→ Observe
→ Think
→ Act
```

我们想做：

```
```

```
              cheap semantic reflex
                     ↑       ↓
Think → Act → Observe → State → Think
  ↑       ↓              ↑
  └──── context / progress / risk ────┘
```

也就是让 agent 从：

> **“一个不断调用工具的大模型”**

变成：

> **“一个有注意力控制、进展感知、风险感知和自我纠偏机制的运行系统”。**

如果这个东西最后只是省 20% token，我会觉得价值一般。

如果它能做到：

> **同一个模型，在长任务里更少走偏、更少重复、更晚才需要昂贵 reasoning，而且更可靠地知道什么时候该停。**

那我认为这就是一个很有价值的 agent infrastructure 项目。