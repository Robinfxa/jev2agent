# ValueHermes 模块 11：ACI 因果链遥测（机器可读轨迹）

> 状态：✅ 定稿（2026-07-03 用户评审通过；与 §12 强耦合，遥测契约以本章为准）
> 骨架定位：构件群 IV 守护构件之首、**横切契约而非事后模块**（`docs/architecture/00-master-design-book.md` §11）；北极星增补「agent-first 延伸至运行时观测」的落地章（骨架 §00 前提 1 增补）。
> 证据纪律：hermes 事实只引 `hermes-agent/` 真实本地路径（见 §9 证据索引）。用户方向输入 ×3：`docs/research/newfeature/11-aci-telemetry/agent-computer-interface-eval.md`（下称「ACI 报告」）、`docs/research/newfeature/12-inspector-agent/observer-agent-telemetry.md`（下称「observer 报告」）、`docs/research/newfeature/00-cross-cutting/25-guardian-and-cross-cutting-clusters-architecture.md` §2.1（下称「25 号报告」）。三报告的文献矩阵（vertexaisearch 跳转 / 未核验 arXiv 编号 / 厂商文档链接）按 A2 硬闸**一律不作正文依据**；OpenTelemetry GenAI 语义约定与 W3C Trace Context 均为外部标准——本章只作**命名与格式的对齐桩**，字段级逐字对照在实现期完成并入 A2 文献引用区（§1.2）。示例数值均为形状示意（no-invent）。

---

## 0. 本章定位：一条中心契约，两个消费者

**要解决的问题**：多智能体系统的因果链极长且非确定——一次共识建议穿过哨兵事件、控制面路由、蓝图 run、若干 L2 子进程、几十次 LLM/工具调用。若轨迹是给人眼看的散文日志，事后归因只能靠人肉贴日志；北极星增补要求**观测数据的第一消费者是 agent**（骨架 §00 前提 1）：轨迹必须机器可读、可查询、因果完备。

**一条中心契约，先立后用**：**业务流只携极简结论，因果链全量走遥测——两条河永不合流。** 这是骨架 §01「状态流裁剪」协议桩的本章视角：业务节点的输出契约压缩至极简结论（§05 §3.4、§07 §5.5 已锁），评分张量、回退流、辩论全文、上下文快照由捕获面收进遥测库；反方向同样成立——遥测数据绝不回流成业务输入（§12 报告隔离归档的前提）。这条契约同时是 §12 Inspector「零代码侵入」的配套前提：业务代码不为可观测性写一行日志代码，观测由底座缝合点与引擎回收点承担。

**本章边界**（已成稿章的合同前提，只对接不重定义）：

- **存储边界**已由 §03 §5 从域库侧给出建议（独立 `telemetry.db` + trace_id 关联、域库不承载高基数轨迹、权威行携带 trace_id）——本章 §5 正面定稿确认；三层存储分工（权威/过程/展示）以 §03 §2.2 为准。
- **事件侧 trace 起点**已由 §09 §3.3 定稿语义（哨兵为每事件生成新 trace_id、事件检测即根 span、`origin_trace_id` 跨链引用原决策、防篡改透传）——§09 虽为 draft，其 wake_event 信封与 trace 起点是本章的给定接缝，本章承接不重定义。
- **引擎侧义务**已由 §05 锁定：run 状态迁移必发遥测事件（§05 §4.1）、检查点携带 trace_id（§05 §4.3）、trace_id/span 随节点输入注入 L2 且节点与引擎均不得清洗（§05 §3.4）；「span 穿 CLI 进程边界的机制」是 §05 未决 #9 留给本章的正面作答义务（§3.3）。
- 遥测的**消费侧行为**归 §12（Inspector 怎么用）与 §13（评测怎么用）；本章止于「数据怎么产生、怎么落、怎么被只读查询」。

本章七件事：Frame Lifetime Trace 契约（§1）；OTel SDK 依赖裁定（§2）；trace/span 传播全链与防篡改（§3）；捕获面与 hermes 缝合点核对（§4）；写入拓扑（§5）；独立遥测库（§6）；AOI 只读查询接口形态裁定（§7）。三态、证据、未决随后（§8-§04）。

---

## 1. Frame Lifetime Trace 契约

### 1.1 span 模型与 frame 分类

ACI 报告的核心概念：每次迭代（Step）、工具调用、参数传递、上下文快照封装为 Frame Lifetime Trace（ACI 报告 §1）。本章落为统一 span 模型——**一行一 span，event 是零时长 span**，不建两套表：

```text
span = {
  trace_id, span_id, parent_span_id,   -- W3C 三元组（§3）
  kind,          -- frame 分类枚举（下表）
  name,          -- 种内命名（工具名 / 节点 id / 状态迁移名…）
  start_ts, end_ts, status,            -- event 型行 end_ts = start_ts；
                                       --   status: ok | error | timeout | canceled
  attrs,         -- 结构化属性（命名对齐 gen_ai.*，§1.2）：model、token 用量、
                 --   tool 名、audit_label（§4.4）、run_id、node_id、
                 --   blueprint_id+version、账别、decision_id（若关联）…
  error_ref,     -- 结构化错误对象引用（§1.4，可空）
  blob_refs      -- 大对象 handle 列表（§1.3，可空）
}
```

**frame 分类（kind 枚举）与产生方**：

| kind | 语义 | 产生方（§4/§5 的捕获拓扑） |
|---|---|---|
| `turn` | 主体一次用户轮（对话研究生命周期的根 span） | 主体侧捕获 hooks（gateway 进程） |
| `run` | 一次蓝图执行（PENDING→终态全程） | 引擎（自研构件直写） |
| `node` | 一个节点的派发→回收 | 引擎 |
| `llm_call` | 一次 LLM API 往返 | hermes hooks（主体侧 + L2 侧） |
| `tool_call` | 一次工具执行 | hermes hooks（同上） |
| `prefetch_compose` | 一次 `PrefetchComposer` 记忆预取合成（收集→排序→预算→冲突消解→渲染，§10 §9.1-§9.2） | 主体侧插件直写（`ValueHermesMemoryProvider`/`PrefetchComposer` 自研构件；hermes 无原生 hook 包裹，同 `run` kind「自研构件直写」产生方，§1.8） |
| `state_event` | run 状态迁移 / 挂起 / 恢复 / 取消（§05 §4.1 义务） | 引擎（event 型） |
| `event_receipt` | §09 事件送达控制面（事件链首个落库 span，§3.1） | 控制面（event 型） |
| `checkpoint` | 检查点写入（§05 §4.3） | 引擎（event 型） |
| `persist` | 权威落库动作（账本行 / 阈值行写入，携 decision_id） | 引擎（event 型） |
| `process_meta` | 引擎回收时剥离的业务过程层附件（评分张量 / 回退流 / shadow 对比，§4.1） | 引擎回收点 |
| `audit` | §12 Inspector 审计会话自身的轨迹（§12 §4.5） | 审计触发器 + L2 侧 hooks |
| `error` | 独立错误事件（无宿主 span 的异常，如插件自身故障） | 各捕获面 |

六条生命周期（骨架 §01 总览表）的 trace 根映射：对话研究 = `turn`；定时任务 / 挖掘扫描 = 控制面为每次 `cron_tick` 派发生成的 `run` 根；漏斗决策 = 触发它的 `turn` 或 cron 根的子链（§3.2）；跨域深挖 = 所属 run 内的动态节点 span（不另起 trace——hop 因果留在同链）；事件触发紧急重估 = 哨兵生成的事件根（§09 §3.3，本章承接）。

### 1.2 OTel GenAI 对齐桩（命名对齐，非依赖对齐）

骨架 §11 桩要求「对齐 OpenTelemetry GenAI 语义，`gen_ai.*`」。本章把这条承诺精确化为**两层承诺**：

- **结构承诺（本章即锁死）**：span 三元组（trace_id/span_id/parent_span_id）、span 生命周期字段（start/end/status）、属性挂 span 的组织方式——这是 W3C/OTel 模型的骨架，也是 §12 因果重构的最低依赖，进合同。
- **命名承诺（对齐桩，实现期定稿）**：`attrs` 内 LLM 相关字段（操作名、请求模型、token 用量、工具名等）采用 `gen_ai.*` 命名族——**具体字段名逐字对照 OTel GenAI semconv 后定稿**。理由：该 semconv 是外部标准且仍在演进，A2 硬闸「标外部文档来源的断言未经本地复核不得进正文」在标准文本上的对应纪律就是：本章不凭记忆抄写字段名清单，实现期对照当版规范落字段表、入 A2 文献引用区。对齐的收益是词汇通用性（未来任何 OTel 兼容工具可理解本库导出），不是工具链兼容性（§2 裁定不引 SDK）。

**内部 canonical vs 外部 alias 的分层（本轮复核补强）**：OTel `gen_ai.*` 的字段级定稿推到实现期**只约束 export / 互操作命名，不是内部唯一主家**——§13 回归评测（模型/provider 换档、tool call、cache token 命中率、成本断言）与 §18 冷前缀 token 经济（cache read/write token、命中监控）已在承重 token/model/tool/cache 字段，不能等 OTel semconv。故本章立**内部 canonical attrs `valuehermes.llm_attrs_v1`**——span attrs 的稳定内部字段名，AOI 查询 / evaluation.db 历史 / 成本回归一律以此为准：

```yaml
valuehermes.llm_attrs_v1:            # 内部 canonical（查询/评测/成本回归主家；字段级形状示意 no-invent）
  model_id / provider_id / request_hash
  prompt_tokens / completion_tokens / total_tokens
  cache_read_tokens / cache_write_tokens / cache_hit_status(hit|miss|partial|unknown)
  tool_id / tool_result_status(success|failed|blocked|unavailable|null) / tool_schema_version
  llm_call_role(subject_response|l2_node|judge|inspector|summarizer)
  cost_accounting_class(user_visible|background|eval|debug)
```

分层纪律：**`valuehermes.llm_attrs_v1` = 内部查询/评测/成本回归 canonical；`gen_ai.*` = export alias / 兼容映射**（导出时按上款命名映射、实现期对当版 semconv 定稿）。防「OTel 改名 → AOI 查询漂移 / provider 字段不一 → token 不可比 / cache 字段不统一 → 成本回归失真」。该字段族被 §13 回归 / §18 token 经济消费、进 §15 §1.2-10 三库 schema smoke 探测。

### 1.3 大对象 handle + 结构保留预览

高基数轨迹的第一杀手是大 payload 内联：上下文快照、工具原始返回、辩论全文若逐字进 span 行，遥测库膨胀且查询面被拖垮；全部丢弃又断了 drilldown。契约：

- **content-addressed blob**：超过内联阈值（配置项，KB 量级形状）的对象以内容哈希（如 sha256）为键落 blob 存储，span 行只存 `{hash, size, content_type, preview}` handle。同内容天然去重（同一份上下文快照被多个 span 引用只存一次）。
- **结构保留预览**的定义（「预览」不是掐头去尾的散文截断）：JSON 对象保留全部 key、值按类型截断并标注（字符串截断标 `…(n chars)`、数组截前 k 项标 `…(n items)`）；纯文本头尾各留窗口、中间标省略长度。预览的目的：让查询 agent 不取 blob 就能判断「这个对象是不是我要深读的」——AOI 的上下文经济学（§7）。
- **blob 落位两候选**：库内 blobs 表（单文件备份一致性好、content-addressed 去重简单，基线）；超大对象（MB 级形状）外置文件目录 + 行存路径（防库文件失控）。阈值实现期定（未决 #3）。
- **§18 冷数据 digest 的承载**：§18 冷数据经济区的 digest 是「携原文 handle 的浓缩件」——digest 本身入业务上下文，其**原文/大对象**经本节 content-addressed handle + 结构保留预览引用，§12/主体需精确核对时按 handle 下钻回原文（消费侧兑现同 §7 护栏，取本体是显式第二次调用）。digest 的运行埋点（缓存命中率 / digest 复用次数 / §18 §5 delta 门控跳过率）按 §11 §1「因果链全量走遥测」落遥测宽表 span 的 attrs（数值形状示意 no-invent）——这正是 §18 §6「无声降级留痕」在治理侧的兑现（防降级/退化在治理层漏账）；**命中率长期偏低本身是 §12 Inspector 的归因信号**（cache 失效 / 冷数据 churn 过高），埋点是材料层观测量，不进任何决策权重。

### 1.4 结构化错误对象契约

骨架 §11 桩点名「结构化错误对象」。与 §05 §2.2 的分工先说清：`on_failure` 熔断上报给**业务流**的是压缩结构化摘要（错误类别 + 最后一次失败原因，不带原始堆栈也不空白）——那是给下游节点与控制面看的；**遥测侧存完整版**：

```text
error_object = {
  error_class,     -- 枚举族：tool_error | llm_api_error | contract_violation
                   --   | timeout | budget_exhausted | node_crash | engine_error
  error_code,      -- 系统级 canonical error_code（valuehermes_error_code_v1，§1.7；
                   --   本轮复核补强——error_class 是遥测局部粗分类，error_code 是
                   --   跨层可聚合坐标，两者并存、不互相取代）
  message,         -- 一句话（机器可读优先，禁散文堆砌）
  origin,          -- {run_id, node_id, tool 或 provider 名}
  retriable,       -- 布尔 + 已重试次数
  ts, span_id,     -- 因果锚
  detail_ref       -- blob handle：完整堆栈 / 原始 API 错误响应 / 坏 shape 原文
}
```

两边由 span_id 关联：业务流的摘要极简可路由，遥测的对象完整可归因——「调试 agent 拉取死锁前动作序列」（ACI 报告 §1 AOI）拉到的就是这张错误对象链 + 其宿主 span 时间线。

### 1.5 Telemetry PII 分类（本轮复核补强）

§4.1 双源捕获（hooks 通用轨迹 + 引擎回收业务过程层）对任意工具调用/节点产出一视同仁地捕获 attrs/blob——若上游数据本身携带用户持仓、券商导入摘要、行为诊断结果，捕获面不会自动分辨敏感度。本节补一张遥测侧 PII 分类表，枚举值对齐 §03 已定案账别（no-invent：不发明新维度，直接复用既有承载物边界）：

```yaml
telemetry_pii_classification:
  public_market_data: backup_allowed
  user_declared_portfolio: backup_allowed_with_manifest
  high_sensitive_broker_import: raw_forbidden_in_telemetry_blob   # 对齐 §03 承载物 #15
  derived_behavior_profile: redacted_summary_or_handle_only        # 对齐 §03 承载物 #14
```

纪律：`high_sensitive_broker_import`（§03 #15）与 `derived_behavior_profile`（§03 #14）二类**不得以原始内容写入遥测 blob**——即便 §1.3「结构保留预览」机制对一般大对象生效，涉及这两类账别的 span/blob，预览本身也必须先脱敏或只留 handle（不可只做长度截断、任由原文片段暴露）；capture 面（§4.1）为 §03 §3.6 行为诊断流水线相关的 `tool_call`/`node` span 落 attrs/blob 时适用同一纪律。`backup_allowed`/`backup_allowed_with_manifest` 两档描述的是 `telemetry.db` 自身随 HERMES_HOME 进普通备份（§6.3）时该类内容片段是否可被覆盖，不改写 §03 已锁的账别物理备份边界（§03 §1.2：#15 账别本身默认不进普通备份，是更上游的账别隔离；本条只补遥测这一条捕获/落库路径的对应义务）。**冷前缀缓存不豁免本表分类（本轮复核补强）**：§18 §4 静态前缀缓存机制、复用纪律见 §18 §6——冷前缀落进断点区被跨调用复用，是效率机制不是分类豁免；`high_sensitive_broker_import` 与 `derived_behavior_profile` 默认排除出冷前缀缓存范围，不因「更新一次、复用千次」的成本收益而绕过本节 PII 分级。分类表是唯一真相源，缓存布局层不得自行判断内容是否敏感。

### 1.6 `epistemic_distribution` span attrs（本轮复核补强，答 §17 Detection 的遥测硬化缺口）

§17 Detection + Quarantine 回路依赖历史认知方差序列判定蓝图是否腐烂（§13 §3.7「`epistemic_variance` 即 §13 三维评测认知维度、§17 Detection 料源」已锁记录侧语义），但落到运行时 span，逐路方向分布此前仍是「向 §11 提交埋点需求」的接缝文字，未硬化为 mandatory 字段。本节收口：

```yaml
epistemic_distribution:
  enabled_for:
    - multi_lane_decision
    - shadow_compare
    - decay_monitoring
  fields:
    - lane_id
    - verdict
    - confidence
    - action_temperature
    - distribution_hash
```

落位：挂在触发场景对应的 `node`/`run` span attrs 上（§1.1 kind 枚举不新增 kind，本字段是既有 span 的 attrs 扩展，同 §1.2 命名对齐桩的组织方式）——仅当该 span 归属 `multi_lane_decision`/`shadow_compare`/`decay_monitoring` 三类触发场景时才携带，非全量 span 强制字段（避免无意义空字段污染宽表）。与 §13 `epistemic_variance`（Monte Carlo 重放的聚合方差指标，§3.7）是同一认知维度量纲的两个层次：本字段是**单次 span 的逐路分布明细**，`epistemic_variance` 是其**批次聚合结果**——两者不是两套指标，聚合值可由分布明细算出（本节只锁明细字段存在，聚合公式归 §13/§17）。缺失时的处置（`decay_monitoring` run 不得因此 silent no-op）是回归评测侧的 Tier-1 断言，归 §13 §2.1（本节只锁 telemetry 侧字段合同）。

### 1.7 `valuehermes_error_code_v1`：系统级 canonical error_code（本轮复核补强，答跨层错误/降级坐标统一缺口）

问题：本章 §1.4 的 `error_class` 是遥测局部枚举（`tool_error`/`llm_api_error`/…）。跨章各有本地降级/失败语汇——§04（`_unavailable`/fallback exhausted/stale/provider unavailable）、§05（`on_failure`/`fallback_ref`/`all_failed_degraded`/timeout/cancel）、§10（`OmittedCandidate.reason`/source unavailable/token budget omitted）、§13（eval replay unavailable/judge failed/insufficient evidence）、§16（asset hash mismatch/manifest missing/feature flag disabled）——都合理，但 Inspector / eval / 用户呈现需要跨层回答「这次为什么降级：数据不可用还是工具被禁、provider quota exhausted 还是 token budget omitted、蓝图 fallback 还是 Prefetch 未选进 prompt」；局部字符串各写各的，归因面无法聚合、降级回归无法统一断言。

裁定：新增系统级 canonical `valuehermes_error_code_v1`，每个错误码至少携带：

```text
error_code          -- 字符串，唯一码
namespace           -- DATA | TOOL | BLUEPRINT | PREFETCH | TELEMETRY | EVAL | ASSET | SECURITY | CONFIG
severity            -- info | warning | error | fatal
retryable           -- true | false | maybe | after_period
user_visible        -- true | false | maybe
affects_authority   -- true | false | audit_only | eval_only | maybe
suggested_recovery  -- 字符串
```

已知码示例（no-invent——数值/枚举照源文档给定，非本章发明；未列出的错误码在实现期按同一 taxonomy 补 registry，不在本章猜测）：

| error_code | namespace | severity | retryable | user_visible | affects_authority |
|---|---|---|---|---|---|
| `DATA_PROVIDER_UNAVAILABLE` | DATA | warning | true | true | true |
| `DATA_STALE` | DATA | warning | maybe | true | true |
| `DATA_QUOTA_EXHAUSTED` | DATA | warning | after_period | true | true |
| `TOOL_FORBIDDEN_BY_POLICY` | TOOL | warning | false | maybe | false |
| `BLUEPRINT_NODE_TIMEOUT` | BLUEPRINT | error | maybe | maybe | true |
| `BLUEPRINT_FALLBACK_EXHAUSTED` | BLUEPRINT | error | maybe | true | true |
| `PREFETCH_TOKEN_BUDGET_OMITTED` | PREFETCH | info | false | false | maybe |
| `TELEMETRY_TAIL_GAP` | TELEMETRY | warning | false | false | audit_only |
| `EVAL_INSUFFICIENT_EVIDENCE` | EVAL | warning | maybe | false | eval_only |
| `ASSET_HASH_MISMATCH` | ASSET | fatal | false | maybe | true |

规则：

- 各章保留本地 reason（`error_class`、`on_failure` 原因、`OmittedCandidate.reason` 等不删、不强改名）；
- 落 telemetry（本章 `error_object.error_code`，§1.4）/ eval / audit / user-facing degradation 时，必须同时携带映射后的 canonical `error_code`；
- 各业务章 local reason → canonical `error_code` 的映射表是各业务章自己的作业（seam，不在本章展开，归各业务章 + §13 + §15）；
- 未知错误码不得进入 live formal run，只能以 `INTERNAL_UNCLASSIFIED_ERROR` fail-closed（该码完整字段值与 namespace 归属实现期定，本章只锁「未知码 = fail-closed」这条纪律，不发明其完整字段值）。

`TELEMETRY_TAIL_GAP` 与 §5.5 run 级 `telemetry_commit_status = tail_gap` 是同一语义在两个坐标系的表达——`error_code` 侧用于跨层聚合展示/归因，`commit_status` 侧用于 §03 `run_commit_marker` 的镜像字段（§03 §4.5）；两者不是重复建模：一个是错误分类坐标，一个是收口状态坐标，值上应保持对应（`tail_gap` 状态若伴随一个 error span，该 span 的 `error_object.error_code` 应为 `TELEMETRY_TAIL_GAP`；纯记录性的 `tail_gap` 状态本身不强制每次都伴随 error span——归 §5.5，本节只锁两坐标的语义对应关系）。

本节新增字段与规则归本章（§11）canonical；各业务章 local→canonical 映射、§13 降级回归聚合、§15 unknown code fail-closed 部署校验——归各自章节（seam）。

### 1.8 `prefetch_compose` frame attrs（本轮复核补强，答 §10 PrefetchBundle 遥测缺口）

问题：§10 §9.1 `PrefetchBundle`（`selected_candidates` / `omitted_candidates` / `conflict_notes` / `staleness_notes` / `rendered_prefetch_text` / `provenance_manifest`）此前「对 hermes 只输出 rendered_text、内部留审计」；§13 `golden_trace_replay_v1` 已把 `prefetch_bundle_ref` 纳入回放输入快照（`input_snapshot_manifest` 字段之一，承重证据），但 §1.1 kind 枚举无对应 frame、bundle 未落 telemetry——本节收口（§1.1 已加 `prefetch_compose` 行）。

裁定：`prefetch_compose` 落 attrs：

```yaml
prefetch_compose_attrs:            # 挂 prefetch_compose kind span（形状示意，字段级 no-invent）
  bundle_hash         -- 内容寻址（同 §1.3 content-addressed 键族），§13 golden_trace_replay_v1
                       --   `prefetch_bundle_ref` 回放固化引用的目标
  selected_count      -- selected_candidates 条数
  omitted_count       -- omitted_candidates 条数
  conflict_count      -- conflict_notes 条数
  staleness_count     -- staleness_notes 条数
  blob_ref            -- 完整 PrefetchBundle（selected/omitted candidates + conflict/staleness notes
                       --   + provenance_manifest）经 §1.3 大对象 handle 存储；span 只留 handle+结构
                       --   保留预览，取本体是显式第二次调用
```

写入方：`ValueHermesMemoryProvider`/`PrefetchComposer` 自身（§10 §9.1 已定「全在 provider 插件内」）——hermes 无原生 hook 包裹 memory provider `prefetch()` 调用（§4.2 VALID_HOOKS 清单无对应项），故本 kind 走「自研构件直写」产生方（同 `run` kind 先例，§1.1），非 hooks 捕获；写入仍落 §5.1 gateway 进程内单写者路径（Composer 只在 gateway 进程内运行，§10 §9.1 「L2 节点默认零 prefetch」——不涉 §5.2 spool）。§10 §9.2 提及的细粒度事件名（`prefetch_request_received`/`source_called`/`candidate_omitted`/`conflict_resolved`/`bundle_rendered`/`source_failed`）是本 frame 内部阶段的可选补充观测（可挂同一 span 的 attrs 或作其子 event span，粒度与落位归实现期）；本节只锁 bundle 级汇总字段为 mandatory。

PII 纪律：bundle 若含 §1.5 高敏账别派生材料（对应 §10 §9.1 `PrefetchCandidate.sensitivity_class` 的 `user_thesis`/`user_portfolio`/`behavior_derived`/`broker_derived`），blob 预览同受 §1.5 强制脱敏纪律约束，不因「内部审计」豁免。

### 1.9 Source policy 与 report/evidence refs 的 trace attrs（扩展既有 attrs，非新 frame kind）

§04 §8.7 来源治理与 §14 §7 报告证据链要求过程轨迹回答「本次实际选了什么来源、排除了什么、为什么、按哪份生效策略」与「产出的报告绑了哪些 refs」。**落法 = 扩展既有 frame 的 attrs，不因命名便利新增 frame kind**：

- **`tool_call` attrs 增列**（膜工具调用面——DataResult `meta.source_policy` 的遥测镜像，§04 §8.7 条五）：`source_policy_snapshot_id + policy_hash`（§16 §2.3 子快照）、`selected_source_refs`、`excluded_selector_count` + `exclusion_reason_families`（§04 §8.7 同源 `reason_family+reason_code(+gate_id)` 结构的计数分布）、`fallback_decision_refs`；明细列表大对象走 §1.3 handle。
- **`prefetch_compose` attrs 增列**（§1.8 既有 frame）：`source_policy_denied_count`（compose 前被策略剔除的候选数——§10 §9.2 `OmittedCandidate(reason=source_policy_denied)` 的汇总镜像）、`source_policy_snapshot_id`。
- **`run`／`process_meta` attrs 增列**：`source_policy_snapshot_id + policy_hash`（run 级生效策略）、`report_id` + `claim_count` + `evidence_ref_count`（报告收口 run 的 manifest 摘要镜像——manifest 本体权威在 §03 承载物 #20，本库只留过程指纹）、`evidence_coverage_status`（full｜partial_evidence_coverage｜evidence_blind_spot——payload 截断、TTL 过期或未捕获时置 partial/blind_spot，**不得置 full 冒充完整**）。
- **永久轻量 manifest 的主家仍是 §03（承载物 #20）**：本库只拥过程轨迹与 blob/TTL——manifest 引用的重型 payload 过期后，本库如实呈现缺失（blind spot），审计完整性由 §03 manifest 的 hash + 最小 provenance 承担（§03 §5 边界合同）。

字段级 schema 与采样/保留细部归实现期（未决 #11）。

> 🔴 **supersede 注（2026-08-03，W9-B γ0 Scope/Profile 终裁 · readiness plan §13.21-K）**：上句「未决 #11」为**归属错配**——§10 的未决 #11 正文是 `telemetry_commit_status` **摄入判定细节**且尾注回指 §5.5（本文件 §10 第 11 条），与本节（source policy / report·evidence refs 的 trace attrs）无关；§10 清单十一条中**无**以 §1.9 为归属的条目。**上句历史原文逐字保留**；其待定项自本注起改归 **「telemetry attrs physical schema / γ0 后续扩展」**——即：γ0（`impl-w9b-gamma0-telemetry-authority-cnp`）只封闭 `attrs_json` 作为**开放式结构**的物理载体，本节这组 attrs 的**字段级 schema** 属 γ0 之后的独立扩展面，须另立 change 与 Gate，🔴 不得在 γ0 内自造。

---

## 2. OTel SDK 依赖裁定（ponytail 正面作答）

25 号报告 §2.1.1 的表述——「子进程的 OpenTelemetry 探针原生提取该变量」——隐含底座已有 OTel SDK。**本地事实：hermes 依赖清单零 OTel**（`hermes-agent/pyproject.toml` 全文无 opentelemetry/otel 条目；依赖方针为 exact-pin + 最小 scope，`pyproject.toml:24-45`，§09 §2.2 已引同款证据）。因此「要不要为遥测引入 OTel SDK」是本章必须显式过 ponytail 的裁定：

| 需求轴 | OTel SDK 提供什么 | 本系统要什么 |
|---|---|---|
| 导出 | OTLP 协议、云后端集成、采样器生态 | **无买主**——遥测禁止强制推送云端 SaaS（骨架 §00 前提 2），全量落本地 SQLite |
| 传播 | 跨服务上下文传播器（HTTP header 等） | 只需环境变量携带一个定长字符串（§3.3）——stdlib 字符串操作可解析生成 |
| 语义 | gen_ai.* 命名约定 | **命名抄得起，不需要运行时**（§1.2 词汇表对齐） |
| 依赖面 | SDK + API + exporter 多包 | 底座供应链方针 exact-pin、最小 scope（`pyproject.toml:24-45`）；遥测写入模块要进主体插件、引擎、每个 L2 子进程——是发行配置里铺得最开的代码 |

> **裁定：不引 OTel SDK。自研 stdlib 遥测写入共享模块**（`sqlite3` + `json` + `os`），作为发行配置内共包由主体插件、引擎、L2 节点侧共用同一实现——§09 §1.1「同源复制纪律」的遥测版，防多侧协议漂移。**OTel 对齐是词汇表对齐，不是依赖对齐。** 升级候选（记录不承诺）：远端部署封存接口解封、需要 OTLP 导出时再引 SDK——届时 §1.2 的命名对齐使迁移是搬运不是重写。

**对 25 号报告的形状修正（诚实标注）**：「子进程 OTel 探针原生提取 TRACEPARENT」在零 OTel 底座上不成立——提取者是**我们的插件启动序列**（§4.2 已证插件在 `chat -q` 子进程内加载）。报告的传播方案（环境变量注入、避免 STDIN 污染）全盘采纳，载体修正为自研共享模块。

---

## 3. trace/span 传播全链定稿

### 3.1 三类 trace 根

| 根 | 生成方 | 语义 |
|---|---|---|
| **用户请求** | 主体侧捕获面在每个用户轮开一个 `turn` 根 span | 对话研究生命周期；同一任务的多个 turn 以 attrs 内 session/task 标识关联（软关联，不并 trace——每 turn 一 trace 保持树浅、查询窄；task 级聚合是查询侧视图，未决 #7） |
| **cron tick** | 控制面为每次 cron 触发的派发生成 `run` 根 | 定时任务 / 挖掘扫描生命周期 |
| **§09 事件** | **哨兵生成 trace_id，事件检测即根 span**（§09 §3.3 定稿承接） | 事件触发紧急重估生命周期；`origin_trace_id` 跨链回指产生阈值行的原决策 trace——两条链经这对引用双向可达，不续用原链（时序语义保真，§09 已论证） |

哨兵自己**不写遥测库**（§5.3）：事件根的第一个落库 span 是控制面的 `event_receipt`（trace_id 取自事件 payload，`tick_ts`/`detect_ts` 双时戳原样入 attrs——检测时刻的真相由 §09 信封字段保真，不靠哨兵写库）。

### 3.2 异步链的延续：execute_blueprint 与挂起恢复

- 主体经 `execute_blueprint` 提交的 run **延续同一 trace**：run span 的 parent = 提交时的 `tool_call` span。P1 排队等待表现为父子 span 的时间间隙——排队延迟不需要专门字段，时间线自明。
- 挂起/恢复不换 trace：SUSPENDED 期间无 span 产生，恢复后节点 span 照常挂原 run span 下；挂起原因（事件 id）在 `state_event` attrs 里指向触发事件的 trace_id（跨链引用，`origin_trace_id` 同款语义）——§12 由此能回答「这个 run 为什么中断了 40 分钟」。
- 紧急蓝图 B 的 run 挂**事件根**下（§3.1 第三行），被挂起的标准 run 留在自己的 trace 里——两条 trace 经挂起 `state_event` 的跨链引用互指。

### 3.3 跨进程注入：W3C Trace Context 环境变量（§05 未决 #9 正面作答）

> **裁定：引擎拉起 L2 子进程时注入 `TRACEPARENT` 环境变量（W3C Trace Context 格式：version + trace_id + parent_span_id + flags 的定长连字符串）；`TRACESTATE` 预留字段名、默认不设**——本系统无多厂商链路状态可传，设空字符串徒增解析义务（诚实不用比形式合规更重要）。字节级格式实现期对照 W3C 规范定稿（A2 文献引用区同 §1.2 纪律）。

理由与纪律：

1. **与 HERMES_HOME 显式传播同纪律、同注入点**：§03 §4.4 已锁「引擎拉起 L2 必须显式传 HERMES_HOME」，§05 §3.1 的两档配置注入都经环境变量面——TRACEPARENT 就是在同一个 spawn 调用里多一个 env 条目，零新机制。§15 部署铁律清单相应加一行：**凡拉起 L2 的代码路径，HERMES_HOME 与 TRACEPARENT 必须同批注入**（漏 trace 注入的节点产出将成为因果孤儿，蓝图加载校验管不到运行时，靠 spawn 封装单点化保证——引擎拉起代码只有一处，§05 §3.1）。
2. **避免 STDIN/argv 污染**（25 号理由采纳）：L2 的 `-q` 参数与输入文件是**任务输入通道**（§03 §6 统一挂载点协议），混入控制流元数据会污染输入契约、且暴露在进程列表里。环境变量是进程级带外通道，与任务数据物理分离。
3. **deterministic 节点**（§05 §3.1 两型之一）同进程直执行——span 上下文经内存直传，无需环境变量；两型节点在遥测里的 `node` span 形态一致，消费方无感。

**义务收拢表**（骨架 §01 协议桩「trace/span 传播 + 防篡改」的全链兑现）：

| 环节 | 义务 | 出处 |
|---|---|---|
| 哨兵 | 事件生成新 trace_id + origin_trace_id 跨链引用；零遥测写 | §09 §3.3（承接） |
| 控制面 | 事件送达记 `event_receipt`；派发 run 时把 trace 上下文交引擎 | 本章 §3.1 |
| 引擎 | spawn 时注入 TRACEPARENT（与 HERMES_HOME 同批）；回收时关闭 `node` span；落库时向域库权威行原样透传 trace_id | 本章 §3.3；§03 §5（已锁） |
| L2 节点 | 插件启动序列读 TRACEPARENT 接续父链；**不得生成新 trace_id 顶替、不得清洗上游三元组**；进程内全部 llm/tool span 挂父链下 | §05 §3.4（义务已锁，本章给机制） |
| 域库 | 权威行携带 trace_id + 产生 span_id 作跨库关联键 | §03 §5/§8（已锁） |

### 3.4 防篡改纪律正文化

observer 报告 §四「业务节点不得清洗上游 trace_id、底层数据不被业务层摘要篡改」落为四条工程形态 + 一条显式不做：

1. **真相源分离（结构性防篡改的核心）**：遥测行的 trace 三元组由**捕获面从进程环境 / 引擎运行态注入**，永不取自业务 payload——节点即使在输出 JSON 里伪造 trace 字段，也影响不了遥测行（捕获 hook 根本不读那个字段）。控制流真相走带外通道，数据流走业务通道，两不相认。
2. **append-mostly**：遥测访问模块只暴露 append 与只读查询，无 UPDATE/DELETE 常规面（唯一例外是 §6.3 的 TTL 轮转整段淘汰）；「审计结果的可信」首先来自「写过的行改不了」。
3. **分库只读授权**：Inspector/评测对遥测库按库文件粒度只读（§03 §5 分库红利、§03 §4.4 权限表已锁；连接级只读机制见 §12 §3.2）。
4. **合同义务链已锁**：引擎/节点不清洗（§05 §3.4）、落库透传（§03 §5）——本章不重立，只指认。
5. **显式不做（ponytail）**：不建哈希链/数字签名类密码学防篡改。威胁模型是 bug 与 LLM 幻觉，不是恶意攻击者——本系统全部进程运行在用户本机同一信任域（本地优先不变量的推论）；密码学完整性是跨信任域工事，此处只有成本没有敌人。**封存注记**：远端部署封存接口解封（信任域出现网络边界）时，本条与 §12 §3.2 的 OS 级隔离一并重估。

---

## 4. 捕获面：状态流裁剪的遥测侧（hermes 缝合点核对）

### 4.1 双源捕获模型

「底座中间件捕获」（骨架 §01 协议桩）在结合方式 A 上的准确实体是**两个捕获源**，各管一半：

- **hermes hooks/middleware（通用轨迹）**：LLM 调用、工具调用、会话生命周期——凡 hermes agent 进程内发生的事，由插件注册的 hooks 捕获成 `llm_call`/`tool_call`/`turn` span。主体（gateway 进程）与 L2（`chat -q` 子进程）**同一插件、同一捕获代码**（§4.2 可行性证据）。
- **引擎回收点（业务过程层）**：评分张量、回退流、辩论逐轮全文、shadow 对比、菜单 override status——这些不是「调用轨迹」而是节点输出里的过程层附件，hermes hooks 看不见其语义。捕获点 = 引擎回收/合并步骤（§05 §3.2 第 3 步）：按 §07 §5.5 的 raw/bucketed 分离清单剥离过程层字段 → 落 `process_meta` span（blob handle 承载大件）→ 权威层零携带。**过程层字段清单以各漏斗章定稿为准**（§07 §5.5 四分离落位表是首个实例），本章只立剥离动作的统一落点。

### 4.2 hooks 面核对：缝合点存在且覆盖 L2

骨架 §11 剩余待答「与 hermes 回调面/hooks 缝合点」，本章核对完毕：

1. **hooks 清单**：`pre_tool_call`/`post_tool_call`、`pre_llm_call`/`post_llm_call`、`pre_api_request`/`post_api_request`/`api_request_error`、`on_session_start/end/finalize/reset`、`subagent_start/stop` 等（`hermes-agent/hermes_cli/plugins.py:135-213` 全清单）——工具与 LLM 往返的前后沿配对齐全，`tool_call`/`llm_call` span 的开合有原生锚点。
2. **hooks 在 L2 子进程内生效的直接证据**：kanban hooks 的进程注记明言「kanban workers run as separate `hermes -p <profile> chat -q` subprocesses」且 `kanban_task_completed` 在 **WORKER 进程**触发（`plugins.py:188-208`）——插件 hooks 活在 `chat -q` 子进程里是底座的既有工程事实，不是本书假设。加固证据：CLI agent 命令启动序列显式跑插件发现——`_AGENT_COMMANDS = {None, "chat", "acp", "rl"}` 且 `_prepare_agent_startup` 对其调用 `discover_plugins()`（`hermes-agent/hermes_cli/main.py:12027,12055-12068`）。
3. **middleware 面**：`tool_execution`/`llm_execution` middleware 可**包裹执行本体**（「Observer hooks report what happened. Middleware can change what happens by … wrapping the actual execution callback」，`hermes-agent/hermes_cli/middleware.py:1-34`）。**基线用 observer hooks**（零改写风险、语义就是「报告发生了什么」）；若实现期发现 pre/post 配对在异常路径漏边（如工具抛异常时 post 不触发），升级到 execution middleware 包裹计时——机制已核存在，按需启用（未决 #4）。
4. **AIAgent 构造回调族不可用**：构造签名带全套回调（tool_start/tool_complete/thinking/step/stream_delta/event_callback…，`hermes-agent/run_agent.py:426-498`），但它们是**宿主构造参数**——gateway 构造会话 agent 时不暴露插件注入缝（§10 §12 已核构造链）；`event_callback` 现役发射面也只见压缩事件（`agent/conversation_compression.py:879`）。捕获面裁定走 hooks/middleware，不走回调族。
5. **save_trajectories 复用否决（ponytail reuse 档显式过）**：hermes 原生有轨迹保存——但形态是 ShareGPT 训练样本 JSONL（`conversations` 数组 + model + completed，append 到 cwd 相对的 `trajectory_samples.jsonl`，`hermes-agent/agent/trajectory.py:31-56`；`run_agent.py:1927-1940` 调用点）——无 trace 结构、无时序字段、无落位纪律，是**训练数据采集面**不是因果遥测。判定：不复用、不冲突（默认 False，两面并存互不相扰）。**风险声明（本轮复核补强）**：`save_trajectories` 若被误开启，其导出面完全**绕开**本章遥测治理——不经 §1.5 PII 分类、不经 §1.3 blob handle/脱敏预览、不经 §6.3 TTL 分级保留、不经 §03/§04 高敏账别隔离，是一条独立于 `telemetry.db` 之外、零治理钩子的原始导出通道；若会话涉及 §03 #15/#14 高敏材料，原始对话内容可能整段写入该 JSONL 而不受本章任何脱敏/裁剪纪律约束。本章判定止于机制层面的「不复用、不冲突」；`save_trajectories` 在 ValueHermes profile 中的默认值强制关闭与相应部署铁律归 §15（Director 侧接缝）。
6. **ATOF/ATIF 复用否决（reuse 审计对称补齐）**：hermes 另有第二套机器可读轨迹导出——`nemo_relay` 观测插件把 observer hooks 映射为 NeMo Relay 的 **ATOF**（Agent Trajectory Observability Format：append-only JSONL 事件流，带 timestamp / session_id / tool_call_id / scope 边界与 parent·child·subagent 关联键）与 **ATIF**（`ATIF-v1.7` 收口后可回放轨迹，一会话一份），载体 `hermes-agent/plugins/observability/nemo_relay/`（机制转引底座考古册 `modules/08-observability-and-trajectories.md` §3.3）。**判定：ATOF 概念上是现成事件源，但落盘/序列化载体不复用，自研 per-run JSONL spool（§5.2）**——三条理由：① **依赖与可靠性**：ATOF 导出依赖 `nemo-relay` 运行时且是 opt-in 观测插件，缺运行时 fail-open 静默不导出、`--ignore_user_config` 会跳过 enabled 状态——把全书承重的遥测面架在一个可静默 no-op 的第三方插件上违反「第一个 sprint 即埋点」的可靠性铁律（§6.4）；② **schema/TTL 自管**：ATOF 是 NVIDIA canonical 事件格式，本章要的是自控的 `gen_ai.*` 对齐 span 模型（§1.1/§1.2）+ 分级 TTL 轮转（§6.3）+ 大对象 handle 拓扑（§1.3），骑 ATOF 反失去这些自控点；③ **落位与形态**：ATOF 默认落 `.nemo-relay/atof`、是离线 debug 制品（非常驻可查询 trace store，考古册 08 否定性事实 C），与本章「独立可查询 SQLite 遥测库 + spool 引擎摄入」拓扑（§5/§6）不同构。**gen_ai.* 语义翻译层本就无可复用**（hermes 零 OTel，§2）；故复用面止于「捕获总线当埋点面」（§4.1 已骑），落盘/序列化/存储层自研——ATOF/ATIF 与 ShareGPT 轨迹（条 5）同为「审过后显式否决」，不是漏审。

### 4.3 待核诚实声明

`post_api_request` 的 kwargs 是否携带 token 用量与延迟细节、`api_request_error` 的错误对象形态——本章未深读该 hook 的触发点实现（⚠️ 待复核，未决 #4）。影响面有界：若字段不全，兜底是 `llm_execution` middleware 包裹处自取（机制已核，§4.2-3）——缝合点的存在性不依赖此项。

### 4.4 audit_label 落位（答 §10 未决 #8）

> **裁定：audit_label 是 `tool_call` span 的 attrs 标准字段。** 捕获 hook 从工具注册单点真相取值（§10 §8.2：schema/handler/audit_label 同源派生）——工具调用进遥测的每一行都自带人类可读的投研语义（「发起一次完整正式决策（会写入决策账本）」），§12 Inspector 与人工复盘按此字段一秒识别异常调用意图（24 号报告语义，§10 §6.2 三消费面之二的兑现）。无 audit_label 的工具（hermes 原生工具）该字段为空——诚实缺失，不编造。

---

## 5. 写入拓扑：单写者 + L2 spool

### 5.1 gateway 进程内单写者

主体捕获 hooks、引擎、控制面全部宿主在 gateway 进程（§05 §1 宿主形态）——遥测写入模块在该进程内维持**单写者语义**（内部队列 + 单连接批量 flush，形态实现期定，未决 #8）。域库写入单点化（§03 §4.4）的遥测版：写入方收敛为一个代码路径。

### 5.2 L2 节点：spool 间接写入（直写否决）

L2 子进程的捕获数据**不直写 `telemetry.db`**：

| 候选 | 判定 |
|---|---|
| L2 直写遥测库（WAL + retry） | **否决**：并发漏斗 run 下 N 个 L2 + gateway 同时写一个 SQLite 文件，正是 hermes 自述的写锁 convoy 教训（多进程共享 state.db、15 次 jitter retry 自救，`hermes-agent/hermes_state.py:858-889`，§03 §4.2 已核转引——§03 用它否决 A′，本章用它否决 L2 直写，同一条证据链） |
| **L2 写 per-run spool（采纳）** | 节点侧捕获模块 append 单行 JSON 到互斥输出路径内的遥测文件（`ipc/{run}/{node_id}/telemetry.jsonl`）——复用 §05 §3.2 已定的命名空间与「并行节点路径互不重叠故无锁」性质；引擎回收节点输出时**同批摄入** spool 进遥测库 |

spool 方案白得两件事：**崩溃遗书**——节点崩溃时 spool 已 append 的行仍在盘上（JSONL 逐行追加，崩溃只损尾行），引擎按 `on_failure` 回收时照常摄入，§12 `on_crash` 归因的第一手原料不随进程死亡蒸发；**时序解耦**——遥测可见性延迟到节点回收（分钟级形状），对事后审计的消费形态（§12 批次后离线回溯）零损失。诚实声明这条取舍：**本设计不提供 L2 运行中的实时 span 流**；若未来需要「盯着正在跑的节点」，升级缝是引擎周期性预读 spool（文件在盘上，读不锁写），列增强不进基线。

> 🔴 **supersede 注（2026-08-04，W9-B γ1 Scope/Profile Gate 终裁 · readiness plan §13.21-X；上文形态段逐字保留，本注只更正物理落点与能力边界）**
>
> - **spool 物理落点 supersede**：上表「采纳」行的 `ipc/{run}/{node_id}/telemetry.jsonl` 与「复用 §05 §3.2 已定的命名空间」两处表述，**建立在已被 ISR §5 s7-7C 废止的字面之上**（该裁决废止「节点直接写 canonical ipc 输出文件」的物理写者表述，改裁**引擎为 canonical ipc 唯一写者**，同时**保持** ipc 命名空间与每节点互斥路径）。叠加 W8a 物理隔离后子进程的 `HERMES_HOME` = **attempt 临时根**（结构上够不着引擎 canonical ipc），并叠加 live spec `l2-process-carrier` 对「载体侧（含引擎生成的注入插件）写 `ipc/**`」的禁令 —— 自本注起，spool 落点 **supersede 为 attempt-local 固定相对路径 `<attempt HERMES_HOME>/valuehermes/telemetry/telemetry.jsonl`**，与既有 7D-2 capture（`valuehermes/capture/request_capture.jsonl`）**并列为恰两条受控写面例外**。🔴 SHALL NOT 放宽为任意 attempt-local 文件、整个目录、engine canonical ipc 或第四持久树。
> - **「同批摄入」时点精确化**：上文「引擎回收节点输出时**同批摄入**」自本注起按 **identity gate 之后**执法——摄入 SHALL 发生在 `carrier result 坐标身份前置比较` 通过之后，顺序链 = gate 成功 → wrapper shape validation → capture 解包 → telemetry envelope validation → spool parse → span 写入。
> - **四段依赖 supersede**：W9-B 的实现路线由 `γ0 → γ1 → β` **supersede 为四段严格串行** —— **γ0**（telemetry.db bootstrap 与 run authority 状态机，已 CLOSED）→ **γ1a**（attempt-local spool append / harvest / **non-run span** ingest）→ **γ1b**（run lifecycle authority 创建与 `pending→terminal` 转换）→ **β**（domain mirror 受控 update）。前一段 archive 后才允许打开后一段。
> - 🔴 **「崩溃遗书」能力边界（诚实收窄）**：上文「节点崩溃时 spool 已 append 的行仍在盘上…不随进程死亡蒸发」**只对 harvest 实际发生的腿成立**。实测（`valuehermes/engine/l2_carrier.py`）：harvest 位于 result 构造腿，覆盖 `spec.md` 五条清理路径中的**四条**（success / failure / timeout / TERM→KILL）；**`OwnershipLost` 及 wait-loop 内异常结构性绕过 harvest**，另有 pre-spawn 校验失败 / `attempt_root_setup` 失败 / `Popen` 失败 / probe 异常等腿同样零 spool，而 `finally` 的 `rmtree` **无条件执行**。⇒ 🔴 **SHALL NOT 宣称全终止路径 telemetry 覆盖**。
> - 🔴 **§12 crash-forensics 通道偏离登记**：§12 §1.3 / §3.1 把「盘上 spool 遗物」写成 crash forensics 第一手原料与 Inspector 只读工具（`read_file` / `search_files`）的读取对象 —— 在 **attempt-local + 无条件 `rmtree`** 的实现形态下该通道**结构性不可得**；同理 gateway 在 attempt root 删除之后、telemetry 写入之前崩溃 ⇒ **无 durable retry source**。二者均登记为**未闭合边界**，🔴 SHALL NOT 宣称 gateway-crash durable continuity；闭合须另立 durable handoff / recovery Gate，🔴 不得以延迟或跳过 attempt 根清理取得。

### 5.3 哨兵与进程树外构件（答 §09 未决 #7 的遥测半边）

> **裁定：哨兵零遥测库写入。** §09 §1.1 通道清单「没有第四条通道」是定义性约束，本章不为遥测破例：

- **送达的事件**：控制面记 `event_receipt`（§3.1）——事件流水在遥测库里的形态由订阅端产生，哨兵无感；
- **被防抖抑制的判定**：不逐条进遥测（为被抑制的噪声开高频写通道与防抖的目的自相矛盾）——**聚合计数进哨兵心跳文件**（§09 §6.3 已立的心跳事实上加统计段：各 ticker 抑制计数、冷却锁状态快照、最近 sweep 时刻；原子写，采样不逐条）。Inspector 对哨兵的归因通道 = 心跳文件 + 遥测库里的 event_receipt 流水（§12 §1.4 承接）；
- **`non_breach_event_producer` 心跳补强（本轮复核补强，答遥测半边）**：§09 §4.5 裁定的非破位事件 producer 是与事件哨兵（§09 §1）不同源的第二个确定性常驻进程——上一条「哨兵心跳」的统计段（ticker 抑制计数/冷却锁/sweep 时刻）是哨兵自己的可观测面，不覆盖这个 producer 的读取游标、规则命中与 ingress 成败。同一条「哨兵零遥测库写入」纪律延伸到它：不逐条进 span，聚合统计走自己的心跳文件：

```yaml
non_breach_producer_heartbeat:
  producer_id
  last_feed_cursor
  last_processed_at
  artifact_lag
  rule_manifest_hash
  generated_count
  suppressed_count
  ingress_success_count
  ingress_failure_count
  last_error_ref
```

  规则：送达事件走控制面 `event_receipt`（§3.1，同哨兵事件族一套落库路径）；未送达 / 被抑制 / 规则未命中的统计一律走本心跳，不逐条进遥测（同上「防抖抑制不逐条进遥测」的理由——为噪声开高频写通道与抑制的目的自相矛盾）。`rule_manifest_hash` 对齐 §16 asset hash 或 config_snapshot_id（复用既有版本锚，不新立哈希机制）。Inspector 对该 producer 的归因通道 = 本心跳文件 + 遥测库里的 event_receipt 流水，同哨兵一套模式（§12 §1.4 承接）。**心跳文件的落位、写入时机、`producer_id` 分配与准入登记归 §09 producer_registry / §15 部署守护（未决，跨文件 seam）；本条只锁 telemetry 侧的字段语义与走线规则。**
- Feed Handler/膜低频面的自身遥测：桩——调用侧观测已覆盖其服务面（主体/L2 调膜工具的 `tool_call` span 记录了请求与结果），膜内部轨迹列增强候选，随 §04 未决与实现期定（未决 #6）。

### 5.4 Inspector：旁路一等 producer（答 §12 遥测摄入路径未定义）

> **裁定：Inspector audit run 是 telemetry writer 的一等 producer。** Inspector sidecar（§12 §2.1 独立 CLI headless 进程，游离于蓝图 run 之外）在审计任务开始 / LLM 调用 / 工具查询 / 报告写入时，以 `trace_id` 为根**直接写** `audit` span 到 `telemetry.db`；它**不经 §05 蓝图引擎回收路径**——§5.1/§5.2 两条既有拓扑均以「宿主在 gateway 进程」或「引擎回收节点输出」为前提，Inspector 进程两条都不挂靠（§5.2 否决的是 N 个 L2 并发直写同一文件的 convoy 场景，Inspector 是孤立、低频、默认串行的旁路写者，不复现该风险量级）。捕获层沿用同一 hooks 机制（§4.2 已核），落库层遵守本章全部既有纪律：span schema（§1.1）、blob handle（§1.3）、弱引用无外键（§6.2）；对 telemetry.db 其余表与域库的查询面仍走 §7 只读连接，写面仅限自身 `audit` span 这一条产出——它是本节「单写者 + L2 spool」之外的第三条产出路径，不是对前两条的例外破坏。

### 5.5 Run 级 `telemetry_commit_status` 与 `tail_gap`（本轮复核补强，答 §03 `run_commit_marker` 的 telemetry 侧字段）

问题：§03 §4.5 新增的 `run_commit_marker` 需要一个 `telemetry_commit_status` 镜像字段（`pending`/`flushed`/`tail_gap`/`failed`），权威值必须在本库（telemetry.db）产生、domain.db 侧只镜像不重算。§5.2 已论证 L2 spool 崩溃时「损尾行」是已知、可容忍的场景（节点崩溃只损尾行，引擎按 `on_failure` 回收时照常摄入），但此前未把「某个 run 的 telemetry 侧到底摄入完整与否」固化为可查询状态——本节收口这个缺口。

裁定：run 级 telemetry 完整性状态挂在该 run 对应的 `run`-kind span 的 attrs 上（§1.1 kind 枚举不新增 kind，同 §1.6 `epistemic_distribution` 的落位方式——既有 span 的 attrs 扩展）：

```yaml
telemetry_run_commit:              # 挂 `run` kind span attrs（形状示意，字段级 no-invent）
  telemetry_commit_status: pending | flushed | tail_gap | failed
  expected_child_span_count: integer | unknown   # 引擎侧按 spool 命名空间预期的子 span 数（若可知）
  ingested_child_span_count: integer
  tail_gap_reason: string | null      # 如 "L2 crash before spool flush"、"spool file truncated"
  last_ingest_attempt_at: datetime
```

写入方：引擎回收/摄入 spool 时更新（沿用 §5.1/§5.2 既有单写者路径，不新增写入角色）。`flushed` = 该 run 关联的全部已知 spool 命名空间均已摄入；`tail_gap` = 引擎确认存在未摄入的尾部（节点崩溃、spool 截断等 §5.2 已知场景），区别于 `failed`（摄入过程本身出错，如 telemetry.db 写入失败）——诚实区分「知道漏了多少」与「不知道到底完不完整」，二者都不得静默当作 `flushed`。§5.1/§5.4 的非 spool 直写路径（gateway 内捕获、Inspector 旁路写）天然无尾行丢失风险，走 `pending → flushed` 即可，不涉及 `tail_gap`。

> 🔴 **分账 reconciliation（2026-08-04，W9-B γ1 Scope/Profile Gate 终裁 · readiness plan §13.21-X；上文语义逐字保留，本注只作阶段归属与术语分账）**
>
> 上文「写入方：引擎回收/摄入 spool 时更新」中的**更新动作归 γ1b**，**不属 γ1a**。四词固定、禁止混用：
> - **spool record** = child 写入的**短寿命自报** JSONL 行；
> - **harvest envelope** = parent 在 cleanup 前构造的 **engine-owned opaque transport**；
> - **ingest observation** = 本次 attempt 的**内存摄入事实与 coverage**，🔴 **不是 run truth**；
> - **run authority** = `telemetry.db` 中 `kind='run'` 的 **durable terminal truth**。
>
> **γ1a 只产 ingest observation、只摄 non-run span**：任何 spool document 的 `kind == "run"` SHALL 在 span writer 调用**之前** typed reject、零 mutation；γ1a **SHALL NOT** 创建 run-kind span、SHALL NOT 提交任何 `telemetry_commit_status` terminal、SHALL NOT 宣称 `flushed` / `tail_gap` / `failed` 已闭合。**结构性理由**：`spans` 对**所有 kind** 强制 `end_ts` / `status` 非空，而 run-kind 行**只能以 `pending` 初始化** ⇒ 创建该行即须给出 run 的结束时间与终态，而 attempt 粒度的 seam **不具备**该事实；任何在 attempt ingest 腿合成 run 起止的做法**均属伪造**。
> **run authority 的创建时点、`start_ts`/`end_ts`/`status` 来源、真实 run start/end seam、取消/挂起/恢复与 terminal 路径 —— 整体归 γ1b**，另过 Scope/Profile Gate；**β 继续以「γ1b 权威已成功 commit」为硬前置**。
> 🔴 `expected_child_span_count` 保持「若可知」的 **exact unknown** 姿态，SHALL NOT 发明任何推算规则（§13.21 rev2 §F G-6）。

消费方：§03 `run_commit_marker.telemetry_commit_status` 读取本状态镜像；Inspector / `post_restore_audit`（§03 §4.5 已锁规则：先查 marker 再查弱引用）；`tail_gap` 状态对应错误坐标 `TELEMETRY_TAIL_GAP`（§1.7）。

权威边界：本状态的权威值在 telemetry.db（本节）；domain.db 侧的镜像字段允许滞后（best-effort 更新，非强一致事务），三库无外键的既有纪律不因此改变（§6.2、§03 §5）。`expected_child_span_count` 何时可知/不可知的判定逻辑——留实现期，本节只锁字段合同与语义。

---

## 6. 独立遥测库（§03 §5 建议的定稿确认）

### 6.1 落位定稿

> **裁定：遥测独立成库文件，落 HERMES_HOME 自持目录（与域库同目录不同文件，如 `HERMES_HOME/<自持目录>/telemetry.db`；目录名随 §03 未决 #1）。** §03 §5 三条理由（写入速率与保留策略不同构 / 消费者不同 / 报告「state.db」语汇的裁定链）与 25 号报告 §2.1.2（append-mostly 时序宽表混入域库引发锁竞争、独立 TTL 轮转）本章全数采纳并定稿——骨架 §11 待答「遥测=独立本地库」就此收口。「本地 SQLite、禁止强制推送云端 SaaS」（ACI 报告 §1）原样保留为不变量推论。

### 6.2 表形态

spans 主表（§1.1 契约的直译，宽表、时间主序）+ blobs 表（§1.3）+ schema_docs 自描述表（表/列 → 语义一句话，**schema 即接口**——AOI 查询 agent 先读它再组查询，§7 的 ACI 精神落点）。纪律沿用 §03：一表一权威语义（§03 §1.3）、always-apply 幂等 schema（§03 宪法第五条）、测试指向 tmp 库（同宪法）。**无外键**——遥测行对域库/彼此只有弱引用（trace_id/span_id/decision_id），坏引用是可诊断事实不是写入错误（遥测自己也要 honest：残链就残链，禁止为外键完整性拒收轨迹）。

> 🔴 **物理分账 reconciliation（2026-08-03，W9-B γ0 终裁 · readiness plan §13.21-K；上文形态段逐字保留，本注为其物理落法的补充，非改写）**
>
> §03 宪法第四条要求「**新表设计优先列级字段、JSON blob 仅用于真正开放式结构**」（`03-domain-state-store.md` §2.1 第四条），本章 §1.1 又把 `attrs` 定义为结构化属性袋、§5.5 把 `telemetry_run_commit` 五字段挂在 `run` kind span 的 attrs 上。二者在**物理层**按下述分账 reconcile，🔴 **是一份真相的两个层面，不是两份真相**：
>
> - **列级提升（唯一物理主家）**：`telemetry_commit_status` / `expected_child_span_count` / `ingested_child_span_count` / `tail_gap_reason` / `last_ingest_attempt_at` 五个**固定字段**在 `spans` 表**列级存储**，且**只**落 `kind='run'` 行；🔴 **SHALL NOT 同时复制进 `attrs_json`**（双写即双真相）。§5.5 的「挂 run kind span attrs」在逻辑层继续成立——列即该 span 的属性，只是物理上被提升为列以满足宪法第四条与可索引/可约束诉求。
> - **JSON 承载（仅限真正开放式结构）**：`attrs`（§1.1，gen_ai.* 对齐的开放属性袋）· `error_ref`（§1.4 结构化错误对象）· `blob_refs`（§1.3 handle 列表）三处保留 JSON 列（`attrs_json` / `error_ref_json` / `blob_refs_json`），因其字段集合本身开放、随 frame 种类与后续扩展变化。
> - **未提升项**：本章其余 attrs 组（含 §1.6 `epistemic_distribution`、§1.8 `prefetch_compose`、§1.9 source policy 等）在 γ0 内**一律走 `attrs_json`**，其字段级物理 schema 属 γ0 后续扩展（见 §1.9 supersede 注），🔴 γ0 不得自造。
>
> 逐表 exact DDL、约束与索引由 **γ0 change `impl-w9b-gamma0-telemetry-authority-cnp`** 承载（capability `aci-telemetry-store`）；本章保持**设计意图**层，不复制 DDL 字面。

### 6.3 TTL 轮转与分级保留

- **分级保留**：`formal` 账关联 trace（决策账本行引用的）≥ advisory run trace ≥ 对话 turn trace——三档保留期全部配置项（数字不发明；量纲形状：月级 / 周级 / 周级以下）。依据：§03 §2.2 过程层合同「高保真但可按保留策略裁剪」；formal trace 优先是因为它是 §20 后置归因（legacy 14）的原料（骨架 §20「遥测与评测数据正是未来归因的原料」）。**权威层永不因遥测轮转受损**——账本行自足（§03 §2.2 权威层完整 round-trip），轮转掉的是过程保真度不是决策事实。
- **轮转机制两候选**（实现期按实测数据量定，未决 #3）：周期批删 + `auto_vacuum=INCREMENTAL`（单库简单，删除风暴与碎片是代价）；按时间分库文件（`telemetry-YYYYMM.db`，淘汰 = 删文件，查询跨库要 ATTACH）。基线倾向前者（ponytail：先用最简形态扛到数据量证明不行）。
- **备份语义**：库落 HERMES_HOME 即天然进 `hermes backup`（`agent/memory_provider.py:299-311` docstring，§03 §4.2 已核转引）。体积治理首先靠 TTL 本身；备份是否应排除遥测库（可裁剪数据要不要占备份体积）与 hermes backup 有无排除机制——归 §03 未决 #10 同批实测（未决 #5）。

### 6.4 「第一个 sprint 即埋点」正文化

骨架 §11 桩的这句话落为实现期铁律：**遥测写入共享模块与 spans 表属实现期第一批交付物**，先于任何漏斗节点——理由与 §03「先定 11 层契约再实现漏斗」（三态册 L85 的新版对应）同构：没有遥测的第一个节点一旦跑起来，就制造了因果链的考古断层。tier-1 冒烟项：TRACEPARENT 注入→L2 内接续→spool 摄入→trace 树完整的 round-trip（§13 蓝本联动）。

### 6.5 评测执行轨迹与评测库边界（三库 triad 的遥测侧）

> **裁定：`telemetry.db` 不拥有评测结果 schema。** 评测框架运行时，其执行轨迹（`eval_runner` / `judge_model_call` / `prompt_render` / `schema_validation` / `error` span + latency/token/cost）以普通 span 进 `telemetry.db`；但评分张量、聚合判定、golden set 绑定、rubric 版本、晋升证据的**权威落位在 §13 `evaluation.db`**（§13 §3.5 三库 triad）。

守护数据由此形成三库分工——`domain.db`/域库（§03，业务权威状态）· `telemetry.db`（§11，过程轨迹）· `evaluation.db`（§13，评测权威结果）：

- **三库弱引用、无跨库外键**（§6.2 遥测「无外键」纪律的三库版）：经 `trace_id / eval_run_id / asset_id / config_snapshot_id` 弱关联；telemetry 行可携 `eval_run_id`、evaluation 行可携 `trace_id`；坏引用是可诊断事实、不为外键完整性拒收轨迹。
- **TTL 不牵动评测权威**：分级保留轮转（§6.3）淘汰的是过程保真度；评测结果是资产治理证据、须长期保留，**不随 telemetry TTL 被裁剪**——这正是评测结果不能寄生遥测库的核心理由（§13 §3.5 retention 错配）。
- **消费侧一致**：telemetry 可作评测的**证据来源**（某 judge call 发生过），但不是评测结果的**权威主库**（某资产是否通过评测）——权威裁定归 §13，本章止于「数据怎么产生、怎么落、怎么被只读查询」（§0 边界）；评测结果的只读查询由 §13 侧的 evaluation.db 承担，本章 AOI（§7）覆盖的是遥测库过程轨迹。

---

## 7. AOI 只读查询接口形态裁定（正面作答）

骨架 §11 剩余待答「AOI 接口形态（SQL 直查 vs API）」。候选对比：

| 轴 | A：只读 SQL 查询工具 | B：类型化查询工具族（N 个专用工具） | C：REST/HTTP API 服务 |
|---|---|---|---|
| 表达力 | 全量——查询 agent 按 schema 自由组合（死锁前动作序列、跨 run 对比、任意聚合） | 封顶于预设的 N 种问题；每类新问题 = 新工具发版 | 同 B（endpoint 封顶） |
| agent-first 契合 | **schema 即接口**：schema_docs 自描述 + SQL 是 LLM 的既有能力——ACI 的本义 | 把 agent 当成只会点菜的客户端 | 同 B |
| 上下文经济 | 需护栏（大结果集会炸上下文） | 天然收窄 | 天然收窄 |
| 部署面 | 零（进程内工具，sqlite 只读连接） | 零 | **新常驻服务**——本地优先下无买主，且违反「总线不成为件」同款哲学（§09 §2.3） |
| 安全 | 连接级只读（SQLite URI `mode=ro` 打开——教科书级机制，无本地路径，实现期 Tier-1 冒烟）——注入类风险无定义域 | 同 | 多一个网络面 |

> **裁定：AOI = 只读 SQL 查询工具（基线）+ 预制视图族（常用查询的固化）。C 显式否决。** B 不另建——预制视图（trace 时间线、run 摘要、错误对象链、「死锁前最后 N 个动作」）就是「类型化查询」的正确形态：固化在库内视图而非工具清单里，agent 既可以直接 SELECT 视图（B 的便利），也可以下自由查询（A 的表达力），工具面只有一个。

**护栏合同**（考古 13 条目 30-32 白名单裁剪协议在 AOI 的对应物，经 §03 §3.4 已录）：行数与字节双上限（配置项）+ 查询超时 + 大对象列**默认以 handle+预览返回**（§1.3 的消费侧兑现——取 blob 本体是显式的第二次调用）。消费方与授权：Inspector（§12）、调试 agent、§13 评测（golden trace 回放候选的读面，骨架 §13 待答的接缝）、主体展示层 drilldown（§10 §10.1 交互合同的数据源之一）——全部只读（§03 §4.4 权限表）。

**per-consumer view ACL（本轮复核补强，答「只读不等于安全」的缺口）**：上述护栏合同管的是「查多少」（行数/字节/超时），管不住「查到什么」——同一张只读 SQL 工具面，不同消费者不该看到同一份视图集合（主体展示层 drilldown 若能查到 raw prompt blob、judge_score_tensors、broker_import 派生痕迹，只读不等于安全）。AOI 基线因此不是「任意 SELECT」，而是**「只读 SQL + per-consumer allowed view set」**：

```yaml
aoi_consumer_acl:
  subject_display:
    allowed_views:
      - decision_summary_view
      - trace_timeline_public_view
      - per_stock_profile_public_view
      - report_trace_public_view      # 报告相关过程轨迹的公开投影（telemetry 侧半边）——durable manifest 权威在 §03 #20 域库读面，非本库 view
    forbidden:
      - raw_prompt_blobs
      - raw_tool_outputs
      - judge_score_tensors
      - broker_import_handles
      - behavior_diagnosis_raw

  inspector:
    allowed_views:
      - trace_timeline_full_view
      - error_chain_view
      - blob_preview_view
    requires_explicit_blob_fetch: true

  eval_runner:
    allowed_views:
      - golden_trace_view
      - eval_lineage_view
```

三档对应上段既有消费者列表的收窄：`subject_display` = 主体展示层 drilldown——**Evidence Drilldown 是 §10 §10.4 的逻辑读模型**：durable manifest 从 §03 承载物 #20 经**域库读面**读取、按稳定 refs 可选下钻本库 `report_trace_public_view` 过程投影、在呈现层确定性合成（**不建跨库持久 view、无跨库外键、本库不接管 domain manifest authority**）；本档另见结论级视图；高级审计（`inspector` 档）可下钻 tool/source metadata；**原始 prompt、内部 reasoning、敏感 payload 继续受 ACL/PII/TTL 限制**——评分张量（`judge_score_tensors`，权威落位归 §13 §3.5、本库不承载）、高敏账别派生痕迹（`broker_import_handles`/`behavior_diagnosis_raw`，对齐 §1.5 分类）与原始 prompt/tool 输出一律不进 `subject_display` 视图集。**盲区呈现纪律（各档通用）**：payload 截断、TTL 过期或未捕获的引用在任何视图中显示为显式 **evidence blind spot**（§1.9 `evidence_coverage_status`），不得渲染为「证据通过」或中性缺省；`inspector` 沿用 §12 全视图授权（§5.4 已定 Inspector 为一等 producer），大对象仍需显式二次调用取本体（§1.3 handle 纪律不因授权级别放松）；`eval_runner` 只见评测回放所需的血缘与 golden trace 视图（§13 §8.1 通道 1 的读面），不越权读遥测库其余内容。「调试 agent」比照 `inspector` 档位消费，不另开第四档。视图集合的具体成员随预制视图族扩张（新增视图归入下方 §19 一类的对应档），ACL 随视图新增而演进——**新增预制视图时必须显式声明它进入哪个/哪些消费者的 `allowed_views`，不声明默认不可见**（zero-trust 缺省，同 §03 §4.4 权限表纪律）。

**§19 逐股画像的 AOI 落位**：§19 的逐股（per-ticker）驱动画像作为**预制视图族的新成员**加入本节固化视图清单——「某 ticker 驱动画像时间线」「性格漂移信号」与既有四视图（trace 时间线 / run 摘要 / 错误对象链 / 死锁前最后 N 个动作）并列，供调试 agent、§17 姊妹回路（策略衰减的 ticker 侧证据面）、主体展示层 drilldown 三方**只读**消费（§03 §4.4 权限表）。画像的**底料原文与大对象经 §1.3 handle 下钻**（视图默认返回 handle+预览，取本体是显式第二次调用，同上护栏）；画像是材料层观测视图，不获数字权威、不写回任何决策信号（advisory membrane，同 §3.4 真相源分离）。若 §19 采「按需现算」物理形态（§19 §7 物理形态选项 2），则画像不落固化视图、查询侧现算即 AOI 预制视图本身——固化 vs 现算的形态选择归 §19，本节只认「它是 AOI 只读视图族成员」这一接缝。

---

## 8. 对 legacy 的三态判断

本章构件为**新增**——legacy 无遥测层：其观测形态是散落的 console/trace sidecar 与 env-gate shadow 对比。按骨架 §11 三态行处理，关联注记照 §09 先例：

| 构件 | 三态 | 出处与独立论证 | 备注 |
|---|---|---|---|
| Frame Lifetime Trace 契约 + span 模型 | **新增** | ACI 报告 §1，经本章 §1 字段级落地 | OTel 对齐两层承诺（§1.2） |
| W3C 环境变量传播 + 防篡改四条 | **新增** | 25 号 §2.1.1 + observer 报告 §四，经 §3.3-3.4 落地（OTel 探针表述经 §2 形状修正） | 密码学防篡改显式不做 |
| 独立遥测库 + TTL 分级 | **新增** | 25 号 §2.1.2 + §03 §5 建议，本章 §6 定稿 | — |
| AOI 只读查询面 | **新增** | ACI 报告 §1 AOI，经 §7 裁定为 SQL 工具 + 预制视图 | REST 服务否决 |
| **关联注记：legacy 15 sidecar 大 payload 分离** | 不在此判（§10 §7.3 #4 已作吸收验收项） | trace/console sidecar 不进 message 注入路径的纪律，是「业务流与观测流分离」的 legacy 原型——本章过程层是其体系化 | A1 不重记 |
| **关联注记：legacy 09 `VA_DETERMINISTIC_ACTION_SHADOW` 观测** | 不在此判（§07 §5.5 已判「改造（机制升格进遥测）」） | shadow 对比数据成为遥测过程层常规字段——「先观测再晋升」治理的存储面由本章承载 | A1 不重记 |
| **关联注记：legacy 20「无人值守成功要证据」** | 不在此判（三态承接在 §15/§05 §10） | 本章义务面：每 run 终态必有遥测事件（§05 已锁）、心跳统计（§5.3）是其哨兵版 | A1 不重记 |

---

## 9. hermes 机制证据索引（本章引用的真实本地路径）

本章直接承重路径：

- `hermes-agent/pyproject.toml`（全文 grep）— **依赖清单零 OTel/opentelemetry 条目**（§2 裁定的主证据）；`:24-45` exact-pin 供应链方针与最小 scope 规则（§09 §2.2 已引）
- `hermes-agent/hermes_cli/plugins.py:135-213` — VALID_HOOKS 全清单（pre/post_tool_call、pre/post_llm_call、pre/post_api_request、api_request_error、on_session_*、subagent_start/stop、approval observers、kanban 族）（§4.2-1）
- `hermes-agent/hermes_cli/plugins.py:188-208` — kanban hooks 进程注记：worker = 独立 `hermes -p <profile> chat -q` 子进程、`kanban_task_completed` 在 worker 进程触发——**插件 hooks 在 CLI headless 子进程内生效的直接证据**（§4.2-2）
- `hermes-agent/hermes_cli/main.py:12027,12055-12068` — `_AGENT_COMMANDS = {None, "chat", "acp", "rl"}` + `_prepare_agent_startup` 对 agent 命令显式 `discover_plugins()`（§4.2-2 加固证据）
- `hermes-agent/hermes_cli/middleware.py:1-34` — VALID_MIDDLEWARE 四类；observer/middleware 语义分界注释（report vs wrap execution）（§4.2-3）
- `hermes-agent/run_agent.py:426-498` — AIAgent 构造签名：全套回调族（tool_start/tool_complete/thinking/step/stream_delta/event_callback）+ `save_trajectories` 均为宿主构造参数、非插件面（§4.2-4/5）
- `hermes-agent/agent/trajectory.py:31-56` — `save_trajectory`：ShareGPT 格式 JSONL、cwd 相对文件名、无 trace 结构；`run_agent.py:1927-1940` — `_save_trajectory` 调用点（§4.2-5 复用否决依据）
- `hermes-agent/agent/conversation_compression.py:879` — `event_callback("session:compress", …)`：event_callback 现役发射面（§4.2-4）
- SQLite URI `mode=ro` 只读连接 — 教科书级 SQLite 机制，非 hermes 事实，无本地路径；实现期以 stdlib `sqlite3` 冒烟验证列 Tier-1（§7；§09 §8 对 `PRAGMA data_version` 的同款处理先例）

转引来源章已核路径（本章未复读，不承重于本章新裁定）：`hermes_state.py:858-889`（写锁 convoy，§03——§5.2 否决 L2 直写）；`hermes_constants.py:55-80`（HERMES_HOME 显式传播，§03——§3.3 同纪律先例）；`agent/memory_provider.py:299-311`（hermes backup 走 HERMES_HOME，§03——§6.3）；`hermes_cli/plugins.py:998-1042`（auxiliary task 面，§09——本章不用，§12 引）。外部标准 ×2（OTel GenAI semconv、W3C Trace Context）：对齐桩处理，字段/字节级定稿入 A2 文献引用区（§1.2、§3.3）。

---

## 10. 显式未决问题清单

1. **gen_ai.* 字段级对照表**：attrs 命名与 OTel GenAI semconv 的逐字段对照——实现期对当版规范定稿，入 A2 文献引用区（§1.2）；TRACEPARENT 字节级格式同批（§3.3）。
2. **保留期与内联阈值参数**：三档 TTL、blob 内联/外置阈值、AOI 行数字节上限、查询超时——全部配置项，默认值不发明，实现期 + §13 校准（§1.3/§6.3/§7）。
3. **轮转机制终选**：周期批删 + incremental vacuum（基线倾向）vs 按月分库——按实测数据量定（§6.3）；blobs 外置文件目录的启用阈值同批（§1.3）。
4. **hooks 异常路径与字段完备性**：`post_api_request` 的 token/延迟字段、工具抛异常时 pre/post 配对是否漏边——实现期核；不足则升级 execution middleware 包裹（§4.2-3、§4.3）。
5. **备份排除**：hermes backup 对可裁剪遥测库的处理（排除机制是否存在/是否需要）——与 §03 未决 #10 同批实测（§6.3）。
6. **膜/Feed Handler 内部遥测**：调用侧观测之外是否需要膜自身轨迹——随 §04 未决与实现期定（§5.3）。
7. **task 级聚合视图**：per-turn trace 之上的任务粒度视图（[TASK_START] 边界与 trace 的关联字段）——随 §10 未决 #3（任务边界判定）联动，实现期定（§3.1）。
8. **gateway 进程内写入队列形态**：单连接串行 vs 批量 flush 节拍、进程崩溃时未 flush 尾窗的丢失预算——实现期定（§5.1）；崩溃尾窗与 §12 尸检扫描的交互在 §12 §1.3 承接。
9. **L2 实时可见性增强**：引擎预读在跑节点 spool 的「实时盯梢」面——增强候选不进基线（§5.2）。
10. **`valuehermes_error_code_v1` 落地残留**（本轮复核补强）：各业务章 local reason → canonical `error_code` 映射表、`INTERNAL_UNCLASSIFIED_ERROR` 的完整字段值、unknown code fail-closed 的部署校验点——归各业务章 + §13 + §15（§1.7）。
11. **`telemetry_commit_status` 摄入判定细节**（本轮复核补强）：`expected_child_span_count` 何时可知/不可知的判定逻辑、`tail_gap` 与 `failed` 的边界情形（如摄入过程中途崩溃）——实现期定（§5.5）。

---

## 11. 🔴 W9-B γ1b reconciliation（2026-08-05，readiness plan §13.23-AD AD-8 + §13.23-AF AF-6；**纯追加 supersede / reconciliation，上文全部正文逐字保留、零改写**）

> 本节只作**阶段归属与口径 reconciliation**，**不改**上文任一裁定、不复制 DDL、不新增字段。合同全文归 OpenSpec change `impl-w9b-gamma1b-run-telemetry-authority-finalization-cnp`（capability `run-telemetry-authority-finalization`）。

1. **`pending` = 两事务之间的 durable staging，不是 run in-flight lifecycle** —— §5.5 的 `telemetry_commit_status: pending` 在**物理层**只出现于「**终态 run document 已知之后、telemetry authority 尚未完成 terminal commit**」这一窗口：`write_span`（创建 `pending`）与 `commit_run_authority`（提交 terminal）**各自独占其 `BEGIN IMMEDIATE`**、结构上不可合并 ⇒ 二者之间**必有 COMMIT 窗口**。🔴 该 `pending` **SHALL NOT** 被读作「run 正在飞」；两事务间的 **pending crash residue** 是真实窗口，由 fresh recovery 的 **`pending` fail-closed** 腿处置（登记为 residual）。

2. **run span 的 start / end 时间来自 W7 durable readback（引擎零自造墙钟）** —— §1.1 的 `start_ts` / `end_ts` 在 γ1b 的**唯一**来源：`start_ts` = `blueprint_run_queue.dispatched_at`（`begin_dispatch` 成功后由控制面**重新读取** durable intake 行取得）；COMPLETED / FAILED / TIMED_OUT 的 `end_ts` = **首次 durable `cancel_window_closed_at`**（🔴 由绑定层 **post-fence durable readback** 取得，**不是**调用方输入的内存归一值）。🔴 **SHALL NOT** 由 `datetime.now()` / `time.time()` / monotonic 转墙钟 / 环境变量 / run record `elapsed` / 恢复现场墙钟产生。

3. **CANCELED 的 `end_ts` 来自 CANCELED audit checkpoint 的 store-stamped `created_at`** —— §05 §4.6 的 CANCELED 收口序列先写 `run_status='CANCELED'` audit checkpoint，其 `created_at` 由 checkpoint owner 加戳；γ1b 以该值作 CANCELED run span 的 `end_ts` 与 `last_ingest_attempt_at`。🔴 fresh recovery 侧**必须**经**既有 public** `read_latest_checkpoint`（`expected_identity` = intake 五元身份）复核该值 —— **checkpoint 缺席 / `run_status` 非 CANCELED / 身份损坏 / 值漂移一律 loud typed fail、零 marker**；🔴 **不接受**「canceled 恢复不比 `end_ts`」的降级。

4. **`last_ingest_attempt_at` 的窄义** —— §5.5 该字段在 γ1b 的语义**精确登记**为「**run-level authority reconciliation boundary**」（= 同一 terminal durable boundary）；🔴 它**不是**最后一个 child span 的事件时刻、**也不是** provider 请求时刻。

5. **`parent_span_id` 当前固定 `None`，continuity deferred** —— §3.2「run span 的 parent = 提交时的 `tool_call` span」在 γ1b **尚未实现**：γ1b 的 run document `parent_span_id` **恒为 `None`**。🔴 该 residual **只表示** `tool_call → run` continuity 未实现，**SHALL NOT** 被读作「允许历史行带伪 parent」—— 当前 run parent **仍必须为 `None`**，非空即判 divergent。

6. **`failed` production branch deferred** —— §5.5 四态中的 `failed` 在 γ1b **无 production branch**（保留 owner 能力、明确 deferred）；🔴 **SHALL NOT** 为凑四态制造假失败；🔴 业务 run 终态 `FAILED` **不映射**为 telemetry `failed`（两套状态机正交：业务 FAILED 仍可得 `flushed` 或 `tail_gap`）。同段的 `expected_child_span_count` 保持 **exact unknown（恒 `None`）**，🔴 不发明推算规则 ⇒ `flushed` 的「完整性」断言**弱于字面**。

7. **`NOT_OBSERVABLE` 不阻塞既有 domain terminal truth** —— §5.5 的权威缺席在 γ1b 的处置：`NOT_OBSERVABLE`（missing / blind observation，或 fresh recovery 下 authority 真缺席）⇒ **零 authority 写入，但既有 domain closure 照常执行**（marker 照常写）。🔴 **SHALL NOT** 让 telemetry 缺席阻塞业务 terminal truth；🔴 缺席**仍不构成阴性证明**（不得读作「该 run 无遥测」或「遥测已完整」）。authority *decision* 先于 domain closure，但**只有** `flushed` / `tail_gap` 才要求 terminal commit 先于 marker。

8. **β mirror update 仍是独立后续 change** —— §5.5 的消费方（§03 `run_commit_marker.telemetry_commit_status` 镜像）在 γ1b **零 UPDATE**；🔴 任一非 `pending` 镜像更新的硬前置仍为「本库对应权威状态已成功 commit」，其 API 与 caller **归 β change**，🔴 **SHALL NOT** 在 γ1b 提前建立 dormant β API。

🔴 **本节 SHALL NOT 被读作**：真实 Hermes hook producer 已接线 · 真实 provider 已验证 · W9-B complete · W9 overall · gateway-crash durable continuity · exactly-once / at-least-once · 真实 clock authority · 全链 W3C `trace_id` 格式已证明 · 全局 correlation 已完成。

## 12. 🔴 W9-B β reconciliation（2026-08-06，readiness plan §13.25-AO；**纯追加 reconciliation，上文全部正文逐字保留、零改写**）

> 本节只做**账实对齐**：§11 第 8 条「β mirror update 仍是独立后续 change / 在 γ1b 零 UPDATE」作为**历史事实逐字继续成立**；本节陈述 β change（`impl-w9b-beta-domain-telemetry-mirror-cnp`，路线 D）的形态与边界。

1. **authority = `telemetry.db`** —— `kind='run'` span 行的 `telemetry_commit_status` 是该 run 遥测收口状态的**唯一权威**；本节不改变 §5.5 的任何权威归属。
2. **marker = domain 单向镜像** —— `domain.db` `run_commit_marker.telemetry_commit_status` 是**镜像**，🔴 **不参与** closure / adopt / diverge / read-before-replay 的任何判定（§03 与 `blueprint-run-closure` 既有合同逐字继续成立），**不改变 closure 判定权威**。
3. **β = 显式 per-run 单向 reconciliation** —— 收敛方向恒为 `telemetry authority → domain mirror`；入口 `control_plane/telemetry_mirror.py::reconcile_run_telemetry_mirror` 是**显式 per-run entrypoint**，marker 侧唯一 CAS owner 为 `domain_store/markers.py::update_run_commit_telemetry_mirror`（marker 的 **INSERT 生命周期**仍归既有收口写面，两 owner 分账）。
4. **marker 缺席不代插** —— 该 run 无 marker 行时，β 记 finding、**零 `INSERT`**；🔴 marker 的创建不属 β 职责。
5. **absent / pending 不猜 terminal** —— authority 缺席 ⇒ `NOT_OBSERVABLE`；authority 仍 `pending` ⇒ not-ready finding。两者均**零 domain mutation**，🔴 SHALL NOT 据此推断该 run 的遥测已完整或已失败。
6. **双库非原子** —— `telemetry.db` 与 `domain.db` 之间**无跨库原子事务**；🔴「authority 已 terminal 而 mirror 仍 `pending`」在崩溃后是**可存在的合法中间态**，SHALL NOT 宣称已消除。
7. **无自动 scheduler / consumer** —— β **不**提供自动发现、周期调度、后台 worker、sweep，**不**枚举全库 `pending` marker，**零 production caller**。🔴 因此只可陈述「**显式调用时可收敛**」，**SHALL NOT** 陈述 automatic eventual consistency / exactly-once / at-least-once；未被显式调用的 run，其镜像可**无限期停留 `pending`**。
8. **不反向修复权威** —— β 的任一失败腿（read 失败 / storage 失败 / marker 缺席 / divergence / 非法历史值）**SHALL NOT** 删除、覆盖、重置或以任何方式写 telemetry authority；🔴 mirror 的缺席、值或分歧**不构成**对 authority 的任何反向断言。

🔴 **本节 SHALL NOT 被读作**：真实 Hermes hook producer 已接线 · 真实 provider 已验证 · W9-B complete · W9 overall complete · `failed` production branch 已活体 · mirror 已成为权威 · 自动最终一致性已达成 · B2 member-level M1 / golden / `production_locked` / IMC。
