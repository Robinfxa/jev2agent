# ValueHermes 模块 13：双层评测与特性开关消融

> 状态：**✅ 定稿**（2026-07-03 用户评审通过）
> 骨架定位：构件群 IV 守护构件（`docs/architecture/00-master-design-book.md` §13）。北极星增补「非确定性输出以双层评测衡量而非 Pass/Fail」（骨架 §00 前提 1）的落地章；🔴 **实现期 overlay §3 测试体系回填将以本章为蓝本**（骨架 §13 点名，本章 §9 兑现声明）。
> 方向输入：`docs/research/newfeature/11-aci-telemetry/agent-computer-interface-eval.md` §2/§3（下称「ACI 报告」）+ `docs/research/newfeature/00-cross-cutting/25-guardian-and-cross-cutting-clusters-architecture.md` §2.3（下称「25 号报告」）；§3.5-§3.7 评测域存储与记录 schema 另据 `docs/research/newfeature/13-two-tier-eval/evaluation-store-boundary.md`（下称「store-boundary 稿」）、`docs/research/newfeature/17-strategy-lifecycle-evolution/evaluation-run-record-and-linked-evaluation-graph.md`（下称「run-record 稿」）；评测场景、裁判校准与时间化回放的边界另参 `docs/research/newfeature/13-two-tier-eval/32-llm-benchmark-scenario-evaluation.md`（下称「32 号报告」）。ACI 报告与 25 号报告的文献矩阵（arXiv 编号未核验、厂商链接）按 A2 硬闸**不作正文依据**，本章只采编其架构结论并独立论证。
> 证据纪律：legacy 事实引考古书与考古 12/18/20 章；三态候选引 `docs/research/legacy-tri-state-arc/tri-state-candidates.md`（下称「三态册」）；hermes 断言见 §11 证据索引。全章零发明数值：样本量、及格线、裁判数、超时数一律配置项，定标待实证数据。

---

## 0. 本章定位与边界

漏斗产出研报、立场、共识建议——这些非标文本没有绝对对错，传统「断言相等」的回归测试对它们失效；但系统又必须能回答「升级 hermes / 换模型档 / 改蓝图之后，整体能力退化了没有」。本章立**回归评测体系**：Tier-1 确定性断言兜硬性下限，Tier-2 多裁判量规打分衡量软性质量，特性开关消融在退化发生时做控制变量定位。

本章在 §14 §2.6「纪律的三个执法时刻」中承担第三时刻：**运行时**由节点内卫兵执法（§14 §4）、**事后单体**由 §12 Inspector 归因，**回归**由本章批量验证。三者读同一遥测（§11），职责不重叠（分工正文化见 §4）。

**本章不做的事**：运行时防线本体（两层熔断、卫兵、加载校验——§05/§14 已定，本章只消费与分工）；遥测 schema 与 AOI 接口（§11，波 B）；Inspector 归因机制（§12，波 B）；量规维度的字段级定稿与 golden set 初始集（未决，实现期）；CI/调度载体选型（实现期）。

---

## 1. 评测对象分型：什么进双层、什么不进

「双层评测」不是全系统测试的替代品，是**非确定性输出专用**的回归形态。先分型，防止两个方向的误用：

| 对象 | 性质 | 回归形态 |
|---|---|---|
| 确定性构件：解释器状态机、voter/tiebreak 公式、卫兵规则、膜公式、防抖判定、TemporalValidity 闭式解 | 有绝对对错 | **传统单元/契约测试**（Pass/Fail 完全有效）——不进双层；把它们塞进 Tier-2 打分是纪律倒退 |
| LLM 节点行为：FactInterpreter rationale、News 票面、ThesisLane、辩论回应、RM synthesis、trader 意图、深挖简报 | 非确定性、无标准答案 | **双层**（节点级） |
| 蓝图端到端产物：漏斗 A 全链、MAD B 全链、挖掘扫描批次 | 非确定性组合 | **双层**（run 级，golden traces 回放） |
| gated-off 路径：flag 关闭时的旧行为 | 必须与关闭前逐字节一致 | **Tier-1 特殊断言**（byte-identical 锁，§5.2） |

**触发场景四类**：① 新功能上线前（flag experimental → 晋升的证据义务，§6）；② 版本升级期（hermes 升版、模型/provider 换档、蓝图新版本——25 号 §2.3「CI/版本升级期批量跑 golden traces」）；③ 退化排查（消融协议，§5.3）；④ 周期抽查（卫兵自审计、量规信噪比复核，§8.3）。

---

## 2. Tier-1 确定性断言合同

### 2.1 合同条款

**完全禁止 LLM 参与**（ACI 报告 §2 Tier-1 条款原样继承）：纯启发式、Python 断言、JSON Schema 校验器。断言族按本书既有合同归类：

1. **结构断言**：产物过 outputs Pydantic 契约、必填字段无遗漏、枚举值在定义域内（出口信封三段、ThesisLane、DeepDive_Briefing 等已定稿 schema 的回归锁）；
2. **行为断言**：工具是否被正确触发、条件分支是否被精准覆盖（fast-path 触发/旁路、fallback 链路、`on_failure` 语义）；
3. **纪律断言**：trace_id 未被清洗（§11 防篡改）、账别正确（advisory 产物没写正式账）、状态写入 ⊆ 白名单（§03 宪法一）、display 字段未进权威列（§03 §2.3）；**前缀缓存命中断言**：对「同实体重复推理」批量断言 `cache_read_tokens > 0`（hermes 归一后 canonical 用量字段，`agent/usage_pricing.py:786-790`）——跨重复请求恒为 0 即前缀被静默失效（provider 侧 TTL 过期 / 前缀字节漂移 / 缓存点错位），熔断并给确定性坐标（哪个前缀、哪字节漂移），不容「功能仍对但成本静默翻数倍」的退化蒙混过评测；最小实现落回放注入缝之上（§2.2），链回 §18 §6 冷数据前缀缓存复用；**decay_monitoring 遥测完整性断言（本轮复核补强）**：对标记 `decay_monitoring` 的 run，批量断言其相关 span 携带 §11 §1.6 `epistemic_distribution` attrs（`lane_id`/`verdict`/`confidence`/`action_temperature`/`distribution_hash` 齐备）；缺失时该 run **不得 silent no-op**（沉默跳过是本轮复核点名的失效模式，§17 Detection 侧消费该信号）——必须记录确定性标记 `insufficient_telemetry_for_decay_detection`，作断言族的确定性坐标而非 Detection 自行判定；
4. **差分断言**：lane 翻转敏感度（同 facts 换 lane，signal 不变即纯装饰——§06 §6.5 验证器 3）、回应性结构检测（辩论产物论点 id 引用 ≥1——§06 §6.5 验证器 2 的 Tier-1 半边）、gate-off byte-identical（§5.2）；
5. **资产准入断言**：挖掘蓝图编译链的 GCD schema 合规、AST 墙规则覆盖、mock fetcher 下拓扑可执行（§08 §7 回路 3 点名的 Tier-1 实例）；蓝图声明的 calc slot / 工具引用对登记册可解析（附录 A5 §9 registry item 合同、§04 §8.6 数据域注册表——加载校验层拒绝在先（§2.2 分工），本断言族作其回归锁）。

**Portfolio Lens 专项断言集**（组合透镜最易滑坡处的定向锁，进 live run 前必备；纪律族的场景实例，链 §07 §4.6 / §14 §5.3 归因墙 / §03 承载物 #6）：无推断持仓（`inferred_holdings` 恒空——持仓只来自用户显式 `portfolio_book_input`）；不产 `target_weight` / `rebalance_order` / 任何 brokerage action（透镜非组合优化器、非执行通道）；`book` 缺失 → missing-book disclaimer、`book` 陈旧 → stale-book disclaimer（不静默省略、不拿旧 book 当现值）；`portfolio_lens_summary` 永不写正式账（advisory material only，§03 表级隔离）；暴露 / 集中度 / capacity 字段有确定性 provenance（Python 算出、非 LLM 生成）。**golden seed（`portfolio_lens_golden_seed_v1`，§8.2 golden set 初始条目候选）**：`buy_precheck_no_book` / `buy_precheck_over_sector_limit` / `sell_precheck_thesis_intact_but_concentration_high` / `crash_policy_shock_shared_sector_exposure` / `monthly_review_hidden_theme_overlap`——覆盖缺 book、超行业上限、thesis 完好但集中度高、暴跌共振暴露、月度复核隐藏主题重叠五类滑坡面。

**L2 Prompt Isolation 专项断言集**（L2 headless 子进程隔离墙最易滑坡处的定向锁，进 live run 前必备；纪律族的场景实例，五轮复核 6.4 收口）：对每次 L2 节点 run 断言——rendered prompt/context 不含未声明的 `state_view` 键（§05 节点契约的物理裁剪声明面，§03 §6 理由 1）；MemoryProvider / PrefetchComposer 输出不得出现，除非节点显式声明 `memory_view`（§10 §9.1 唯一 provider 合同在 L2 侧的收窄面）；`memory_view` 存在时，每条候选必须携带 `source_type` / `source_id` / `effective_time` / `recorded_time` / `data_cutoff_time`（§10 §9.2 供料源字段的断言化）；主体 session history 不得出现在 L2 prompt 中；`broker_import` 与行为诊断 raw 材料永不出现（§03 高敏 PII 边界在 L2 隔离侧的执法）。**依赖声明**：本断言族消费 L2 执行 profile 隔离合同（`allowed_inherit` / `forbidden_inherit` / `memory_policy`）的产物，该合同字段级定义归 §05；合同细节落定前，本五条断言先作回归锁生效，不阻塞、随 §05 补齐时对齐（不新增机制，只锁断言）。**证据源对齐通知（D3 · ISR §05 seam-7 取证链裁决照录）**：本五断言的**真载体证据源**按分源映射钉死——**L2 进程内 LLM 请求证据的真载体 = hermes `pre_api_request` hook 捕获面**（该 hook 在 `_build_api_kwargs` → transport preflight → middleware 之后触发，其 `request_messages` 是接近实际 provider request 的最终消息面，底座锚 `conversation_loop.py:1073-1112`；`pre_api_request` 已在 §11 §5 hooks 清单登记，底座锚 `hermes-agent/hermes_cli/plugins.py:135-213`；取证件原子落 `ipc/{run}/{node}/forensics/`）。**分源映射**：断言 ①（`state_view`）②（Provider/Composer 输出）④（session history）的证据源 = `pre_api_request` 的 `request_messages`；断言 ⑤（`broker_import` 永不出现）证据源 = 拉起前精确 tool manifest/hash（生成侧执法），最终 request 工具面若现有 hook 无法**无截断**捕获 → 登记**窄 capability gap**（不得以 tool_count 代工具名清单，能力具备后与最终 request tools 交叉核对）；断言 ③（`memory_view` 五字段齐全）证据源 = 输出边界 schema 校验（引擎回收侧、非 request 捕获断言）。**partial evidence coverage 纪律**：五断言全量真载体化前，本断言族只标 **partial evidence coverage**（接 §11 §1.9 `evidence_coverage_status` / §7 盲区呈现纪律，不新增 coverage 机制）——**捕获缺失或 `request.body` 截断标记出现只记显式 evidence blind spot、绝不记「断言通过」（未捕获 ≠ 通过）**；`request.body` 只作有界遥测（截断/项数/深度上限 env 可调，底座锚 `run_agent.py:2226-2263,2376-2387`），出现截断标记时不得作为「禁止项不存在」的完整性证明；**工具最终执行面的取证 gap**（最终 request 工具面无截断捕获缺口）显式登记为 **capability gap**、不夸大成熟度。真载体对齐（在 hermes chat 真载体上跑捕获面、闭合工具最终面 gap）归实现期 L2 请求取证工作包（`impl-l2-request-evidence`）——本通知**只登记证据源与 coverage 纪律，不实现捕获、不宣称五断言已全量真载体化**。

**Provider Quota 专项断言集**（provider 真金费用/连接配额坐标最易失控处的定向锁，进 live run 前必备；纪律族的场景实例，链 §04 §8.6 `provider_quota_budget_v1`，源 `docs/research/_claims/valuehermes-cross-layer-contract-gap-review.md` §1 F1）：批量挖掘扫描 / DeepDive 多跳检索 / 非破位事件 producer / refresh job 单 run 内 provider request 计数与 cost 估算不超过配置预算（`request_cap` / `cost_cap` / `connection_cap` / `concurrency_cap` 逐项断言）；fallback 链路触发时同样计入预算、不得绕过 quota gate（fallback 请求量断言 > 0 时预算消耗同步增长）；quota exhausted 时返回结构化 unavailable（`status=unavailable` + `reason_codes` 含 exhausted 标记），不得 silent fallback 到降级 provider 或伪造中性值；每条 request 携带的 `caller_class` 必在定义域内（subject_query / formal_run / advisory_run / mining_scan / deepdive_retrieval / event_producer / refresh_job / eval_replay 之一）。**golden seed**（`provider_quota_golden_seed_v1`，§8.2 golden set 初始条目候选）：`provider_quota_exhausted_mid_scan`（挖掘批量扫描中途触发 quota exhausted → 结构化 unavailable + 扫描其余部分不受影响）、`fallback_chain_consumes_quota`（主 provider 失败触发 fallback → fallback 请求同样计入预算，非零成本旁路）。

**Mock Data Isolation 专项断言集**（真假数据坐标最易误入正式链路处的定向锁，进 live run 前必备；纪律族的场景实例，链 §04 §8.6 `mock_data_runtime_gate_v1`，源同上 F2）：`DataResult.meta.source_mode` / `is_mock` 逐工具响应必带；**formal run 消费 `is_mock=true` 的 DataResult 直接 fail**（硬闸，不允许静默放行、不允许降级为 warning）；advisory run 消费 mock 数据时产物必标 debug，且写 `formal_decision_ledger` / `risk_threshold_table` / 触发 asset promotion 的尝试均被拒；eval run 的 mock/replay 产物只写 `evaluation.db`，零外溢 `domain.db`。**golden seed**（`mock_data_isolation_golden_seed_v1`，§8.2 golden set 初始条目候选）：`formal_run_rejects_mock_dataresult`（构造 `is_mock=true` 的 DataResult 喂给 formal 蓝图 → 直接 fail，零决策产出）、`advisory_debug_mock_cannot_write_ledger`（advisory debug run 用 mock 数据 → 产物标 debug 且写 ledger 的尝试被拒）。

**Source Policy 专项断言集**（用户来源治理与证据链最易滑坡处的定向锁，进 live run 前必备；纪律族的场景实例，链 §04 §8.7 `source_access_policy_v1`／§16 §2.3 子快照／§14 §7／§03 #19-#20）：**deny 与 actual selected 不相交**（实际选中来源集 ⊆ 有效 allow 集，且与 deny 集交集为空）；**denied cached source 不被消费**（缓存命中 denied selector 的条目对新 run 零消费——fetch 与 cached-consume 双闸逐一断言）；**当前偏好变化不改变历史 `as_ran`**（修改 §03 #19 当前声明后，既有 as_ran replay 的输入、hash 与结果记录逐字节不变）；**counterfactual 单变量守恒**（除 source policy 外，蓝图/模型/其他配置/PIT 与 data_cutoff 边界与 baseline 逐项一致）；**历史不可得来源不能穿越**（`current_policy_validation` 只从历史时点真实可得集选择，今天才出现的 provider/事后补录材料拒入）；**全过滤返回 insufficient/unavailable**（策略过滤后零可用来源 → §04 DataResult 返回 canonical `unavailable`/`insufficient` **数据层状态**，报告层映射为非断言型 evidence outcome——两层枚举不混写、零伪中性 stance，§14 §7 两态合同）；**formal evidence 拒绝 stance selector**（bullish/bearish 立场过滤器在 formal 证据集上直接拒绝）；**config snapshot 可展开 source policy**（`config_snapshot_id` 展开出同一 run 记录的 `source_policy_snapshot_id + policy_hash`）；**system hard gate 排除可表达断言**：每个 system hard gate 的排除都可被 `reason_family + reason_code (+gate_id)` 结构表达（§04 §8.7 同源家族——新硬闸缺 family 映射即 Fail）；排除/fallback/历史可用性判断均有可解析记录（reason 结构在同源家族定义域内）。**golden seed**（`source_policy_golden_seed_v1`，§8.2 初始条目候选）：`current_preference_change_does_not_mutate_as_ran`／`denied_cached_source_not_consumed`／`preferred_source_unavailable_fallback_disclosed`／`future_source_rejected_in_current_policy_validation`／`all_sources_filtered_returns_insufficient`／`stance_filter_rejected_for_formal_evidence`。**Tier-2 边界**：Tier-2 只评「来源选择与降级是否解释得诚实、对用户是否有用」——许可、PIT 合法性与 deny 执行全部属本 Tier-1 硬合同，Tier-2 不得替代。

**结果语义**：绝对二进制 Pass/Fail。**任何 Tier-1 Fail 直接熔断流水线，不允许进入 Tier-2**（ACI 报告原则）。三个独立理由：成本——Tier-2 每一分都花裁判 token，给结构非法的产物打质量分是纯浪费；污染——「文笔流畅但漏了必填字段」的样本会拉高量规分、掩盖硬伤（流畅度偏见的入口之一）；定位——Tier-1 失败自带确定性坐标（哪条断言、哪个字段），先修它再谈质量。

### 2.2 三层确定性防线的分工（骨架点名的正面作答）

Tier-1 不是系统里唯一的确定性检查，与 §05 加载校验、§04 fetcher 注入缝是**三个不同问题的答案**，分工如下（同 §08 §2.3 三层分治的姊妹表）：

| 层 | 回答的问题 | 时机 | 内容 | 归属 |
|---|---|---|---|---|
| **蓝图加载静态校验** | 「这份资产现在可以被执行吗？」 | 每次引擎加载（生产运行时） | schema、DAG 无环、悬空依赖、工具黑名单、hash 漂移拒载 | §05 §2.1/§4.4/§7 |
| **fetcher 注入缝** | 「评测/测试的输入从哪来？」 | 评测与测试执行时 | 每条数据路径可注入 mock fetcher——不触网、不依赖 key、不依赖当天行情的确定性输入 | §04 §1.2 条 7（考古 03 §精华 7 继承） |
| **Tier-1 断言** | 「这次行为/产物符合合同吗？」 | 回归评测期（批量） | §2.1 五族断言 | 本章 |

三者关系：加载校验管**资产形状**、每次都跑；注入缝是**数据面前提**——Tier-1 的确定性依赖输入确定性，没有注入缝，「同一断言两次跑出两个结果」会把回归信号淹死（考古 18 §测试通信协议的 canned fetcher/offline guard 策略即此前提的 legacy 实证，三态册 L803）；Tier-1 管**行为断言**、跑在注入缝之上。运行时的两层熔断（§05 §6.1）与节点内卫兵（§14 §4）是第四、五道确定性机制，但它们是生产防线不是评测——评测失败不阻塞生产 run，生产熔断也不等于回归覆盖。

### 2.3 「unit pass ≠ wire 真通」的协议继承

legacy 后期反复强调的验证纪律（考古 20 §OpenSpec verification gate：触 state 字段的变更必须有 integration wire test）继承为 Tier-1 的组稿原则：断言族必须含**贯通断言**（run 级 golden 回放中检查写入真的落了账、事件真的发了、阈值行真的更新了），不允许全部由节点级 mock 断言拼凑。同源继承测试隔离卫生（考古 20 §Tier-2 与 xdist：共享状态隔离、offline guard 防网络挂死、gate 从 summary 行判结果不被管道截断吞掉）——实现期落地细则归 overlay §3 回填（§9）。

---

## 3. Tier-2 多裁判量规打分与评测域存储

### 3.1 量规外置与及格分制

非标文本摒弃「判断对错」，采用**量化打分制**（ACI 报告 §2 Tier-2）：评分维度与标准**外置为量规（Rubrics）文件**，不写死在评测代码或裁判 prompt 模板里。量规是**版本化资产**（§16 §1 清单第 4 项）：量规变更会使前后分数不可比，故每次评测结果必须绑定（量规版本，被评资产版本，config_snapshot_id）三元组——没有这个绑定，「新版本分数降了」无法区分是能力退化还是量规变严（绑定机制归 §16 §2）。

**及格分制**：高于及格线判定合规，不做逐分排名崇拜。及格线与维度权重是配置项（零发明数值）；定标方法用相对基准：新版本分数对比同一 golden set 上旧版本（active 资产）的分数分布，显著劣化即拦截——**相对排名优先于绝对阈值**，这是 no-invent 纪律在评测域的形态。

**量规先例承接**（§14 §5.3 移交）：解释层产物的评估轴 = 智识质量——grounded / useful / bounding 三维、with/without-grounding 对照（考古 17 §精华 5 的评估思想，harness 实体不搬）；配套警告同刻进本章合同：**quality eval 分数不可当 alpha**（考古 17 §危险边界 5）——量规分衡量「说得有没有据、有没有用、有没有边界」，永不衡量「赚不赚钱」，两者混同是归因墙（§14 §5.3）在评测域的违章。

### 3.1.1 评测场景：可回放的评测装配单元（canonical）

**评测场景（Evaluation Scenario）**是将一个或多个版本化 golden case 的输入快照、被评版本、Tier-1 可观测量、Tier-2 量规与裁判集、重放方式及允许的非确定性**装配为同一可回放评测单元**的评测域对象。它不等于运行时的业务场景，亦不引入新的 §05 DSL、运行时执行器或独立业务账：其静态承载复用 `golden_sets / golden_cases`，轨迹来源的输入与重放承载复用 §8.1 `golden_trace_replay_v1`，每次执行事实落 §3.6 `eval_run`。

| 概念 | canonical 家 | 评测场景的关系 |
|---|---|---|
| `scenario_class` | §05 / IMC；§3.6 只作运行记录切片维度 | 可被引用以选择业务语境，**不被评测场景替代或改写** |
| `scenario_contract` | §16 随宿主蓝图版本治理的运行时合同 | 可作为被评或被引用资产，**不是**评测场景本身 |
| Evaluation Scenario | **本章 §13** | 只服务离线回归、重放、比较与评测证据，零运行时判断权 |

每个评测场景必须同时绑定：① 输入快照与适用的 `as_of_time` / `data_cutoff_time`；② 被评版本及 `asset_snapshot_refs`；③ Tier-1 `expected_observables`；④ `rubric_version` 与 `judge_model_set`；⑤ `replay_mode` 与 `allowed_nondeterminism`；⑥（可选）**来源策略轴**——`source_policy_snapshot_id + policy_hash`（§16 §2.3 子快照）+ `policy_mode`（`not_applicable`｜`as_ran`｜`counterfactual`｜`current_policy_validation`）。**缺省语义三分**：未绑定来源策略轴 → `policy_mode = not_applicable`（**不伪装 as_ran**）；绑定已有原 run → 可缺省 `as_ran`（沿原 run 冻结策略）；**没有原 run 的首次历史场景 → 必须显式声明并冻结 baseline `source_policy_snapshot_id` 后方可运行**，counterfactual 必须引用该 baseline、不得凭当前声明临时生成不可比较基线（§17 §5.8 同源）。`policy_mode` 只描述来源策略实验语义，**与 ⑤ 的 `replay_mode`（single｜monte_carlo｜shadow｜ab_test）正交、不得复用或覆盖彼此枚举**——同一 `eval_run` 可同时是 `replay_mode=ab_test` 与 `policy_mode=counterfactual`。这些组分别已有 canonical 落点（§8.1、§3.6 字段组 6/10/12），本节只定义其不可拆散的评测语义，**不另造 `evaluation_scenarios` 表、第二套快照字段或第二套版本绑定规则**。

评测场景的实现面可按既有边界独立落地：golden case / manifest 的版本与校验、Tier-1 执行、Tier-2 裁判与校准、`eval_run`/报告/晋升证据的记录；任一实现面先只沿 `评测场景 → runner → evaluation.db` 单向流动。离线 fixture / mock / replay 的评测结果以报告或审阅为终点；只有同时满足 §6 晋升验收单、§03 committed 来源与 §04 非 mock 数据闸的证据，才可形成 `promotion_evidence → 用户显式核准 → §16 资产晋升` 的后续链。不存在从裁判分、量规结果或报告直接回写 `domain.db`、voter、正式信号或交易执行面的管道（§3.4、§14 §5、§6）。

### 3.2 多裁判聚合抗流畅度偏见

单裁判 LLM 打分有已知病：**流畅度偏见**——文笔流畅的产物拿高分，与事实质量无关（ACI 报告 §2 幻觉抑制段）。本章合同：

- **多裁判独立打分**：同一产物由多个裁判（不同视角框架或不同模型）按同一量规独立打分，互不见对方评分；裁判数配置项。
- **盲比较与换位复核**：候选—基线的成对比较必须随机化呈现顺序，并保留换位后的判定与翻转率；绝对量规分用于质量画像，盲 A/B 用于回归方向，二者不可互相冒充。位置敏感或换位翻转是裁判/量规失配信号，不得被聚合平均掩盖。
- **聚合呈现分歧而非硬平均**：裁判分歧本身是信号——分歧大的维度呈现「裁判未收敛」而不是折中分（与 §07 §5.1 共识层「呈现分歧、不编造共识」同构；honest disagreement）。聚合函数确定性（加权平均 + 分歧度标注），权重配置项。
- **反事实锚**：量规内为每档分数给可判定的行为描述（「引用了权威数字骨架外的数值」而非「不够严谨」），把打分尽量推向可核对的判断——量规写得越确定，裁判间分歧越小，这是量规库迭代的方向信号（量规信噪比复核，§8.3）。
- **人工校准锚**：每份新量规与每次裁判集换代均以少量专家已标注 golden case 复核裁判—人审偏离；人审是校准样本，不是每批评测的人工瓶颈。未通过或未记录校准的裁判结果不得与既有基线静默比较，须标为不可比或隔离复核。

### 3.3 裁判模型选型原则与成本量纲（不发明数字）

1. **档位下限**：裁判模型档位 ≥ 被评节点的生成模型档位。理由与 §12 Inspector 的选型同源（25 号 §2.2.1）：弱模型评审强模型产物，评审本身出幻觉——评测体系的错误率必须显著低于被测系统，否则信号全是噪声。档位映射配置项（载体：hermes provider 档位配置，§11 证据）。
2. **裁判独立性**：裁判与被评产物的生成模型尽量异源（至少不同模型，最好不同 provider）——同模型自评有亲和偏见；无论是否异源，裁判 (provider, model) 必须记录进评测结果行，供事后审计「分数漂移是否因裁判换模」。
3. **成本量纲**：Tier-2 是**批次活动不是每 run 活动**——只在 §1 四类触发场景下跑 golden set，不在生产 run 的热路径上打分（25 号 §2.3 的分工含义；生产运行时的质量机制是卫兵，不是裁判）。成本公式量纲 = golden set 条数 × 量规维度数 × 裁判数 × 触发频次，四个因子全部配置项；控制成本的正当手段是裁剪 golden set 分层（冒烟子集 / 全量集）与降低触发频次，**不是**降裁判档位（违反原则 1）。

### 3.4 判断权对齐：评分是评测域产物

Tier-2 分数**不进任何权威决策字段、不进任何 voter 权重水源**（归因墙 §14 §5.3 + advisory membrane §14 §5.1 在评测域的执法）：评测结果只消费于「资产晋升/拦截证据」（§6）与「用户/Inspector 审阅」。存储遵四分离同构：逐裁判逐维度评分张量 = raw（`judge_score_tensors`），聚合及格判定 = bucketed（`eval_aggregate_results`），评测报告 = display（现场合成）；评测产物与主链决策账**物理分库**——落位定稿见 §3.5：独立 `evaluation.db`，归本章。

### 3.5 评测域权威库 `evaluation.db`（三库 triad · 归本章）

§3.4 悬置的物理落位就此收口。**裁定（store-boundary 稿 §2/§16 采编）：评测域主库独立成库 `evaluation.db`，归本章（§13）拥有——不寄生遥测库、不混进域库。** 守护数据由此形成**三库 triad**（与 §03 §5 域库侧裁定、§11 §6 遥测库定稿同一张网，在评测侧补齐第三格）：

| 库 | owner | 主语义 | 承载 | 禁载 |
|---|---|---|---|---|
| `domain.db` / 域库 | §03 | 业务权威状态 | 决策账本 / advisory 记录 / thesis / 候选池 / 风控阈值 | 评分张量、量规结果、高基数遥测 |
| `telemetry.db` | §11 | 过程轨迹 | spans / blobs / schema_docs / 工具·LLM 调用 trace / error span | 评测结果 schema、晋升证据主记录、golden set 主表 |
| `evaluation.db` | §13 | 评测权威结果 | eval_runs / golden_sets / rubrics / judge_score_tensors / eval_aggregate_results / ablation_results / promotion_evidence | 决策账本、业务状态、热路径运行态 |

一句话分工：**telemetry.db 记「发生了什么」、evaluation.db 记「评得怎么样」、domain.db 记「业务上承认什么」。**

**为什么评测结果不塞进 telemetry.db**（三条错配，store-boundary 稿 §3 采编、独立论证）：① **retention 错配**——telemetry 是高频 append、可裁剪、随 TTL 轮转（§11 §6.3）；评测结果是资产治理证据、必须长期保留，否则「某 blueprint_version 为何晋升 / 某 style_profile 为何被拦 / 某次模型升级为何判退化 / 某 golden case 为何被删」皆无从回答；② **查询面错配**——telemetry 主键面（trace_id/span_id/node_id/timestamp）与 evaluation 主键面（eval_run_id/golden_set_id/rubric_version/judge_model_id/asset_version/config_snapshot_id）不同，混库使 telemetry 退化成「所有守护数据杂货库」；③ **权威错配**——telemetry row 只证明「某 judge call 发生过」，evaluation row 才证明「某资产是否通过评测」；telemetry 可作 evaluation 的证据来源，但不能是评测结果的权威主库。

**`evaluation.db` 的 always-apply schema bootstrap（本轮复核补强，与 §03 domain.db、§11 telemetry.db 同等级）**：`evaluation.db` 连接初始化同样遵 §03 宪法第五条 always-apply 幂等 schema 纪律（§11 §6.2 telemetry.db 已定稿的同款义务，本节补齐评测库侧，不新立机制）——每次连接无条件执行 `CREATE TABLE IF NOT EXISTS`（覆盖下文核心表族清单）；新增列走 `PRAGMA table_info` guard 后 `ALTER`；`schema_version` 只作人读记录，不作唯一迁移门；migration fail 即该子系统启动 hard fail；不允许 silent partial schema——`eval_runs`/`golden_sets`/`judge_score_tensors`/`promotion_evidence` 等核心表若因迁移遗漏而部分缺列，后果是「资产晋升证据静默不完整」而非「显式迁移失败」，危害等级不亚于 domain.db 缺表。测试指向 tmp 库（同 §03/§11 宪法）。三库联合 schema smoke test 归 §15 安装/启动期校验（跨文件 seam，本节只锁 `evaluation.db` 自身的 bootstrap 纪律）。

**三库弱引用、无跨库外键**（§11 §6.2「遥测行对域库/彼此只有弱引用」纪律的三库版）：三库经 `trace_id / eval_run_id / asset_id / config_snapshot_id` 弱关联；坏引用是可诊断事实、不是写入错误。**telemetry TTL 轮转不得破坏 evaluation authority**（§11 §6.3 分级保留淘汰的是过程保真度，牵动不了评测库）、**不因 telemetry 缺失删除 evaluation 结果**——这条与 §03 §3.2「三条历史化机制弱关联、不做外键」同族。

**表族的 raw/bucketed/display 三层归属**（§3.4 四分离的物理落位）：raw（`judge_runs` / `judge_score_tensors` / raw judge output handle）与 bucketed（`eval_aggregate_results` / `ablation_results` / `promotion_evidence`）均落 `evaluation.db`、归 §13——raw 不覆盖、bucketed 可重算但留版本；display（`eval_reports` 或现场合成，可携可选 telemetry 引用）由 evaluation.db 生成、非权威记录。核心表族（DDL 实现期，本节锁语义与归属）：`eval_batches / eval_runs / golden_sets / golden_cases / rubrics / rubric_dimensions / judge_runs / judge_score_tensors / eval_aggregate_results / ablation_results / promotion_evidence / eval_reports`。

**写/读边界**：写方 = 评测执行器族（`evaluation_runner / tier1_assertion_runner / tier2_judge_runner / ablation_runner / promotion_gate / inspector_review_writer`）；业务蓝图 / domain analyst 节点 / LLM agent 节点 / 遥测采集器**禁写**评测库（三者不得互相代写，§11 §5.1 遥测单写者的评测域对应物）。读方 = §13 评测报告 / §12 Inspector / §16 资产晋升门 / §17 策略生命周期复核 / 调试工具；蓝图 loader 只读一枚只读视图 `asset_gate_view`（语义此处锁定，字段级 DDL 实现期；五轮复核 5.5 收口）：

```yaml
asset_gate_view:
  asset_id
  asset_version
  pass_block_status
  required_min_version
  promotion_evidence_id
  reason_bucket
```

loader **禁读** `judge_score_tensors` / raw judge outputs / free-form evaluator rationale——loader 只消费晋升门的**结论**（能否加载、要求的最低版本、指向哪条晋升证据行、失败归因桶），不消费评分过程；控制面同样只读资产 pass/block 状态，不越权读打分明细。**业务决策节点（voter / position sizing / formal signal / L1 计算工具）一律禁读 raw judge score tensor**（§3.4 判断权墙在存储侧的执法，同 §14 §5.3 归因墙）。

**promotion_evidence 与 §16 的接缝**：资产（blueprint / style_profile / weight_profile / rubric / prompt_template / scenario_contract / tool_atom / domain_analyst_node）的晋升/拦截/回滚/退役评测证据落 `promotion_evidence`（evaluation.db，§13 owner，可引用 telemetry trace 但权威记录在本库）；§16 资产晋升记录**引用** `evaluation.db.promotion_evidence`、资产定义文件**不内嵌评分张量**，golden set / rubric 是版本化资产（§16 §1 清单 4/6）、其运行结果归本库。**接缝已对齐**（五轮复核 5.1 收口）：`scenario_contract` / `tool_atom` / `domain_analyst_node` 分别登记为 §16 §1 清单条目 8/9/10（限 live runtime 登记，见该清单条目 8-10 限定）；`prompt_template` 即 §16 §1 清单条目 3 的 `node_prompt_fragment`（§06 §4.3/§4.5 已定），本枚举与 §16 术语对齐、非新增资产，不重复挂号。

### 3.6 Evaluation Run Record v2：评测运行记录 schema（record schema canonical 家归本章）

**裁定（收口 OPEN-D）：Evaluation Run Record（下称 `eval_run`）的记录 schema 与 Linked Evaluation Graph（§3.7）的 canonical 家 = 本章（§13），与 `evaluation.db` 同章；§17 回测方法论只引用消费、不拥有该 schema。** store-boundary 稿定 `eval_run` **物理落哪库**（evaluation.db），run-record 稿定 `eval_run` **有哪些字段**——二者是同一 `eval_run` 对象的位置面与 schema 面、无字段互斥，合并归本章。

**从「蓝图回测行」升格为「评测运行记录」**：旧式回测记录只绑 `(blueprint_id, blueprint_version, blueprint_struct_hash, config_snapshot_id)`——对 formal 蓝图结构对比够用，却覆盖不了系统的真实评测对象。除 `formal_decision` 外还有 discovery 挖掘 / decision_precheck 买卖前 gate / event_response 事件唤醒 / linked_alert 联动警报 / thesis_lifecycle 月度复核 / decision_replay 复盘——旧粒度回答不了「这只股谁挖的、被哪些蓝图消费、是否触发 formal、最终 outcome、LLM 多次重放是否收敛」。故 `eval_run` 升级为携产物血缘 + 多次重放的完整审计记录：它**不是蓝图资产、不是运行时执行器、不是新账本，是评测域的事实记录**。

每次评测必声明 `eval_type`（首发枚举实现期定，no-invent）：`financial_backtest / scenario_quality_eval / discovery_eval / linked_alert_eval / replay_eval / l1_contract_test / differential_test / monte_carlo_stability_eval / shadow_comparison / ab_blueprint_eval`。

**十二字段组**（字段级 schema 与首发枚举授权实现期，本节锁字段组语义与归属——同 §18 §3.3「schema 单一真相在本节、枚举首发集实现期」纪律；枚举值集中 `style_profile`/`blueprint_family` 成员集不在本章定死，随其 canonical 章）：

| # | 字段组 | 关键字段（代表，非穷尽） | 语义/纪律 |
|---|---|---|---|
| 1 | Run Identity | `eval_run_id`（唯一键）/`eval_batch_id`/`eval_type`/`eval_status`(planned/running/completed/failed/quarantined)/`created_at`/`executed_at`/`eval_trigger_reason` | 本次评测的身份与批次锚 |
| 2 | Blueprint Identity | `blueprint_family`/`blueprint_id`/`blueprint_version`/`blueprint_struct_hash`/`blueprint_config_hash`/`blueprint_kind`/`blueprint_tags_snapshot`/`config_snapshot_id` | struct_hash 只代表拓扑；**scenario_class/style_profile/weight_profile 不得伪装成 struct_hash**——若 style 或 scenario 改了 DAG 必晋升新 blueprint_id/version（§16 §2 结构哈希绑定纪律：结构哈希只锁拓扑） |
| 3 | Account & Authority | `account`/`authority_level`/`output_authority`/`write_scope`/`formal_write_allowed`/`advisory_boundary_violation` | scenario_class/style_profile 不覆盖 account（§05 §2.2 引擎账别执法）；advisory eval 结果不写 formal ledger；quality eval 分不当 alpha（§14 §5.3 归因墙、§3.1） |
| 4 | Scenario Context | `scenario_class`/`scenario_contract_version`/`scenario_contract_hash`/`trigger_class`(user/cron/event/system)/`latency_class` | scenario_class 是 `eval_run` 的**切片维度**、非评测库拥有者（场景轴归 §05/IMC） |
| 5 | Style & Weight Profile | `style_profile_id`/`_version`/`_hash`/`style_effect_type`(display_only/decision_affecting/topology_affecting)/`weight_profile_id`/`_hash`/`factor_weight_snapshot`/`veto_rule_snapshot` | display_only → `differential_test`（§2.1 条 4 差分断言）；decision_affecting → 进 `financial_backtest` 切片；topology_affecting → 不得作 style、必晋升蓝图 |
| 6 | Data Time & PIT Guard | `as_of_time`/`decision_time`/`data_cutoff_time`/`market_calendar_id`/`data_snapshot_id`/`pit_dataset_version`/`data_quality_score`/`data_trust_level`/`future_leakage_guard_version`；**来源策略轴**：`source_policy_snapshot_id + policy_hash`（§16 §2.3 子快照——与 `data_snapshot_id` 分别版本化：数据快照答「看到哪批数据」、策略快照答「按什么规则选择/排除/回退」）/`policy_mode`(not_applicable｜as_ran｜counterfactual｜current_policy_validation——**与组 10 `replay_mode` 正交，不得复用枚举**；未绑轴=not_applicable)/`historical_source_availability_manifest_ref`/`actual_selected_source_refs`/`excluded_sources_and_reasons`（§04 §8.7 同源 reason 家族）/`fallback_decisions` | financial/discovery/linked_alert eval 必绑 as_of_time + data_cutoff_time；无 PIT 版本不得进正式回测汇总（§17 §5.3 双时态防穿越、§04 §1.2 条 1 PIT 纪律、§8.2 评测不豁免 PIT）。**来源策略语义**：`as_ran` 锁原始策略/数据快照与实际 source refs，缺任一关键快照只能 `partial`/`unavailable`、不得用当前允许来源静默替代；`counterfactual` 只改变 source policy 轴，蓝图/模型/其他配置/PIT 与 cutoff 守恒（单变量 A/B）；**不做来源 × 蓝图 × 模型全排列**（首发 = 一个 baseline + 少量用户显式替代策略，§17 §5.8） |
| 7 | Target Scope | `universe_id`/`universe_snapshot_hash`/`ticker`/`ticker_set`/`portfolio_id`/`position_snapshot_id`/`thesis_id`/`thesis_snapshot_id`/`risk_threshold_snapshot_id`/`sector_or_industry_id` | 按 eval_type 条件必填（单股/组合/discovery/thesis 各取所需） |
| 8 | Lineage: Upstream & Downstream | 上游 `root_artifact_id`/`parent_run_id`/`source_artifact_type`/`discovered_by_run_id`/`candidate_id`/`alert_id`/`replay_case_id`；下游 `consumed_by_run_ids`/`formal_trigger_candidate`/`formal_run_id`/`thesis_record_id`/`review_run_id`/`event_response_run_id`/`linked_alert_run_ids` | Linked Evaluation Graph 的边料（§3.7） |
| 9 | L1 Calc / Schema Snapshot | `calc_slot_manifest_hash`/`script_versions`/`schema_versions`/`calc_outputs_refs`/`required_calc_missing`/`llm_permission_scope`(explain_only/summarize/compare/no_calculation) | LLM 不得计算关键数值、关键指标来自 L1 calc slot（§14 纪律一）；缺 required calc 记 degrade_reason |
| 10 | LLM & Monte Carlo Replay | `model_id`/`_version`/`prompt_template_hash`/`system_policy_hash`/`temperature`/`top_p`/`seed`/`llm_call_count`/`replay_mode`(single/monte_carlo/shadow/ab_test)/`replay_count`/`sampling_policy`/`aggregation_method`/`variance_metric`/`consensus_threshold`/`epistemic_variance_baseline_key` | 非确定性原则见 §3.7 Monte Carlo 契约 |
| 11 | Outcome Metrics | 按 eval_type 分组、不共用同一指标口径（见下表） | outcome 分流 |
| 12 | Governance & Audit | `judgment_boundary_hash`/`policy_violation_flags`/`future_leakage_flag`/`advisory_boundary_violation`/`quarantine_flag`/`quarantine_reason`/`approval_status`/`golden_set_id`/`rubric_version`/`judge_model_set`/`blind_pair_id`/`presentation_order`/`position_flip`/`calibration_anchor_set_version`/`calibration_status`/`cost_profile`(latency_ms/token_in/token_out/estimated_cost) | 判断权/账别/数据规则违规审计；绑 rubric_version + judge_model_set（§3.1 三元组绑定），保留盲比较与裁判校准的可审计坐标（§3.2） |

**outcome 按 eval_type 分流**（不同 eval_type 不共用指标口径，数值口径实现期 no-invent）：

| eval_type | 主对象 | outcome（代表） | 责任边界 |
|---|---|---|---|
| `financial_backtest` | formal_decision | PnL / alpha / 回撤 / 胜率 / Sharpe / return_windows(T5..T252) | — |
| `discovery_eval` | discovery 挖掘 | 候选质量 / 后续验证率 / formal 转化率 / thesis 存活率 / 最早发现 rank | 不直接背交易 PnL |
| `linked_alert_eval` | 联动警报 | 提前量 / 命中率 / 误报率 / 严重度校准 / formal 重估触发率 | 不等于交易信号 |
| `replay_eval` | 复盘模拟 | 归因稳定性 / hindsight bias / 规则提炼质量 | 不反向改写历史结论 |
| `scenario_quality_eval` | advisory 场景 | 模板遵守 / 风险遗漏 / 降级正确性 / formal 触发正确性 / grounding·usefulness·bounding | 质量分不当 alpha（§3.1） |
| `l1_contract_test` | scripts/schemas | schema_pass / deterministic_pass / pit_pass / 数值容差 | — |

**推荐核心索引**（实现期）：`blueprint_id/version/struct_hash · scenario_class · style_profile_id · weight_profile_hash · config_snapshot_id · as_of_time · data_snapshot_id · account · eval_type`；discovery/linked 另备 `root_artifact_id/candidate_id/source_artifact_id/parent_run_id/formal_run_id/ticker`；Monte Carlo 另备 `replay_mode/replay_count/aggregation_method/epistemic_variance_baseline_key`。**与 §16 绑定对齐**：`eval_run` 的 (blueprint version, struct_hash) + 量规版本 + config_snapshot_id 三元组绑定复用 §16 §2.5「评测结果行绑定」既有落点——本节把该行的字段面展开为十二组，不新立绑定机制。

### 3.7 Linked Evaluation Graph 与 Monte Carlo 重放契约

**Linked Evaluation Graph = 评测域产物血缘图**（run-record 稿 §18 采编）：系统**不做**「所有蓝图 × 所有股票 × 所有场景 × 所有流派」的指数级全排列，而**沿真实产物链路评测**——沿 `discovery candidate → precheck → formal decision → thesis → event alert → review/replay → outcome` 的真实生成链。节点 = run/artifact/outcome（`EvaluationRun / BlueprintRun / CandidateList / CandidateStock / PrecheckResult / FormalDecision / ThesisRecord / EventAlert / LinkedTickerAlert / ReviewRecord / ReplayCase / OutcomeWindow`）；边 = 发现/消费/触发/接受/拒绝/复核/复盘/警报/观察（`produced / consumed / triggered / accepted / rejected / reviewed / replayed / alerted / observed`）。血缘边由 `eval_run` 字段组八（§3.6）的上下游引用物化，Graph 存储表结构实现期定（no-invent）。

**评测责任边界**（每模块按自身产物类型担责、不越界）：`formal_decision` 担财务回测、不背 discovery 召回；`discovery` 担候选质量/验证率、不直接背交易 PnL；`decision_precheck` 担 gate 完整性/误放行率、不直接背 alpha；`event_response` 担冲击识别/触发正确性、不直接出买卖；`linked_alert` 担提前量/命中率、不直接背交易收益；`thesis_lifecycle` 担衰减识别/复核及时性、不替代 formal 决策；`decision_replay` 担归因稳定性/规则可复用、不事后重写历史账。一句话：**discovery 不背全部 PnL、alert 不等于交易信号、replay 不反向改写历史结论。**

**Monte Carlo 重放契约**（承 §07 council 多裁判 + §17 §5.2 蒙特卡洛多路回放的评测侧记录合同）：凡 LLM 参与且影响判断的历史测试点，**不能只跑一次**——`Temperature=0` 在智能体框架下是虚假确定性、掩盖 LLM 固有内在方差（§17 §5.2）。对每个被捕获抉择点用相同蓝图 + 物理隔离执行 N 次独立重播（N 配置项 no-invent），记录并输出**分布聚合而非单次答案**：
- 必填输出：`verdict_distribution / confidence_distribution / degrade_rate / consensus_rate / entropy / epistemic_variance / outlier_runs_ref`；
- 聚合裁定（承 §07 §5.1「呈现分歧不编造共识」、§3.2 多裁判聚合同构）：高一致率 → 可形成稳定结论；中一致率 → 呈现分歧；低一致率 → 标记认知方差高、禁强收口；数据不足致分歧 → 降级不强行决策。**聚合不是简单平均、是分布收敛判断**（§3.2「加权平均 + 分歧度标注」的记录侧对应，`aggregation_method` ∈ majority_vote/conservative_merge/distributional_summary/ensemble_verdict/no_aggregation）；
- **`epistemic_variance` 即 §13 三维评测认知维度、§17 Detection 料源**：Monte Carlo 方差就是 §17 §2.2 认知维度分——回测记录侧与 §17 v1 守护回路**共用同一量纲、不是两套指标**（§17 §5.2 已锁，本节记录侧承接）。

**血缘图/契约与 §17 消费的分界（OPEN-D 落定）**：§13 拥 Linked Evaluation Graph 与 Monte Carlo 契约的 **record schema**（与 evaluation.db 同章）；§17 §5 回测方法论**引用消费**这套记录——回测在 testing 态跑出的三维分作为 §17 §4.5 蓝图重构晋升验收单（§13 §6）的 Tier-2 证据来源，但回测记录本身落 `evaluation.db`、schema 归本章（§17 §5 交叉引已对齐）。

### 3.8 建议-结果校准边（per-user Brier · §14 §2.7 通道三）

投资者本人建模纪律的第三枚判断权钉子落在评测域——**系统对某用户的建议置信 vs 该用户已实现命中的校准是评测轴、非 gate**（§14 §2.7 通道三）：

- **归评测轴 + 材料层反馈，不是硬门**：per-user 校准用 Brier / 严格 proper scoring 打分（数值 no-invent，打分实现期），落评测域产物（同 §3.4「评分是评测域产物」的判断权对齐）；反馈形态同 legacy 质量评估——**统计反馈不阻断当次决策**，只调后续参考阈值（§07 §5.1 win_rate 冷启动同款、§3.1 及格分制的相对基准精神）。
- **🔴 校准分 ≠ alpha、禁进 voter 权重水源**（归因墙 §14 §5.3 + §3.1 在 per-user 校准的执法）：建议置信的校准度量衡量「系统对这个人报得准不准」，**永不进 win_rate / 任何 voter 权重 / signal / confidence / 阈值表**——把校准分当 alpha 是归因墙违章（换接受者不改标的评估，§14 §2.7 判断权自检）。
- **料源与承载**：料源 = §03 thesis 账 + win-rate + outcome 回填族的 **per-user 采纳/校准 facet**（§03 §3.6 承载③复用，零新建库）；校准评测作一条评测轴挂 §1 触发场景的批次活动（非生产热路径），可作 `scenario_quality_eval` 谱系的 per-user 维度或实现期新增 `eval_type`（首发枚举实现期定 no-invent，§3.6）；其分布进材料层反馈，供用户/主体审阅（§10 呈现），永不写回 prefetch 源表或权威账。

**校准对象模型（记录语义四件套 · 源 `13-two-tier-eval/advisory-outcome-calibration-contract.md`）**：本边的记录语义收口为一条链——`advisory_recommendation_record`（系统当时建议了什么）→ `user_adoption_event`（用户如何处理）→ `outcome_window_record`（窗口内结果如何）→ `calibration_summary`（按 user / scenario_class / blueprint_family / confidence bucket 聚合校准）。它是建议关系的仪表盘、不是自动学习发动机；字段级 schema 形状示意、实现期（未决 #9）：

- **recommendation 记录**：锚 `decision_id / run_id / trace_id` + 标的与建议类型（buy / add / hold / reduce / sell_review / watch / avoid / observation_only——校准侧描述性枚举，动作语汇 canonical 归 §07 菜单/共识出口）+ confidence（raw/bucket 双轨，§14 §2.4）+ horizon + 输入引用族（portfolio_lens / market_temperature_state / thesis / briefing / per_stock_profile 的 id 引用）+ advisory 边界字段（execution_free / user_decision_required / no_broker_action 恒真）。formal 决策产物默认登记；advisory run 按需登记（用户要求跟踪 / decision_precheck / 产物带 confidence bucket）。
- **采纳申报硬边界**：`adoption_status ∈ accepted / ignored / rejected / modified / unknown`，**只能来自用户显式申报、否则保持 unknown——禁一切推断**（LLM 推断采纳、聊天暗示当交易、watchlist 当持仓、旧 thesis 当仓位，全禁；§03「agent 永不推断持仓」纪律的校准侧同族）；申报入口 = §10 主体对话显式申报（§10 §10.1 交互合同条 5）。券商成交导入（§03 承载物 #15 高敏 PII 账）仅在用户授权下作采纳/结果匹配佐证——**永不写 `portfolio_book_input`、不成持仓权威、不开执行通道**。
- **outcome 窗口度量全确定性**：窗口族（5d / 20d / 60d / thesis_horizon——配置注册、零硬编码阈值）+ 价格与基准只认 §04（PIT 检查随行）；realized / benchmark return、alpha、MAE / MFE、hit_label、Brier 分量、reliability gap 一律确定性计算，窗口未到期不评（`not_due` 诚实态）；**LLM 禁产任何度量与 adoption 状态**，只写校准解释与教练性反思措辞（材料层，§14 §5 membrane）——其 Tier-2 量规轴：区分建议质量与市场随机性、不指责用户、不 overclaim 因果确定性、显式样本量限制、守 advisory 措辞。
- **advice-fit / regret-fit 定性维度补强（本轮复核补强，答「偏窄成 per-user Brier」的缺口）**：Brier / proper scoring 只答「置信度校不校准」，答不了「这条建议是否适合这个用户、用户事后是否后悔、是否漏提当时应披露的风险、表达是否清楚、是否符合 IPS/constraints」——这几维不是 Brier 的延伸，是独立的 advice-fit / user-fit / regret-fit 判断轴，不新开顶层记录对象、就地加进既有四件套：`user_adoption_event` / `outcome_window_record` 各加定性字段——`ex_post_regret_bucket`（事后后悔分档，只来自用户显式申报或 §10 主体显式征询，未申报保持 `unknown`，同本节「零推断」纪律，不由 LLM 推断用户情绪）、`clarity_score`（Tier-2 量规打分：建议表达是否清楚，非 LLM 自证）、`constraint_fit`（对照用户 IPS/constraints 的符合度判定，确定性规则或量规皆可）、`missed_risk_flag`（是否漏提当时应披露的风险，Inspector 归因或量规回溯标注，同 §4 协作缝 1 的失败样本沉淀来源）；连同既有 Brier 分量一并落 `calibration_summary`（同 §3.5 `evaluation.db` 落位，不新建库/新建顶层对象）。**执法面不变**：不写 formal ledger、不自动改策略/用户模型，只供 §13/§10/§14/§17 复核——本节既有纪律原样覆盖这四个新字段，非例外。
- **落账沿本节既定**：采纳 / outcome facet 复用 §03 §3.6 承载③（thesis 账 + win-rate + outcome 回填族 per-user facet，零新建承载物）；`calibration_summary` 与打分张量 = 评测域产物落 `evaluation.db`（§3.4 / §3.5；对 recommendation / decision_id 弱引用、无外键——§3.5「禁载决策账本」纪律不破）；决策账本行零改动（可被 recommendation_id 弱引用）。
- **与 §17 的分界与只读消费**：§17 盯「蓝图是否腐烂」、本边盯「建议关系是否校准」。§17 可只读消费校准聚合作证据（高置信重复假阳、场景性过度自信、蓝图家族校准漂移）；但校准**禁自动隔离/重写蓝图、自动升降策略、自动调 voter 权重、自动改用户申报画像**——任何此类动作须分别过 §17 / §16 / §13 治理与用户核准（本节「统计反馈不阻断当次决策」的执法面）。采纳关系类行为反馈 flag（「反复忽略高质量警示」「blocked 温度下反复追高」等）只进材料层教练反馈；深度行为偏差诊断的 canonical 家仍是 §03 §3.6 行为诊断专表（§14 §2.7 通道二，证据门控）。
- **Tier-1 断言族**（§2.1 纪律断言延伸）：recommendation_id 唯一、decision_id 可解、**零推断采纳**、窗口未到期不评、MAE / MFE 价源 §04、Brier 确定性、broker 导入零 portfolio 权威写、正式账零改动。golden 种子三例（进 §8.2 golden set 家族）：未申报采纳（unknown 保持 + 零推断 + 可按 recommendation-only 继续跟踪）、高置信假阳（Brier 记误 + 零自动改蓝图 + 聚合标注过度自信）、券商导入申报（source 标注 + 零 book 写 + 零执行通道）。
- **非目标**：不做自动交易、自动策略演化、自动调权、自动改用户风险画像、broker 同步、税务收割、持仓重建为权威——它衡量「建议是否校准」，不决定「下次自动怎么交易」。

## 4. 与 §12 Inspector 的分工边界

骨架 §13 待答「与 §12 分工边界定稿」，按 25 号 §2.3 采编正文化：

| | **§13 双层评测框架** | **§12 Inspector 审计智能体** |
|---|---|---|
| 职责 | **Regression Scoring（宏观回归打分）** | **Runtime Attribution（运行时归因）** |
| 回答 | 「新版本整体能力 **What & How well**」 | 「这条轨迹为什么失败 **Why & How**」 |
| 粒度 | 批量——golden traces 全集 | 单体——特定执行轨迹 |
| 时机 | CI / 版本升级期 / 晋升评估期（离线批次） | 批次落盘后 / 崩溃瞬间（双轨异步 hook） |
| 机制 | Tier-1 确定性断言 + Tier-2 量规裁判网络 | 顶级推理模型沿因果链跨域归因 |
| 产物 | 评测结果行 + 拦截/放行信号 | 结构化溯源报告（物理隔离归档） |

**协作缝两条**（分工不是隔绝）：

1. **归因 → 回归**：Inspector 归因出的失败样本（毒轨迹 + 根因标注）是 golden traces 的一级积累来源（§8.1 通道 2）——「一次事故变成一条永久回归项」，这是 legacy「已归档但验证不完整的 change 追加 marker 承认」纪律（考古 20 §OpenSpec verification gate）的正向形态。
2. **回归 → 归因**：评测发现退化 → 消融协议定位到毒组件（§5.3）→ 若拨开关后仍无法解释（多 flag 交互效应），移交 Inspector 做单体深挖——消融回答「哪个组件」，Inspector 回答「组件内哪一步」。

数据面：两者都只读 §11 遥测（AOI 只读接口），互不写对方产物；评测库与审计报告目录都与主链物理隔离，防知识库污染（§12 同款纪律）。

---

## 5. 特性开关消融

### 5.1 flag 包裹纪律

ACI 报告 §3 的强制要求采编为合同：**任何改变 LLM 可见上下文、蓝图拓扑、调节通道或工具面的新功能，必须被 Feature Flag 包裹后进入系统**。报告三例（新查询工具、变更视角节点 prompt、引入新协作链路）的通则化判据：改动是否可能改变**非确定性节点的行为分布**——是，则包 flag；否（纯确定性 bugfix、有 Pass/Fail 测试锁定的公式修正），走传统测试即可，不强行包裹（防 flag 通胀）。

flag 的注册、六模式生命周期、退役纪律与注册表载体归 §16 §3.4（资产治理面）；本章持有的是**评测义务面**：每个 flag 登记时必须声明它的回归验证形态（哪个 golden 子集、哪些断言/量规覆盖它），无验证形态声明的 flag 不得晋升出 experimental。

**coverage 面显式枚举（本轮复核补强，答「判据只谈蓝图节点」的覆盖缺口）**：上述通则化判据（是否可能改变非确定性节点的行为分布）本身不变，但覆盖面不止蓝图节点——以下变更源同样受 flag 包裹与本节评测义务约束，显式列出防实现期遗漏：

```text
- new calc_slot required by IMC（附录 A5 registry item 新增/收紧）
- new MCP data domain / tool（§04 数据域注册表新增）
- new PrefetchSource entering MemoryProvider（§10 §9.1 供料源新增）
- new advisory_material entering prompt/context（Atomic Registry advisory_material 新登记，同§3 缺漏 4 live-gate 判据）
- new event producer（§09 producer_registry 新增，§11 §5.3 心跳补强同批）
- new AOI view exposed to subject/Inspector/eval（§11 §7 per-consumer ACL 新增视图，须同批声明进入哪个消费者档）
- new L2 memory_view channel（§05 节点契约 memory_view 声明新增）
```

七类中任一变更缺 Feature Flag 包裹或缺回归验证形态声明，视同违反本节合同；注册表载体与生命周期仍归 §16 §3.4，本节只补「覆盖面不止蓝图节点」这一判据边界。

### 5.2 六产品模式与 byte-identical 义务

legacy 大量能力以 `VA_*` env-gate 存在，考古书的重构启示是把 gate 整理成六个清晰产品模式（考古书 L1142-1153）：**default / advisory / shadow / experimental / operator-only / disabled**，每模式有可见配置、测试覆盖与呈现表示。本章承接其中**测试覆盖**义务：

- **gate-off byte-identical**：flag 关闭时行为与引入前逐字节一致——legacy 保护旧行为与热路径成本的主要上线手段（考古 12 §精华 10、§Env gates L1405-1415），升格为 Tier-1 差分断言族的常规成员（§2.1 条 4）；§07 §5.4 的 LLM 元仲裁 byte-identical 契约测试、§06 §6.4 的拓扑退化声明式完成，都是它的既有实例。
- **shadow 模式的评测义务**：shadow 路径产物进遥测过程层（§07 §5.5 先例），评测框架从过程层批量取 shadow-vs-权威对比作晋升证据（§6）——「先观测再晋升」（考古 10 精华 4）的机器化。
- **模式即默认值纪律**：mode-gated 新能力缺省关、gate-on 才启用（本书工程不变量）；「.env.example 推荐 ≠ 代码默认」的 legacy 教训（考古 20 摘要 2、三态册 EM-14 成熟度要点①）由 §15/§16 的注册表可见性防再犯。

### 5.3 消融协议

系统出现退化（分数掉、断言红、行为漂移）时的定位协议（ACI 报告 §3 采编 + 本章细化）：

1. **零代码修改**：只在配置层拨动 flag（Toggle Off），不动任何代码——git revert 在多智能体非确定性环境下代价高且慢（报告论证采编：revert 混合了多个变更的效应，flag 是单变量）；
2. **同一基准**：每种开关组合跑**同一套** Tier-1 + Tier-2 golden 回归——评测集不变是控制变量的前提；
3. **搜索策略**：默认**一次一 flag、按引入时间倒序**逐个关（最新引入的最可疑）；组合爆炸时按嫌疑分组二分。交互效应（单关任一都不复现、同关两个才复现）超出消融的定位能力，移交 Inspector（§4 协作缝 2）；
4. **定位产物**：毒组件的 flag 名 + 开/关两态的 traces 与评分对比落评测库，作为该 flag 降级（→ disabled/experimental）的核准证据（§16 审计轨迹）。

---

## 6. 显式晋升缝验收单（两个定稿章挂靠待办的正面作答之一）

全书已积累一族「shadow/gated → 权威」的显式晋升缝：LLM 仲裁晋升（§07 未决 #1）、PM deterministic action 替换（§07 §5.5）、veto 家族破例（§14 未决 #5）、挖掘候选自动晋升解封（§08 未决 #7）、token 级恢复重启（§10 §4）。它们的验收单写法归 §13/§16——本节给**通用模板**（证据侧归本章，审计侧归 §16 §3.2）：

**晋升验收单五要素**：

1. **Flag 前提**：候选能力已按 §5.1 包裹，处于 experimental 或 shadow 模式，gate-off byte-identical 断言在册且绿；
2. **shadow 观测期**：产物随生产 run 进遥测过程层，观测样本量达配置下限（数值 env 配，不发明）；观测窗内 shadow-vs-权威的一致/分歧分布落账；
3. **双层评测证据**：Tier-1——候选路径全部契约断言绿（含权限校验类：如仲裁 verdict 值域锁）；Tier-2——候选产物在指定量规上对比**权威路径基线**不劣化、在立项声称的改进维度上有可复核的优势（相对排名，无绝对阈值发明）；
4. **用户显式核准**：评测证据呈现给用户，核准记录落审计轨迹——机器证据没有自动晋升权（§08 §3.5 自动晋升默认关同构；「不得未立 spec 就提升」，三态册 EM-10 L401）；
5. **版本与回退**：晋升 = 新资产版本/新 flag 模式落 §16 注册表 + 审计轨迹；回退路径预登记（拨回 flag 即回旧行为——byte-identical 断言保证回退真的是旧行为）。

**实例填写 · LLM 仲裁晋升（§07 未决 #1 正面作答）**：对照基线 = deterministic tiebreak（现权威路径）；Tier-1 项 = verdict 权限校验（action ∈ lanes 已提集、值域合法）+ byte-identical 契约锁在 shadow 期持续绿 + 晋升后「一致度列仍写 voter 真实票份额」的字段语义断言（§07 §5.4 语义不被覆盖）；Tier-2 项 = 高分歧 golden 子集上「仲裁裁决合理性」量规（裁决是否引用冲突双方依据、是否给出可复核理由）双路对比 + shadow 观测期 agree/disagree 分布（agree 率高说明晋升无增量、disagree 且 LLM 更优才有晋升理由——两头都要呈现）；样本量下限与观测窗配置项。**PM deterministic action 替换走同一张单**，方向相反（把 LLM 菜单选择替换为确定性路径）：基线 = 现 LLM 选择，Tier-2 对比维度 = 决策质量量规而非稳定性——legacy 观察只证明 deterministic 更稳、未证明质量更优（§07 §5.5 遗留警告），验收单必须正面补这个证据。

---

## 7. §06 层级裁剪 A/B 实验设计合同（挂靠待办正面作答之二）

§06 §5.2 对 18 号报告强裁剪的偏离（权威数字骨架不裁剪）**本身未经实证**，设计成可实验变体、实证归本章（§06 未决 #4）。实验设计合同：

- **变体**：V1 层级裁剪（§06 推荐默认：数字骨架全量 + 材料立场化选配）vs V2 强裁剪（18 号原案：数字骨架同进裁剪面）。两变体只差 DSL `state_view` 声明（§05 §2.2），零代码分叉——拓扑消融由 DSL 声明式完成（§06 §6.4 同款机制）。
- **控制变量**：同一 golden facts 集（mock fetcher 注入，§2.2）、同一视角配置集、同一辩论轮次预算、同一下游节点链；仅 `state_view` 不同。
- **度量（双层）**：
  - Tier-1 差分断言：**幻觉填补率**——V2 视角产物中出现被裁剪域的数字（锚定检查直接抓）与被裁剪域的定性断言（关键词域词表匹配，词表随量规库维护）的条数；**可反驳性坍塌率**——辩论层中论点被对方以 do-not-dispute 权威数字直接击穿的比例（回应性结构检测的延伸，§06 §6.5 验证器 2 同机制）；
  - Tier-2 量规：单链论证深度（18 号立论的正面收益是否真实出现）、synthesis 质量、风险承认段的完整性——V2 的预期优势与预期代价各设维度，两头都量。
- **判定原则**：呈现两变体在全部维度上的相对排名与分布，**不预设哪边赢**（§06 的偏离依据是 grounded-first 铁律推理，不是数据）；裁决权在用户——若 V2 在论证深度上显著占优且幻觉填补可被卫兵兜住，§06 推荐可以被推翻，这正是把偏离设计成变体的意义。
- **同套机制复用**：§06 §6.5 的四件验证器（baseline 对照 / 回应性 / lane 翻转 / 急于趋同）与本实验共用 golden facts 集与差分断言设施——一次投入五份回报。

---

## 8. golden traces 积累通道（合同桩）与全书评测积压登记

### 8.1 三条积累通道

golden traces（黄金用例：输入 + 轨迹 + 期望断言/基线分数）的来源合同：

1. **遥测库回放候选**：生产 run 的 Frame Lifetime Trace 天然是回放素材——从过程层筛选代表性轨迹（成功典型 + 边界 case），配套其输入快照固化为评测项。**§11 已定稿（AOI 取证 / 查询 / blob handle + per-consumer view ACL 的 `eval_runner: golden_trace_view/eval_lineage_view`，§11 §7），本条回填 `golden_trace_replay_v1` 回放合同**（字段级形状示意 no-invent；复用 §3.6 `eval_run` 十二字段组、不新立绑定）：

    ```yaml
    golden_trace_replay_v1:
      trace_selector:          trace_id / scenario_class / blueprint_id / asset_version / data_cutoff_time
      input_snapshot_manifest: user_visible_input_ref / data_result_refs / prefetch_bundle_ref / tool_visibility_manifest_ref
      asset_snapshot_refs:     blueprint_version / rubric_version / feature_flag_snapshot / config_snapshot_id
      source_policy_replay:    source_policy_snapshot_id + policy_hash / policy_mode(not_applicable|as_ran|counterfactual|current_policy_validation)
                               #   未绑轴 = not_applicable（不伪装 as_ran）；绑原 run 缺省 as_ran；无原 run 首跑须先显式冻结 baseline
                               #   / actual_selected_source_refs / excluded_sources_and_reasons / fallback_decisions
                               #   / historical_source_availability_manifest_ref —— 可选轴，§3.6 字段组 6 同源，不新立绑定
      replay_mode:             deterministic_nodes_only | llm_rejudge | full_shadow_replay
      expected_observables:    hard_assertions(Tier-1) / tier2_scores / regression_thresholds
      allowed_nondeterminism:  model_variance_window / judge_variance_window / unavailable_external_data_policy
    ```

    **`asset_snapshot_refs` 的术语边界**：本章此处及全文的 asset 指受版本治理的评测相关系统资产——例如 blueprint、rubric、feature flag、config；模型/provider 版本另按 §3.6 字段组十记录——**不指 ticker、持仓或任何金融投资标的**。上述 canonical 字段名保持为 `asset_snapshot_refs`，实现期不得并行再造语义相同的 `evaluation_asset_snapshot_refs`。

    职责分工：**§11 AOI** 取证/查询/blob 读取；**§13 runner** 选 golden trace、执行重放、记结果（落 evaluation.db `eval_run`，§3.6）；**§16** 校验 `asset_snapshot_refs` 与 manifest 一致（restore 后经 §15 §5.4 post_restore_audit）；**§15** 定 CI/本地运行入口与失败策略——回放失败须区分**系统退化 / 数据缺失 / 环境不可重建**三态（`allowed_nondeterminism` + `unavailable_external_data_policy` 划界，PIT 缺数走 §17 §5.7 / §04 unavailable 非中性）；
2. **Inspector 归因样本沉淀**：§4 协作缝 1——每份溯源报告的失败轨迹默认成为 golden 候选，根因标注即断言来源；
3. **人工构造**：用户/评审标注的代表性任务（含 §10 双工具路由三档分类集、§08 候选质量样本），以及**植入违规样本**——为卫兵自审计构造的已知违规产物（引 facts 外数字的 rationale、伪造 quote 的 briefing），验证卫兵命中率与 flag-only 标注信噪比（§14 §4.4/未决 #3 的承接面；构造法与信噪比量规归量规库维护，未决 #4）。

### 8.2 golden set 资产义务

golden set 是版本化资产（§16 §1 清单第 6 项）：每条目带输入数据快照（mock fetcher 可离线重放，§2.2 前提）+ PIT 语义（重放禁止读取条目时点之后的数据——评测不豁免 PIT 纪律，§04 §1.2 条 1）+ 期望断言/基线分数 + 来源标注（通道 1/2/3）。set 变更走资产治理（增删条目 = 新版本，防「悄悄删掉跑不过的用例」——评测体系自身的验证不信任）。

**首发最小评测场景**：`grounded_advisory_explanation` 以冻结的财报/事件 facts 评测 advisory 解释，是本章 §3.1.1 的 P0 seed，而非新业务能力。其 Tier-1 锁 facts/provenance、数值权威、mock 隔离、staleness 状态可见且按 §04 数据域策略处理，以及 advisory/account 边界；Tier-2 先按 grounded / useful / bounding / uncertainty handling 这组 **P0 候选维度**评分并呈现裁判分歧，行为描述与其是否进入全局量规初始集仍归本章未决 #1。它只使用离线快照、只产 `evaluation.db` 回归证据；该离线证据本身**不得**形成 `promotion_evidence`，不接生产运行时写面、不宣称收益或 alpha、也不构成 §17 长期回测的替代品。

### 8.3 全书评测积压登记表

各定稿章显式挂到本章的定标/验证项，登记如下（本表是账不是新义务；逐项落地随实现期评测立项）：

| 来源 | 项 |
|---|---|
| §10 未决 #3/#7 | 任务边界判定规则原型验证；双工具路由正确率三档分类 golden 集 |
| §10 §7.3 | 吸收验收 checklist 中标「评测项」类的回归集编入 |
| §05 未决 #4 | 蓝图 B 聚合裁决规则与超时数值定标 |
| §06 §6.4/§6.5 | 辩论 baseline 对照 + 四验证器（本章 §7 实验共用设施） |
| §06 未决 #4 | 层级裁剪 A/B（本章 §7 正面作答） |
| §07 未决 #1/#2/#7 | 仲裁晋升验收单（本章 §6 正面作答）；分歧度阈值校准（legacy 0.10/0.30/0.6 默认值的实证复核）；risk 叙事层价值验证 |
| §08 §7/未决 #7-#10 | ε、hop 上限、evidence_strength 映射、裁决阈值定标；候选/简报质量量规；抗腐败层 shadow 观测；自动晋升验收单（本章 §6 模板） |
| §09 未决 #2 | 防抖与节拍参数校准（sweep/冷却/微批窗口族） |
| §14 未决 #2/#3/#5 | 新鲜度标注阈值定标；卫兵自审计（本章 §8.1 通道 3）；veto 破例验收单（本章 §6 模板） |
| §14 §2.7 通道三 | 建议-结果 per-user 校准（Brier/proper scoring）评测轴与样本量门槛（本章 §3.8；料源 §03 §3.6 承载③）——校准分 ≠ alpha、禁进 voter 权重 |

---

## 9. 实现期 overlay §3 回填蓝本（声明）

本仓 overlay §3 测试体系现为 ⏸️ 挂起；实现期开启前按本章回填，形状锁定如下（只立形状，命令与路径实现期定）：

- **tier-1** = §2 断言族的确定性执行（pytest 类 runner + mock fetcher 注入 + 隔离 fixtures——考古 20 测试卫生协议落地处）：秒~分级、每次提交跑、红即熔断（ms-loop tier-1 gate 语义对接）；
- **tier-2** = golden set 双层评测 driver（Tier-1 前置闸 + Tier-2 裁判网络）：批次级、按 §1 触发场景跑、产出评测报告供评审与晋升证据（driver env 配置族：golden set 路径、裁判档位映射、样本量/及格线）；
- **消融** = 同一 driver 的 flag 矩阵模式（§5.3 协议）。
- 回填时本章 §2.1 断言族、§3.1 量规义务、§8.2 golden 资产义务逐条映射为 overlay §3 的可执行命令与 gate——**未回填前不得进 ms-loop Code 阶段**（overlay §3 红线）。

---

## 10. 对 legacy 的三态判断（链考古锚点）

| legacy 对象 | 三态 | 判断明细 | 锚点 |
|---|---|---|---|
| **20 · commit-time gate 原则**（零新增校验算法，把已有规则变 commit 前强制层；OpenSpec verification gate「unit pass ≠ wire 真通」） | **协议继承** | 资产准入 gate 复用编译链/加载校验规则不另造（§2.1 条 5）；贯通断言义务（§2.3）；「验证不完整要显式承认」进 golden 积累纪律（§4 协作缝 1） | 考古 20 §Commit-time gate、§OpenSpec verification gate、摘要 8 |
| **20 · tier-2/xdist 测试卫生**（共享状态隔离、offline guard、summary 行判定、原子写防 torn read） | **协议继承（实现期落地）** | §2.3/§9；隔离 fixtures 与 offline guard 是 Tier-1 确定性的工程前提 | 考古 20 §Tier-2 与 xdist、摘要 9 |
| **18/03 · 依赖注入离线测试策略**（canned fetcher/LLM、gate-off 测试锁、offline 可证） | **继承（协议；§08/§04 已承接，本章消费）** | fetcher 注入缝 = Tier-1 数据面前提（§2.2 表） | 考古 18 §测试通信协议、§精华五六；考古 03 §精华 7；三态册 L803 |
| **12 · SkillSandbox tier1-4 分层预检** | **改造 + 命名冲突显式防**：legacy tier1/2（YAML/guard 静态检查 + mock graph backtest）是**资产上线预检**，对应新系统的资产准入断言（§08 编译链 / §16 候选状态机），**不是**本章的行为回归 Tier-1/2；legacy tier3/4（真实 LLM 检验 / dual-LLM judge，opt-in 重路径）是本章 Tier-2 的精神前身——「LLM judge 不在热路径」的成本纪律原样继承（§3.3 条 3） | 同名不同物必须显式立牌，防实现期把资产预检与行为回归混成一套 | 考古 12 §14 Sandbox、条目 24；三态册 L195 §精华 8 |
| **12/14 · promote gate 纪律**（holdout fail-closed、train-test split、anti-overfit；attribution verdict shadow-only 不拦截） | **协议继承（晋升缝先例）** | §6 验收单五要素的 legacy 根据：晋升门保守、证据不足 fail-closed、机器 verdict 无自动晋升权 | 三态册 EM-14 L1061-1063、条目 46；考古 10 精华 4 |
| **12 · env-gate 默认关 + byte-identical 上线术** | **改造（升格六产品模式 + Tier-1 常规断言）** | §5.2；散落 `VA_*` gate 变注册表模式字段（§16），byte-identical 从上线手艺变回归断言族成员 | 考古 12 §精华 10、§Env gates L1405-1415；考古书 L1142-1153；考古 17 §精华 6 |
| **17 · prism_quality_eval 评估轴**（grounded/useful/bounding、with/without 对照、分数不当 alpha） | **改造（评估轴承接，harness 实体后置）** | §3.1；§14 §5.3 已判，本章消费为 Tier-2 量规先例 | 考古 17 L84、§精华 5、§危险边界 5 |
| **14 · 回测/归因学习环本体** | **后置（§20，本章不预支）** | 评测衡量「说得好不好」，不衡量「赚不赚」——outcome 归因等真实决策流后另立（§3.4 归因墙） | 三态册 EM-14 三态候选；三态册 L263 |
| **新增构件**：双层评测框架、多裁判量规网络、特性开关消融协议、golden traces 通道、晋升验收单模板、per-user 校准边（§3.8） | **新增** | 无 legacy 直接对应 | ACI 报告 §2/§3；25 号 §2.3；`14-transparency-and-judgment/31-investor-self-modeling-discipline.md`（§14 §2.7 通道三）；本章 §2-§8 |

---

## 11. hermes 机制证据索引

本章直接承重路径：

- `hermes-agent/providers/base.py:39-90` — `ProviderProfile` dataclass：provider 声明式档案（name/env_vars/base_url/fallback_models/auth 等）（§3.3：裁判模型档位与 (provider, model) 记录的配置载体面）
- `hermes-agent/providers/__init__.py:140-191` — provider 三源发现：bundled plugins → `$HERMES_HOME/plugins/model-providers/` 用户插件（同名覆盖 bundled，last-writer-wins）→ legacy 单文件（§3.3：发行配置可自带/覆盖裁判 provider 档案的机制事实；注：骨架 §10 桩将此行段标注为「ProviderProfile + fallback」，实际内容为发现逻辑，profile 本体在 providers/base.py——本章按核对结果引用）
- `hermes-agent/batch_runner.py:1-22` — 数据集批量并行拉起 agent + checkpoint 断点续跑 + 轨迹保存（§9：golden set 批量回归 runner 的近邻既有机制；其轨迹格式面向数据生成（from/value 对），评测 driver 是否复用它归实现期评估——本章不承重于复用成立）
- **负证据**：`agent/ tools/ gateway/` 三目录粗扫（rubric/eval harness 类符号）无评测框架命中（§0：评测体系域内自建、hermes 只供 LLM 调用与批量拉起底座的前提；粗扫非穷尽，实现期立项时复核）

转引来源章已核路径（本章不复读）：

- `hermes-agent/agent/plugin_llm.py:1-58,140-156` — `complete_structured(json_schema=...)` 与 `parsed=None` 降级缝（§07 §9）——裁判结构化打分输出的载体（§3.2）
- `hermes-agent/hermes_cli/_parser.py:255-268` — `chat -q/-t` CLI headless（§05 §11）——评测期按次拉起被测 L2 节点的同一载体
- `hermes-agent/tools/skills_tool.py:9-12,53-54` — skills 三级渐进披露 metadata（§10 §7）——§10 路由评测项的注册表事实面

**不作依据声明**：ACI 报告与 25 号报告的文献矩阵（arXiv 编号、opentelemetry/mlflow/owasp 链接）未经本地核验，一律不作本章依据（A2 硬闸）；本章全部数值语汇（及格线、样本量、裁判数、观测窗）均为配置项形状，无一进合同。

---

## 12. 显式未决问题清单

1. **量规库与评测场景首发集**：智识质量三维先例（§3.1）之外，逐产物类型（研报/简报/仲裁/候选）的量规首发集、分值行为描述，以及 `grounded_advisory_explanation` 外的评测场景条目——实现期与量规库/golden 资产一并立项（§16 联动）。
2. **及格线、样本量与裁判校准定标**：相对排名基线的统计判定方法（分布对比的显著性口径）、换位翻转/裁判—人审偏离的可接受口径——实现期用首批 golden 数据定，本章零数值。
3. ~~golden traces 回放接口待 §11~~ → **§11 已定稿、§8.1 通道 1 已回填 `golden_trace_replay_v1` 合同**（trace_selector / input_snapshot_manifest / asset_snapshot_refs / replay_mode / expected_observables / allowed_nondeterminism）；剩字段级 schema 与 golden set 初始集归实现期。
4. **植入违规样本构造法**：卫兵自审计的样本族与 flag-only 信噪比量规（§14 未决 #3 承接）——归量规库维护协议。
5. **评测域三库落位**：本章 §3.5 收口——独立 `evaluation.db` 归 §13，与 `domain.db`(§03)/`telemetry.db`(§11) 三库 triad 弱引用无外键；下沉实现期的是核心表族 DDL、`eval_run` 十二字段组的字段级 schema 与首发枚举、Linked Evaluation Graph 存储表结构（§3.6/§3.7 已锁语义与归属，字段级授权实现期）。
6. **消融交互效应的搜索策略细部**：多 flag 组合的嫌疑分组启发式与预算上限——实现期。
7. **CI/调度载体**：评测批次由 hermes cron 挂周期 vs 手动触发 vs 提交钩子——归 §15 部署形态与实现期 overlay §3 回填。
8. **batch_runner 复用评估**：评测 driver 是否基于 `batch_runner.py` 改造（轨迹格式适配成本 vs 自写轻量 runner）——实现期 ponytail 判定（§11 证据注）。
9. **校准对象四件套字段级 schema 与首发集**：recommendation / adoption / outcome_window / calibration_summary 的字段级 schema、窗口族与 confidence bucket 首发集、`eval_type` 谱系归位（§3.8）——实现期 OpenSpec。
10. **来源策略轴下沉实现期的残留**（§2.1 Source Policy 断言集／§3.1.1 ⑥／§3.6 组 6 增列）：`policy_mode` 值集与 `historical_source_availability_manifest` 的字段级 schema、`source_policy_golden_seed_v1` 六 seed 的 fixture 构造、reason 家族（`reason_family+reason_code+gate_id`）与 §04 §8.7 定义位的同源校验——实现期 OpenSpec（语义与正交性本章已锁）。

---

## External Reference Tags

修改本模块前，查外部参考登记表：`docs/research/reference/external-reference-registry.md`。相关 tags：`report_audit` / `numeric_verification` / `golden_seed` / `release_gate` / `bias_audit`。（外部参考为**非承重机制候选**，采纳须过三态判断 + 守其 `forbidden_landing` 边界；本节只登记 tag、不写具体项目强制规则。）
