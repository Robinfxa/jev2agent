# ValueHermes 架构总设计书

> 状态：大型架构设计阶段交付完成——**§00–§20 全章级定稿**、附录 A1–A5 实体化。下一步（实现切片 / OpenSpec 启用 / 底座改造立项 / §20 封存项激活）待用户共同规划。

> 本书回答：**ValueHermes**（2026-07-02 骨架评审定名）在 hermes-agent 底座上长成什么样。形态对标考古书（`docs/research/valueagent-legacy-archaeology/00-master-design-book.md`，下称「考古书」）：总书 + modules 细稿 + appendices。
> 组织原则：**平台构件**——系统本体是一套 hermes 发行配置，故按构件清单成章、章间以协议桩相连；agent-first 的行为视角以「生命周期 × 构件总览」表嫁接在 §01。
> 证据纪律：hermes 事实只引 `hermes-agent/` 真实本地路径（**底座考古册：`docs/research/hermes-legacy-archaeology/`**——「什么现成 / 什么自建 / 怎么调用」的反向索引，逐条 file:line；机制地图：`docs/research/hermes-fit-arc/README.md` §2）；legacy 事实引考古书；三态候选引 `docs/research/legacy-tri-state-arc/`；**标「外部文档来源」的断言未经本地源码复核不得进正文**（复核账：附录 A2）。愿景与事实分离标注；新旧不对等——「应该继承什么」只是启示，不自动成承诺。
> **External Reference Registry**：ValueHermes 可把外部项目 / 论文 / 框架 / 产品案例作**非承重机制参考**，统一登记在 `docs/research/reference/external-reference-registry.md`——**不改变核心架构、不作正文承重、不自动成承诺**（承接上条外部来源硬闸 + A2）。实现或修改某模块时**按 tag 查登记表**判断是否有相关 reference pack；采纳须过三态判断 + 守住其 `forbidden_landing` 边界（不落核心架构 / 控制面 / 正式账 / 交易执行 / portfolio optimizer 等）。首个 pack = **AI Berkshire**（`docs/research/reference/ai-berkshire/`，`non_authoritative` / `selective`）。

## 00 总纲：北极星、不变量与成书契约

### 全书前提（2026-07-02 grill Q1–Q4 + 骨架评审拍板，细稿不再重议）

1. **北极星 agent-first**：常驻投研 Agent 为主体，决策漏斗是被它调用的一项能力；legacy「漏斗为体、Copilot 外挂」关系**倒转**（`docs/CONTEXT.md`「agent-first 倒转」）。
   **增补（骨架评审）**：agent-first 延伸到**运行时观测与测试期**——轨迹必须机器可读（ACI，Frame Lifetime Trace）、观测数据的第一消费者是 agent（AOI 只读查询接口 / Inspector 审计智能体）、非确定性输出以**双层评测**衡量而非 Pass/Fail（`docs/research/newfeature/11-aci-telemetry/agent-computer-interface-eval.md`）。
   **证据链**：agent-first 的信任面延伸至**报告与证据**——每份面向用户的 advisory 结论同时具有 **human-readable report + durable machine-readable evidence manifest + replay handle**（canonical 条文 = §14 §7 No Naked Claim 与可回溯 Advisory Report）。这是跨 §03/§04/§10/§11/§13/§14/§16/§17 的横切合同，**不新增顶层模块、不新增第四数据库**（承载按守护三库既有边界：轻量 manifest 归 domain.db §03 #20、重型过程轨迹归 telemetry.db §11 TTL/blob、评测与反事实运行归 evaluation.db §13）；用户来源控制（§04 §8.7 Source Access Policy）**不得削弱** PIT、许可、隐私、消毒、质量硬闸与判断权纪律，且服从两不变量（`00-cross-cutting/33-end-to-end-evidence-trace-and-replay-contract.md`）。
   **再增补（同日，v2.1）**：北极星组织原则**「原子化与分形组合」**——全系统执行单元严格遵守四级分形：L1 工具/技能原子（无自主决策权、单一职责）→ L2 子代理（**Domain Analyst Node**：受限 toolsets + 有限原子，**严禁瑞士军刀**、跨正交领域即裂变）→ L3 蓝图（只管控制流/状态流转）→ L4 任务会话（串联/并发蓝图）；组件间以强类型 schema 插槽协议即插即用，状态共享只经统一挂载点、禁全局变量；**能力扩展必须自 L1 起逐级向上构建、严禁大一统超级单体**（⚠️ 报告称挂载点为「前期确定的 state.db SQLite」——本书 §03 已定落位方案 A：插件自建独立 SQLite in HERMES_HOME，非复用 hermes 的 state.db）（`00-cross-cutting/atomic-composable-architecture.md`）。
2. **不变量 ×2**：**只 advisory 不执行交易**、**本地优先**；各预留长期**封存接口**——只能显式解封，不许临时代码绕过（CONTEXT.md「封存接口」；清单归 §20）。新增的**决策后监控回路**（§07→§09）不破坏此不变量：哨兵只触发**重估建议**，无任何闭环执行；遥测数据禁止强制推送云端 SaaS。
3. **结合方式 A（不 fork hermes）**：ValueHermes = 自带 HERMES_HOME profile 的**发行配置**（plugins + skills + mcp + config）；常驻主体 = gateway 原生 agent；决策漏斗等能力 = 插件内自研**确定性蓝图解释器**；节点 agent 以 CLI headless 按次拉起（证据：`docs/research/hermes-fit-arc/`）。
4. **三态总表**：默认表 16 模块照准 + 四项裁定（17 拆开 / **18 升格融合** / 19 放弃 / 12·13 拆），见 `docs/research/legacy-tri-state-arc/README.md`；正文锚点在 §02。
5. **命名**：**ValueHermes**，全书一致，不再占位。

### 成书契约

- 流程：本骨架定调 → 簇批模块细稿 → 总书回填（批次 = `docs/plans/archive/2026-07-03-architecture-book-arc.md` Loop Breakdown；**章节序 ≠ 簇批优先级**，章→簇批归属见附录 A3）。
- 设计输入：grill 决议 + 考古书 + newfeature 全集（现 26 篇、随目录增长以 `ls` 为准；用户分批新增 19 篇——事件驱动触发 / 多蓝图编排 / Inspector 遥测 / 定量风控 / ACI 双层评测 / 分形组合北极星 / JIT 资源规划 / 数据质量膜载体——均已收编对应章节桩）。
- 🔴 **三方对照纪律（成书后长期有效，写文档 / 重大更改必守）**：此后写任何架构文档或做重大更改，须**同时对照三份架构参考**——① **valuehermes 本体** `docs/architecture/`（要改的对象）；② **hermes 底座考古** `docs/research/hermes-legacy-archaeology/`（master + `modules/01..11` + `appendices/capability-crosswalk.md`，逐条 file:line；查「底座已现成什么→**别重复造轮子**、有什么可直接调用→**照记**」；机制地图另见 `docs/research/hermes-fit-arc/`）；③ **valueagent legacy 考古** `docs/research/valueagent-legacy-archaeology/`（「继承 / 改造 / 放弃」三态锚点与旧系统教训）。**三方冲突先 reconcile 再落笔**——新架构不得与底座事实或 legacy 教训脱节；覆盖 overlay §1/§2、领域铁律 §5。
- 每章定稿标准：**正文 + 相关 legacy 模块三态判断（链考古锚点）+ hermes 证据（真实路径，以底座考古册为准）+ 显式未决清单**；用户评审通过标 ✅，否则一律 draft。

## 01 系统画像：一套 hermes 发行配置（结合方式 A）

**一句话画像（行为视角）**：ValueHermes 是常驻本机的投研研究员——用户随时与它**对话研究**；它替用户跑**定时任务**；按自定义**挖掘蓝图**主动扫描候选；研究与扫描中被 beacon 触发**跨域深挖**联想；需要正式结论时调用**完整漏斗决策**产出纪律化共识建议，并附带**定量风控参数**（SL/TP、支撑/阻力）；这些阈值随后被**事件哨兵**持续盯守，破位瞬间触发**紧急重估**。全程 advisory、全程本地、全程留因果链。

**构件清单（本体视角）**：ValueHermes = HERMES_HOME profile 发行配置（插件四源发现 `hermes-agent/hermes_cli/plugins.py:1-32`；skills 外部目录 `agent/skill_utils.py:416-507`；MCP `tools/mcp_tool.py:1-70`）：

| 构件 | 载体 | 章 |
|---|---|---|
| 常驻投研 Agent（主体） | gateway 原生 agent（GatewayRunner 长驻 daemon，`gateway/run.py:2581`） | §10 |
| 蓝图引擎 + 控制面路由 | 插件内自研确定性解释器 + FSM 多蓝图路由；节点 CLI headless 按次拉起 | §05–06 |
| 挖掘蓝图 + 跨域深挖 | 蓝图体系内的智能增长点 🔴 | §08 |
| 事件触发与唤醒层 | 事件哨兵 + 本地消息总线 + 唤醒钩子（cron 的事件驱动补层） | §09 |
| 领域状态库 | 必须自建（SessionDB 只存会话，`hermes_state.py:696-775`） | §03 |
| 数据质量膜 | legacy 03 整体继承 | §04 |
| 守护构件：ACI 遥测 / Inspector 审计 / 双层评测 | OTel GenAI 轨迹 + 旁路审计 agent + Tier1/Tier2 回归 | §11–13 |
| 横切：透明度 / 部署铁律 / 版本治理 | 哲学约束 + 配置规范 + 资产纪律 | §14–16 |
| 策略生命周期与演化回路 | Detection/Quarantine 守护回路（v1 常开）+ 演化学习环（Autopsy/Distillation/回测，封存待扳机） | §17 |
| 冷数据 Token 经济层（L1 成本中间件·横切） | 温度分层 + 冷 digest 预消化 + 运行时静态前缀缓存（复用 hermes `system_and_3`）+ 变更门控 + 拓扑纪律 | §18 |
| 逐股·跨时间画像层（advisory 材料层） | §03 画像 rollup 专表 + §07 逐 lane 贡献归因持久化 + 漂移探测姊妹回路（与 §17 正交） | §19 |
| 封存接口与边界 | 交易执行 / 远端部署封存缝 + 后置资产池 + 放弃项 | §20 |

**生命周期 × 构件总览（考古书四条主生命周期的新画法——其中挖掘扫描 / 跨域深挖由 legacy 的 gated 附件升格为两条一等生命周期（§08 §1.1）、事件触发紧急重估为无 legacy 对应的净新增；legacy 01 改造落点）**：

| 生命周期 | 主要穿过的构件 | 横切/守护 |
|---|---|---|
| 对话研究 | §10 主体 → §03 状态库 / §04 数据膜 /（按需）§05 引擎 | §11/§14 |
| 定时任务 | hermes cron → §05 → §03 | §11/§15 |
| 挖掘扫描 | §08 → §05 → §04 → §03（advisory 账） | §11/§14 |
| 跨域深挖 | §08 → §05（动态插节点）→ §03 | §11/§14 |
| 漏斗决策 | §05 → §06/§07 节点 → §04 → §03（正式账 + 风控阈值） | §11/§12/§14/§15 |
| **事件触发紧急重估** | §09 哨兵/总线 → §05 控制面（中断路由）→ 蓝图 B（MAD）→ §03 | §11/§12 |

> **守护表注（§12 覆盖面）**：§12 Inspector 是所有 §05 蓝图 run 的异步 post-run 审计 overlay——异常终态 / MAD 未收敛 / 全失败降级 / 共识层方向性背离极值为必审，正常 COMPLETED run 按配置抽样，用户可按 run_id·decision_id·trace_id 显式触发（§12 §1.2）。守护表未逐行列出 §12 不代表该生命周期不受 Inspector 覆盖；「事件触发紧急重估」行列 §12 只是通用审计面的一个实例。

**成本/研究横切补注**：**§18 冷数据 Token 经济层**是 L1 成本中间件横切——服务对话研究 / 挖掘扫描 / 漏斗决策 / 回测重放的**一切 LLM 调用**（削减冷数据重复注入的 token，不改业务语义、不单列生命周期行，同 §11/§14 横切定位）；**§19 逐股画像层**沿标的时间轴聚合各生命周期产出的单次涌现量，作 AOI drilldown 的 advisory 材料源（与 §17 策略衰减互为姊妹回路）。

**四级分形映射（北极星组织原则在结合方式 A 上的落位，`00-cross-cutting/atomic-composable-architecture.md`）**：L1 = hermes tools/skills ｜ L2 = CLI headless 节点 agent（**Domain Analyst Node**：受限 toolsets + style_profile_ref）｜ L3 = 蓝图（DAG/FSM，§05）｜ L4 = 任务会话（§10 主体 + §05 控制面**串联/并发**蓝图或临时 L2 群组）。六层执行单元命名空间镜像见附录 A5 原子注册表。⚠️ 两处对报告的偏离：报告 L2 带「持续能力单元」语感（可注册、独立攻坚）——结合方式 A 下退化为**按次拉起的无状态进程**，跨次状态一律经 §03 外置；报告 L4 调度器称「Director/FSM Router」——「Director」与本工作流角色重名，本书译作「主体 + 控制面」。

**协议桩（构件间接缝，细稿逐条展开）**：主体→引擎的**收窄调用接口**（invoke 分析师 / execute 蓝图双工具，「什么时候不要用我」写进 description）；引擎→节点的**互斥输出路径 + 内存合并**；全构件→状态库的**写入合同**；共识→风控参数→哨兵阈值→紧急重估的**决策后监控回路**；全链路→遥测的 **trace/span 传播 + 防篡改**（节点不得清洗上游 trace_id）；**状态流裁剪**——业务节点输出契约压缩至极简结论，评分张量/回退流等追踪元数据由底座中间件捕获写入遥测表（§11/§12 零侵入的配套契约）；组件挂载走**强类型 schema 插槽协议**（类 MCP），能力发现只读 **meta-descriptions**（注册表嗅探，供 §10 JIT 规划）。

**画像细节回填（§10 定稿收束此二待答，2026-07-03）**：①**入口面取舍 = 统一网关模式**——放弃各插件平台分散接入，全系统经 gateway 原生入口（Platform 枚举 **24** 内建成员 + 插件动态成员 `_missing_`，§10 §12 已核 `gateway/config.py:136-174`；勘误骨架旧述「22 内建」）集中意图路由 / 鉴权 / 审计，控制面拦截越权自动化执行意图，投研主体维持连续受控人格。②**主体与蓝图会话隔离 = 同会话软裁剪 + 托管状态**——`[TASK_START]` 断层屏障清冗余、保核心 prompt + JIT 能力视图 + 任务简报（§10 §3-§6）；跨次状态一律外置 §03。⚠️ **MicroVM/OS 级沙箱决议已废除**（2026-07-03 用户决令：advisory 属性使重沙箱不必要，统一按 24 号软裁剪）。

## 02 三态总表与对照书关系（与附录 A1 逐行一致）

二十模块最终三态（承接章；逐行 canonical 含考古锚点见**附录 A1**）：

- **继承（整体）**：03 数据质量膜 → §04（全书唯一整体继承项）。
- **被底座吸收**：02 入口面 / 04 LLM 路由 / 15 Copilot 控制面 → §10（各带精华吸收验收 checklist §7.1–§7.3）；**12 技能管线 → §10**（2026-07-03 用户决令；版本治理理念残留改造 → §16）。
- **改造（协议继承、载体重写）**：01 → §01/§05 ｜ 05 → §05 ｜ 06/07/08 → §06 ｜ 09/10 → §07 ｜ 11 → §03 ｜ 16 → §10/§16 ｜ 20 → §15。
- **拆**：13 记忆（会话面吸收 + 投研历史语义改造 + 经验复用）→ §03（经验专表 §17 §4.4）；17 Prism（透明度哲学横切继承 → §14 / 知识库·playbooks 实体后置 → §20）。
- **升格融合**：18 Discovery/Supplychain → §08（Supplychain L1 实体后置 → §20）。
- **分层升格**（14，原「整体后置」修订）：Detection/Quarantine v1 → §17 ｜ Autopsy/Distillation/回测 = 证据扳机激活 → §17（闸门 §20）｜ outcome 字段族 schema 预留 → §03 §8 ｜ 演化壳/三臂实验后置 → §20。
- **放弃**：19 React web 壳（信息架构启示归档；工作台形态属「下一步」另立项）。

新增构件（§10 JIT / §05 控制面路由 / §06 视角配置分解 / §07 定量风控 / §09 唤醒层 / §11–§16 守护横切各件 / §17 演化回路 / §18 冷数据 token 经济 / §19 逐股画像）无 legacy 直接对应，三态列「新增」，出处链 newfeature 报告——逐件见附录 A1 新增区。

对照书关系：每个「继承/改造/放弃/后置/升格」判断均链回考古书或 evidence-map（锚点随 A1 行）；三态候选原料 `legacy-tri-state-arc/tri-state-candidates.md`，**最终判断以各定稿章 + 用户决令为准，已逐行落定于附录 A1**。

---

## 构件群 I：基础设施底座（领域状态库 · 数据质量膜）

### 03 领域状态库与状态契约（第一优先设计对象）

- **hermes 最大空档**：组合、决策账本、行情缓存、回测产物、thesis/领域记忆在 hermes 无现成 home（SessionDB 只存会话/消息/成本，`hermes_state.py:696-775`）——必须自建。
- legacy 11 教训是本章宪法：隐式 sidecar 静默坏掉；边界 Pydantic 合同、JSON 双防线、atomic write 协议继承，载体重写。13 拆分落位：会话面归 hermes 吸收，thesis/投研记忆语义在此重设计。
- **新增职责**：**风控阈值表**（§07 产出、§09 哨兵 O(1) 读）；遥测挂载表与本库的边界（§11 待答联动）。
- 落位方案 = **A（插件自建 SQLite in HERMES_HOME，memory provider 降为读通道）**（§03 定稿）；剩余归实现期：正式决策账与 advisory 产物分账 schema（字段级）、决策账本与 §11 trace 的存储边界、本地优先对选型的硬约束清单。

### 04 数据质量膜

- legacy 03 **整体继承**（唯一整体继承项）：「数据层是一等能力」——provider/cache/sanitization/staleness 透明/PIT/fail-soft 整膜继承；数据事实、模型推断、展示三分。
- 向蓝图节点、常驻主体、挖掘蓝图、**事件哨兵**（行情 tick/缓存）四方供数。
- **载体方向输入（用户 17 号报告，细稿已采编）**：**混合非对称载体**——低频/复杂查询（基本面/新闻）经本地 MCP server 供 L2（密钥零信任隔离，agent 对密钥全盲）；高频 tick 由 **Feed Handler**（单点持有全部外部 WebSocket，多路复用+初步消毒）写共享内存，哨兵与 L2 零拷贝只读；provider 密钥走 OS 原生凭据库（keyring），不落明文 .env。
- 待答：三问（载体/WS 边界/密钥）已获方向输入，细稿须独立论证并处理——macOS 无 /dev/shm 的 mmap 适配；报告 HFT 语汇（纳秒级/tick-to-trade）按 advisory 需求降格；keyring 与 hermes 生态 .env 惯例（optional-mcps）的并存边界；厂商文献按 A2 硬闸不作正文依据。

## 构件群 II：蓝图体系（引擎 · 漏斗 · 挖掘）

### 05 蓝图引擎、解释器与控制面路由

- 蓝图 = 声明式 DAG（CONTEXT.md「蓝图」），插件内**自研确定性解释器**执行（分形 L3：只管控制流/状态流转，不做代码/数据级作业）；节点 CLI headless 按次拉起（`hermes chat -q --toolsets ...`；分形 L2：Domain Analyst Node + 受限 toolsets）。
- **控制面路由（FSM，新增）**：顶层不直接启 agent，先启状态机路由器——监听事件总线（§09）与 cron；`cron_tick` → 标准蓝图，`risk_breach` → **中断**当前任务、硬路由至紧急蓝图；业务流与控制流分离（`05-blueprint-engine-control-plane/multi-blueprint-orchestration.md`）。
- **四维分类模型 canonical 归口**：§05 拥「场景 × 流派 × 蓝图族 × tags」（scenario_class × style_profile × blueprint_family × blueprint_tags）四维正交分类的 canonical 定义，及 viewpoint_lane / 多蓝图并行的控制面裁定（细稿 `modules/05` §2.4/§5.5）；style_profile 资产治理归 §16。
- **蓝图 DSL 外置**：拓扑以 YAML/JSON 配置文件存储、引擎按需解析——为未来「LLM 自主改编排图」留可扩展性；**修改护栏**：蓝图配置 = 系统核心，禁止静默修改，必须**强制中断（Halt）**、风险揭示 + **两次以上显式核准**（人类或 Inspector；链 §10 写确认门、§16 版本治理）。⚠️ 报告示例提及 LangGraph/AutoGen 仅为类比——**执行载体以 Q2 拍板的自研确定性解释器为准**。
- **默认蓝图册**：A 标准投研（cron 触发、顺序管道、宽容时限）；B **MAD 紧急风控**（事件触发、中心化多智能体辩论、**强制数学收敛**、超时熔断、秒级 Hold/Cut 建议）；挖掘蓝图（§08）。
- 硬性机制（v1 照旧）：两层熔断（应用层 schema 校验 + hermes tool_loop_guardrails，hard_stop_enabled 默认关必须显式开——外部文档来源，复核见 A2）；生成配置**回读自校验**；互斥输出路径 + 内存合并、输出幂等白得崩溃恢复；每节点写「拓扑理由」（MAST 警告）。
- legacy 01 入口收束 + 05 决策图协议在此重生：入口无关核心出口、边界强合同、视角 fan-out 失败隔离。
- 待答：蓝图 schema 最小核心集；FSM 中断/挂起/恢复语义→**已获 19 号报告方向输入**（确定性解释器检查点：Safe Point = L2 交回工具调用/节点产出的边界、全工具严格幂等为硬前提、挂起后热切换 MAD 蓝图 B、检查点落 §03 预留表；细稿采编并将报告 liquidation/order 语汇按 advisory 降格）；MAD 蓝图 B 的聚合函数与超时参数；解释器状态机细部（取消/超时）；与 §08 动态插节点接口预留。

### 06 决策漏斗蓝图 · 前半（数据 → 分析师 → viewpoint_lane → 辩论）

- legacy 06/07/08 改造为蓝图节点：分析师 = FactInterpreter（Python 定量、LLM 只写 rationale）+ fact-grounding guard；视角配置拆为正交 profile 族（style/weight/material_profile + node_prompt_fragment）+ viewpoint_lane 机制，是领域 lens 不是 prompt 皮肤，state 传播必须显式声明；辩论层 = fact fidelity 与 bounded synthesis，先过 self-consistency baseline。
- **判断权契约以 §14 横切为 canonical，本章只做节点级实例化**（防漂移）。
- 待答：分析师节点原子粒度；视角配置分解→**已获 18 号报告方向输入**（视角 = (View(State), Subset(Tools)) 双重物理隔离：L3 感知裁剪 + 工具 RBAC，prompt 降格为语气格式化；细稿须调和两点——legacy factor_weights 定量通道有实证效果、拆为正交 profile 族；感知裁剪只适用辩论/视角节点，FactInterpreter 必须见全量事实）；Bull/Bear 辩论是否实质权衡（legacy 未验证缺口）。

### 07 决策漏斗蓝图 · 后半（trader → risk → PM → 共识 → 定量风控）

- legacy 09/10 改造：risk 约束 exposure、PM 在约束内**给建议**；共识层 raw/bucketed/display/authoritative 四分离；deterministic consensus 默认、LLM 仲裁只作 fallback；出口合同对标 AnalyzeCoreResponse 铁律；**判断权契约同以 §14 为 canonical**。
- **定量执行与风控 agent（新增，共识末端旁路，`07-funnel-back-half/risk-execution-agent-architecture.md`）**：订阅**共识出口**极简信号契约（如 `{ticker, signal, confidence, horizon}`；⚠️ 报告称此节点为「Director」，与本工作流 Director 角色重名——全书统一改称**共识出口**）；只授 OHLCV 时序读权、隔离运行、不碰基本面/新闻；双轨——**VTA 符号化技术分析**（外部统计库把 MA/ATR/布林带降维成符号序列，LLM 只对符号推理）+ **时序 RAG 模式检索**（历史相似波动区间提取真实支撑/阻力，拒绝静态百分比止损）；产物 SL/TP + S&R + 趋势判定**只进最终报告与状态库**（advisory-only 校验通过：无闭环执行；⚠️ 报告原文仅「封装入最终报告」，写入状态库是本书为决策后监控回路所作的超集扩展）；阈值写入 §03 供 §09 哨兵盯守——**决策后监控回路的起点**。
- 待答→**已获 20 号报告方向输入**（细稿已采编）：时序 RAG 向量库（模式库）归 **§03 领域状态库**（内部习得经验，非 §04 外部事实防腐层；§03 承载物清单已补行）；风控参数封装 **TemporalValidity 时效衰减契约**（基准时间 + 硬 TTL + 置信度衰减曲线 + 失效阈值，哨兵 O(1) 验算、过期/失效发 `risk_stale` 事件——同步作答 §03 未决 #4）；共识出口走**条件分支 fast-path**（分歧度低时跳过 LLM 合议）。细稿两处调和：fast-path 只跳 LLM 仲裁，deterministic consensus 与账本写入每次必经（legacy 10 权威协议）；报告「关键路径延迟敏感」语汇按 advisory 降格（真实收益是算力成本非延迟）；示例数值均为形状示意（no-invent）。剩余待答：共识产物 schema 字段级定稿。

### 08 挖掘蓝图与跨域深挖（智能增长点）🔴 专门设计轮

- **18 升格融合章**（Q4 用户否决「后置」）：**挖掘蓝图** = 自定义股票发现/筛选方法的蓝图形态；**跨域深挖** = beacon 触发、解释器动态插入调查节点的「二次联想」机制化（路径 A：分析师只声明 beacon、解释器插节点自持 hop 计数、不给分析师 delegation 工具）。
- 行为面两小节：**扫描触发**（周期/手动扫描 → advisory 候选产物，与正式决策账隔离标注）；**联想触发**（beacon 声明 → 动态插节点 → 跨域调查回流）。
- 三条纪律继承进蓝图契约：persist=False 防污染、LLM 零编 ticker、quote grounding 硬门。
- **现无清晰架构——本章只立桩，细稿走专门设计轮**（可能加 Researcher）。
- 待答（设计轮主题）→**已获 21/22 号报告方向输入**（细稿已采编）：深挖结论走**零突变 + 旁路简报 + 显式确定性融合**（探查节点不改主 DAG signal/confidence；只读 DeepDive_Briefing 经纯函数 Assimilation 节点显式融合——「自动改 vs 只简报」的中间解）；深度管控 = **混合有界熵**（语义新颖度衰减软截断 + Max Hops 硬截断；数值为形状示意）；用户自定义面 = **对话生成 + 语法约束解码（GCD）→ DSL + AST 静态验证墙 + 沙箱**；扫描产物走 **CQRS 分流**（海量初筛入低持久化 advisory 事件流，经抗腐败层裁决后才入 §03 advisory 账）。细稿四处调和：①Assimilation 落点须过 §07 输入引用合同与 §14 只缩不增；②「阅后即焚流」与 §03「advisory 账可回看」分层对齐（初筛流 vs 裁决后落账）；③报告「ProposeOrder」语汇按 advisory 降格（无 orders，§03 封存）；④「调取哨兵做定量验证」构件映射勘误（quote grounding 属 §04 膜）。剩余：与漏斗蓝图共享多少解释器机制。

## 构件群 III：触发与常驻主体

### 09 事件触发与唤醒层（新增构件）

- 定位：系统唤醒层从纯时间驱动（cron）升级为**事件驱动**（EDA），根治「两次轮询间隙闪崩失明」（`09-event-trigger-wakeup/event-driven-trigger-architecture.md`）；与 hermes cron **并存**——定时生命周期照走 cron，事件生命周期走本层（⚠️ 报告定位为「原生 cron 的高阶替代品」，并存是本书裁定的偏离）。
- **本地优先哨兵模式**：**事件哨兵**（极轻量驻留进程，**不持有交易所连接**——WebSocket 由 §04 数据膜 Feed Handler 单点持有，哨兵只读其共享内存行情缓存（零拷贝），O(1) 比对 tick 价与 §03 风控阈值表；⚠️ 修正 event-driven 报告「哨兵维持 WebSocket 长连」的表述，依据 17 号报告边界裁定）→ **本地消息总线**（**stdlib UDS 点对点 + 显式 ack**，物理隔离哨兵与 LLM 层；拒绝外部 Webhook 提供商；⚠️ 非 Redis Pub/Sub、非 ZeroMQ——§09 §2 已 ponytail 定案）→ **唤醒钩子**（常驻 agent 后台订阅协程，捕获事件 → 挂起非紧急任务 → 切换紧急重估模式 → §05 控制面硬路由 MAD 蓝图 B）。
- **防抖双层**（防高波动下 token 爆炸）：同向冷却期 + ATR 动态噪声缓冲带。
- 三态：新增构件，无 legacy 直接对应（与 legacy 20 仅为关联——20 的三态承接在 §15，A1 不在此重记）。
- 待答→**已获 23 号报告方向输入**（细稿已采编）：总线 = **本地 stdlib UDS 点对点消息通道 + 显式 ack**（§09 §2 已过 ponytail 定案：淘汰 Redis Pub/Sub 与 ZeroMQ、直用 stdlib Unix Domain Socket 免库依赖；payload 只携指针、状态仍以 §03/§04 为权威）；payload = **指针化极简契约**（{urgency, context 摘要, shm_ref{segment, offset, length}}——控制流极轻、数据经 §04 mmap 零拷贝深读）；防抖细化（ATR 动态水位 Static±k×ATR + 同向冷却锁 + **反向急变/更深层级破位强制穿透**）；**非破位事件族 = 漏斗分级聚合**（L0 致命破位直通绕过聚合池；L1/2 新闻脉冲/数据异常进滑动窗微批池 + 语义去重 → Event Packet 定期递交，防 token 轰炸——同步作答 §05 未决 #6 路由表扩展）。细稿调和：报告 <10μs/微秒级语汇按 §04 §4 先例降格（形状 = 无锁内存判定 + 判定循环禁跨进程 I/O，数字不进合同）；阈值 O(1) 读与 §03 定稿对齐（SQLite 只读是**加载通道**、判定在内存表——写清加载/刷新协议）；L1/2 事件的 producer 边界（新闻脉冲谁产生）待定。剩余：唤醒钩子在 gateway 常驻 agent 的挂载点（hooks 面核对）；哨兵部署守护（链 §15）。

### 10 常驻投研 Agent

- 主体 = gateway 原生 agent，不重造常驻壳（per-session AIAgent LRU 缓存，`gateway/run.py:66-69`）；投研人格/系统提示经 `SOUL.md` 身份槽注入（stable 层首位、整体替换默认身份，`agent/system_prompt.py:150-162`；零插件零 fork，§10 §2 落论，销 hermes-fit-arc §5.1 悬账）。
- legacy **15 吸收 + 精华验收 checklist**；**16 单独标改造**：读自动/写确认的「受控动作总线」协议继承（考古书铁律三），载体换 toolsets 白名单 + **`pre_tool_call` 双墙 + gateway 审批 rail**（写确认门在 `pre_tool_call`；`approval` hook 为 **observers-only**、不承载门——缝位修正，锚 §10 §11 定稿 `hermes_cli/plugins.py:135-213`）；**蓝图配置修改属最高级写操作**（协议见 §05 护栏）。
- 三份**吸收验收 checklist**：02 入口面、04 LLM 路由（provider 三源发现 `providers/__init__.py:140-191`、ProviderProfile 本体 `providers/base.py:39-90`；**按角色/节点路由语义走 `llm_request` middleware**——可重写请求 payload、`hermes_cli/middleware.py:1-34`，非 `pre_llm_call` hook，缝位修正锚 §10 §12 定稿；`pre_llm_call` 实为注入 user message）、15 会话/流式/sidecar 大 payload 分离。
- **JIT 资源规划器（新增，`10-resident-agent/jit-resource-planner.md`；⚠️ 报告中「Director」指常驻主体，非本工作流角色）**：主体接任务的**第一帧**禁止直接求解——先走 JIT 流水线：意图解构 → 注册表嗅探（只读能力 meta-descriptions；hermes skills 三级渐进披露 `tools/skills_tool.py:1-70` 是现成载体）→ 资源按需申领（L1/L2/L3）→ 沙盒化组装（**未选中能力对模型零可见**）→ 移交执行；防上下文超载与「好奇心死循环」。
- 待答→**已获 24 号报告方向输入**（细稿已采编）：JIT 注册表 = **原生渐进披露之上的前置意图映射层**（第一帧本地匹配/轻量 embedding 精确下发 Tool Schema，免 LLM 翻找试错；写权限 API 层截断为 Proposal-only——写确认门的 JIT 侧贯彻）；任务会话沙盒 = **同会话软上下文裁剪**（[TASK_START] 断层屏障清冗余、保核心 prompt + JIT 能力视图 + 任务简报；advisory 属性使 OS 级沙箱不必要）；权限模型自补 = **网关防腐层 + 最小权限动态白名单**（禁自建沉重 RBAC 引擎，上游原生组件就绪即切除）；主驾双路径 description = **LLM-facing schema 约束 + human-facing audit_label 双轨**。两处调和均已细稿落论：①**生成式混合 UI**的「数据流强制结构化渲染防虚构」原则进交互合同；Widget 实体按用户决令收敛——废除 React 独立端、生成式 UI 仅限 CLI 内 Markdown/Mermaid 渲染，工作台形态属「下一步」另行立项（§10 §10.3）。②人格/system prompt 注入可行——主通道 `SOUL.md` 身份槽，零插件（§10 §2）。

## 构件群 IV：守护构件（观测 · 审计 · 评测）

> **守护数据三库（弱引用、无跨库外键）**：业务权威状态 → `domain.db` / 领域库（§03，独立文件、与 hermes 自身 `state.db`/SessionDB 物理分立）；过程轨迹 → `telemetry.db`（§11）；评测权威结果 → `evaluation.db`（§13）。三库物理分立、只经稳定键（`trace_id`/`eval_run_id`/`asset_id`/`config_snapshot_id`）弱关联，不设跨库外键——存储边界的总书收束（弱键集以 §03 §5 / §11 / §13 §3.5 三章定义为准）。

### 11 ACI 因果链遥测（机器可读轨迹）

- 横切契约、非事后模块，**北极星增补的落地章**：每次迭代/工具调用/参数/上下文快照封装为 **Frame Lifetime Trace**（对齐 OpenTelemetry GenAI 语义，`gen_ai.*`）；trace_id/span_id/parent_span_id 强制注入，**防篡改**——业务节点不得清洗上游 trace_id（`11-aci-telemetry/agent-computer-interface-eval.md` + `12-inspector-agent/observer-agent-telemetry.md`）。
- **本地优先遥测存储**：高基数轨迹禁止强制推送云端 SaaS，全量落本地 SQLite 遥测挂载表；**AOI 只读查询接口**——调试 agent / Inspector 经 SQL/API 拉取死锁前动作序列，免人工贴日志。
- **状态流裁剪契约**：业务 agent 输出契约压缩至极简结论，评分张量/回退流等元数据由底座中间件捕获写入遥测表——§12 零侵入的配套前提。
- 结构化错误对象、大对象 handle + 结构保留预览；**第一个 sprint 即埋点**。
- 待答→**已获 25 号报告方向输入**（细稿已采编）：span 穿进程 = **W3C Trace Context 环境变量注入**（TRACEPARENT/TRACESTATE，避免 STDIN 污染——与 §03 HERMES_HOME 显式传播同一纪律）；遥测 = **独立本地库**（append-mostly 时序宽表 + 独立 TTL 轮转，印证 §03 §5 建议）。剩余：AOI 接口形态；与 hermes 回调面/hooks 缝合点；§09 payload trace 起点承接（等 §09 定稿）。

### 12 Inspector 审计智能体（新增守护构件）

- 定位：**旁路 sidecar、零代码侵入**的系统级审计 agent（`12-inspector-agent/observer-agent-telemetry.md`）——读遥测流水 + 代码库变更状态，重构层次化因果图，不干预主流程。
- **双轨异步审计**：`post_blueprint_execution`（批次落盘后离线回溯）+ **crash-audit path**（L2 子进程崩溃由引擎回收感知、gateway 进程内 crash marker 为 best-effort、可靠兜底 = 重启尸检扫描——hermes **无 on_crash 钩子**，不承诺 OOM/SIGKILL 硬崩瞬间拉起 Inspector，§12/§15 §3.4）。
- **跨域归因**：代码层拓扑诊断（git diff × 激活配置）× 数据层血统溯源（遥测时间线）→ 结构化溯源报告；报告**物理隔离归档**（独立目录），防知识库污染。
- 三态：新增（呼应 legacy 20 validation 精神与「无人值守成功要证据」铁律）。
- 待答→**已获 25 号报告方向输入**（细稿已采编）：模型档位 = **顶级推理模型**（弱模型审计自身出幻觉；档位配置化）；只读 = **三层隔离**（工具白名单 / ro 文件系统 / 网络单向抛报告——细稿须过 ponytail：OS 级 ro 沙盒与 24 号「advisory 属性不需重沙箱」的哲学对齐，或降为进程权限+白名单）；与 §13 分工 = **运行时归因（why/how）vs 回归打分（what/how-well）**。剩余：审计报告部署态目录；hooks 注册点（等 §09/§05 执行面）。

### 13 双层评测与特性开关消融（新增守护构件）

- 定位：非确定性输出的回归测试体系（`11-aci-telemetry/agent-computer-interface-eval.md`）——**实现期 overlay §3 测试体系回填将以本章为蓝本**。
- **Tier-1 确定性断言**：无 LLM、纯启发式/Python 断言/JSON Schema 校验；工具触发、必填字段、条件分支覆盖；二进制 Pass/Fail，**Fail 即熔断流水线、不得进入 Tier-2**（Tier-1 是 Tier-2 的前置闸门）。
- **Tier-2 神经元打分**：外置量规（Rubrics）多维量化评分（如逻辑连贯 0-10、风险发散 0-10），高维裁判模型 + 多裁判聚合抗「流畅度偏见」；及格分制而非对错制。
- **特性开关消融**：新功能（新工具/换视角节点 prompt/新协作链路）一律 Feature Flag 包裹；退化时拨开关跑同套 Tier1+2 回归，控制变量秒级定位毒组件（继承 legacy env-gate 六产品模式启示，考古书 L1142-1153）。
- 待答→**已获 25 号报告方向输入**（细稿已采编）：与 §12 分工边界定稿（评测框架管宏观回归——CI/版本升级期批量跑 golden traces；Inspector 管微观单体归因）。剩余：量规库维护与版本化；裁判模型选型与成本预算；flag 注册表与 §16 关系；golden traces 从哪积累（遥测库回放候选）。

## 构件群 V：横切约束

### 14 透明度与判断权纪律（canonical 横切）

- legacy 17 **哲学横切继承**（实体后置）：grounded-first、truth-knobs、advisory membrane（解释永不写回决策信号）。
- **判断权四纪律的 canonical 落点**（§06/§07 只实例化）：Python 定量 LLM 只写解释 / fact-grounding guard / philosophy veto 只缩不增 / raw+bucketed 分开存。
- 待答→**已获 25 号报告方向输入**（细稿已采编）：truth-knobs = **双层表达**（Blueprint schema 全局合规基准 + node 级重载——发散扫描与精确抽取适用不同幻觉容忍度）；grounded 校验 = **节点内卫兵**（post-node hook 重试成本过高；与 §06 已定稿的票面收口 guard 位置对齐）。剩余：不确定性与 staleness 在对话回答的呈现底线。

### 15 部署铁律与配置生成

- legacy 20 改造 + hermes-fit-arc §4 铁律：hard_stop 显式开、生成配置回读自校验、role 静默降级坑位本地核实后收编；产出**非默认部署配置规范**。
- 协议继承：运行时状态不进仓库、无人值守成功必须有证据、原子写；载体换 HERMES_HOME + hermes cron（`cron/jobs.py:641-712`）。
- **新增**：哨兵进程/消息总线的部署形态与守护（崩溃重启、与 gateway 的生命周期绑定）；Inspector `on_crash` 钩子自身的可靠性。
- 待答→**已获 25 号报告方向输入**（细稿已采编）：回读自校验 = **两期分层**（安装/部署期全量深度防线 fail-fast + 启动期轻量 checksum/签名防静默漂移）。剩余：外部来源复核清单清零（A2 已销 hard_stop/config 回退两条，余项已收口 A2.2）；hermes 升版回归与锁版本；错过补偿/盘中密度语义；§09 哨兵/总线守护 + §04/§10 待记清单汇总（§15 细稿已汇总）。

### 16 蓝图/技能资产版本治理

- legacy 12 版本治理理念改造继承：蓝图文件与 SKILL.md 是版本化知识资产，sandbox 候选不污染 live；LLM scorer 等 gated 长尾随 14 后置。
- **新增**：蓝图修改护栏的版本侧——任何蓝图配置变更 = 新版本 + 审计轨迹（链 §05 护栏、§12 归因）；Feature Flag 注册表纳入资产治理（链 §13）。
- 待答→**已获 25 号报告方向输入**（细稿已采编）：绑定粒度 = **不可变结构哈希 + 上下文快照**——run 级账本行绑 `(blueprint_id, blueprint_version, blueprint_struct_hash, config_snapshot_id)` 复合元组；**Node_ID 不进账本行**，节点级还原经 `trace_id` → §11 遥测 span 取 `node_id` / 节点版本 / prompt 快照，实现决策的完美还原（与 §03 §8 已预留的 blueprint_id+version 字段族对接细化；报告「Commit_SHA」按蓝图资产实际载体改为结构哈希）。

## 构件群 VI：演化与边界

### 17 策略生命周期与演化（新增章，2026-07-03 方向一 A / 方向二 B 拍板）

- **四步回路**（27/28 号报告收编，分层升格）：**Detection（认知方差撕裂预警）+ Quarantine（[Decaying] FSM 软下线 + 纸上留观）= v1 核心守护回路**（机制接缝：§13 三维评测常规指标 / §11 遥测 / §05 路由态 / §16 资产状态机）；**Autopsy（元研究蓝图，经 §08 深挖机制唤醒）+ Distillation（Inspector 提炼 Golden Lesson → §03 经验专表单向写入 + RAG 前缀约束）= 设计入册、按 §20 证据扳机激活**；蓝图重构走 §16 人类核准。
- **回测方法论**（27 号）：纯量化前置过滤 / 蒙特卡洛多路回放（置信度分布替代单次重放）/ 动态物理脱敏防穿越（双时态锚定）/ 云端降本三管线（含「过早截断」陷阱防御）/ 三维评测空间（财务/认知方差/工程效率）——整体属封存接口设计，激活按 §20 扳机。
- 待答→已由 §17 细稿处置：Detection 阈值量纲（数值全为形状示意）；[Decaying] 与 §16 sandbox 四态状态机的合并；§03 经验专表 schema（修订随附）；27/28 的 HFT 语汇（「毫秒级」）降格；其伪造文献已按硬闸物理删除、余项过 A2。

### 20 封存接口与后置/放弃清单（边界章 canonical）

> 本章是不变量（只 advisory 不执行交易 / 本地优先）与「未做完 / 不让做」能力的**收口章**：为每一处封存 / 后置 / 放弃设计**缝的位置 + 解封条件**，使不变量只能被**显式解封**、不能被临时代码绕过（CONTEXT.md「封存接口」）。**本章无 module 细稿文件，正文即 canonical**。设计输入：26 号报告 §3（经 2026-07-03 用户五决令过滤——MicroVM/严格沙盒决议废除、伪造文献物理删除）。

#### 20.1 封存接口 ×2（显式解封缝）

**封存接口 A · 交易执行「铁笼」解封验收单**（26 号 §3.1 采编）——系统当前严格 advisory，自动交易执行作为封存接口存在，解封须**同时**满足三条硬前提：

| # | 验收单 | 语义 | 链回机制 |
|---|---|---|---|
| 1 | **量化纸面验证** | 积累跨度含**完整财报季**的实盘纸面（paper trading）数据，其方差与回测**严格吻合**（回测料源可信是前提） | §17 §5 回测方法论 + §17 §5.3 双时态脱敏 |
| 2 | **非 LLM 铁笼防线** | 由底层语言（示意 C++/Rust，实现期定）**硬编码**绝对风控拦截引擎（最大仓位、回撤熔断），经 **100% 覆盖 fuzz-testing**，证明 LLM **绝无可能**经任意指令绕过 | §07 定量风控（advisory）之外的独立执行门；§14 判断权墙 |
| 3 | **合规审计哈希链** | 每次发单前输出含行情快照引用 + 推理树签名的**防篡改审计追踪链**，供监管溯源 | §11 遥测 + §16 结构哈希 + §20.3 归因接缝 |

**注（不变量守恒）**：§07 定量风控参数（SL/TP、S&R）与 §09 紧急重估（Hold/Cut）**均为 advisory 产物（报告+建议）**，不构成执行解封——哨兵只触发重估建议、无任何闭环执行。§03 §8 已确认本库**没有** orders/execution 表（空表本身是诱饵）：解封缝 = `decision_id` 稳定主键，未来执行记录作**新表外键**引用账本，现有 schema 零改动；legacy 的 staged/committed orders 表（考古 11 §6）**不继承**（其 thesis check 从未接牢，考古 13 条目 36）。**导入成交记录不撞本封存缝**：§03 §3.6 投资者行为诊断的券商成交记录导入账（§03 承载物 #15）是**用户外部导入的高敏 PII 证据**（真实成交史）、系统**只读**、永不产/执行订单、永不作持仓权威源——它是「关于用户的证据」而非「系统的订单」，orders 空表封存缝**零改动**（§14 §2.7 不变量拆弹）。

**封存接口 B · 远端部署解封缝**（本地优先不变量的解封面）：解封时单文件 SQLite 可能需换 client-server 引擎；缝的位置 = §03 §4.3 **按领域拆分的窄数据访问模块**——所有访问经窄访问面、无裸 SQL 散落，引擎替换爆炸半径被限制在访问模块内。ponytail 边界：这不是建 ORM / 抽象仓储层，只是「集中访问函数」的最低纪律。遥测数据同守（§11 本地优先：高基数轨迹禁强制推送云端 SaaS）。

#### 20.2 后置资产池（设计入册、账面 / 字段先立，能力默认不建 / 不启用）

后置 ≠ 放弃：预留位置与纪律、实体不建；激活按 §20.4 证据扳机。**注意 §17 已把 legacy 14 的 Detection/Quarantine 升格进 v1 核心守护回路**（不在本池），本池只收**真正后置项**：

| 后置资产 | 来源 | 后置边界 | 激活 / 承接 |
|---|---|---|---|
| **Autopsy 元研究因果归因** | legacy 14 三层 attribution 升格 | 每次烧顶级模型算力（成本自杀风险）；legacy 从未证明真实提升 alpha | §17 §4.2 设计入册；证据扳机（§20.4）激活 |
| **Distillation 经验专表消费** | legacy 14 演化学习 / 13 经验复用 | `golden_lessons` schema 建列不写数据（§03 §8 / §17 §4.4）；激活后单向 append-only + 用户核准准入 | §17 §4.3；扳机激活 |
| **回测方法论**（蒙特卡洛多路 + 双时态脱敏 + 三维评测 + 云端降本三管线） | legacy 14 回测引擎升格 | 高并发重放，成本在算力 / Token 规模化塌缩 | §17 §5 设计入册；独立扳机激活 |
| **SkillEvolver / SkillDirectorLLMScorer 演化壳** | legacy 12 / 14 | 「地基先行、壳后置，顺序不可倒」（§16 §5）；安全阀（激进生成 / 保守晋升 / holdout fail-closed / data-leak 防护）先行进 §13 §6 验收单 | §16 §5、§17 §4.5 后置 |
| **三臂实验 harness**（isolated StateDB / persona alpha 诊断） | legacy 14 | 隔离精华由 §17 §5 回测物理隔离沙盒承接；三臂诊断属演化壳后置域 | §17 §7；扳机激活 |
| **outcome 回填能力**（回测 / 归因消费端） | legacy 14 | **字段族第一天建列**（§03 §8 归因接缝），消费系统后置 | §03 §8 schema 预留 |
| **legacy 17 知识层实体**（knowledge_advisor / role_perspective / playbook 库 / knowledge_injection） | legacy 17 Prism 拆分 | 落地一周即冻结、愿景未验证；透明度哲学已横切继承 §14，实体后置预留位置与纪律 | §14 §8（哲学横切）；实体后置 |
| **legacy 16 影子账户** | legacy 16 Copilot | 数据边界纪律（raw CSV 不落库）随未来评估带走 | §10 §11 三态行 |
| **投资者人生目标锚**（人生目标现金流 Monte Carlo 规划 + 情景压力测试） | §14 §2.7 承载④（financial-services 财富管理参考） | 判为向理财规划师的**使命漂移**（超投研 advisory 边界）；现仅在 §03 §3.6 承载① 申报账预留一个目标申报字段、规划能力**不建** | §14 §2.7；§03 §3.6 字段预留；证据扳机（§20.4）激活 |

#### 20.3 双时态归因接缝 schema（对接 §03 §8 · 零 ALTER 预留）

为使后置的「演化归因 / 历史回测」未来随时可挂载而不破坏历史数据连贯性，决策账本行**从第一天强制预留**以下结构（26 号 §3.2；**字段级 canonical 主家在 §03 §8「只建列、不建能力」**——其中 `generator_context_hash` 的哈希 preimage 定义主家在 §16 §2.6；**本节只作消费说明 + 封存接口说明、不拥有 schema**，是封存语义的边界章收拢）：

| 字段族 | 字段 | 作用 |
|---|---|---|
| **双时态锚点** | `effective_time`（真实世界发生时点）/ `recorded_time`（落库时点） | 彻底消灭回测未来函数（look-ahead bias），对接 §17 §5.3 动态物理脱敏 |
| **因果链血缘** | `causation_trace_id`（串联上下文，§11 遥测关联）/ `parent_state_hash`（连续演化证明）/ `generator_context_hash`（生成上下文结构哈希，**定义主家 §16 §2.6**、字段级落位 §03 §8） | 孤立动作串成不可变防篡改因果链 |
| **扩展占位符** | `attribution_metadata_blob`（schemaless JSONB，默认 `{}`） | 未来复活直接注入特征权重 / 梯度日志，做到 **Zero ALTER TABLE** |

§03 §8 据此把 legacy 14 判为「后置，schema 提前预留」，并作**全归因接缝字段族的 canonical 主家**——含**决策账本归因字段族**（`decision_id` / `trace_id` / `blueprint_id`+`version` / `skill_version` / 输入引用 / outcome 回填族 / 逐 lane 贡献向量）与**本节双时态 / 因果链 / 占位符字段族**（`effective_time` / `recorded_time` / `causation_trace_id` / `parent_state_hash` / `generator_context_hash` / `attribution_metadata_blob`）两组，字段级定义一律以 §03 §8 表为准。

**消费面补注**：本节双时态锚点（`effective_time`/`recorded_time`）从 v1 起即有两个 advisory 消费面——**§18 冷数据变更门控**消费 `effective_time` 判源版本前推（其配套的 `source_hash` 是冷源**原文指纹**、canonical 字段家在 §18 冷 digest 专表、**非本归因接缝成员**；`source_hash` 变化在 §18 内一信号双驱动 digest 重算与 delta 门控解除，Python 层零 LLM）；**§19 逐股画像**继承 `effective_time`/`recorded_time` 锚点使「某段历史窗内一贯 X 驱动」可精确回放、切断未来函数。二者只**消费**本接缝的双时态锚点、不改其 schema，且均为材料层（不入 §20.2 后置资产池）。

#### 20.4 证据驱动的重启扳机（决策方 = 用户本人）

模块重启权从常规排期剥离，交门槛极高的数学证据掌控（26 号 §3.3；本书单用户约束下译解决策方）——**两把独立扳机**（成本结构与证据需求不同，避免「为解剖一次失效被迫拉起整套回测基建」的成本耦合，§17 §4.1）：

| 激活对象 | 证据扳机（数值为形状示意 · no-invent） | 决策方译解 |
|---|---|---|
| **演化归因**（Autopsy + Distillation） | 双层评测显示主链「不可解释漂移」持续超阈（形状：连续 N 天 > X%，量纲 = 认知方差漂移，数值配置项）；或遥测证明人工 Debug 的 MTTR 严重超出 SLA | 26 号「首席架构师 + 首席数据科学家」→ **用户本人**（证据呈现给用户、用户显式解封） |
| **历史回测** | 遥测证明事件溯源「漏事件率」长周期稳定 ~0.00%（回测料源可信前提），且当前重大蓝图重构在影子模式下无法覆盖极端尾部风险 | 26 号「CRO + 首席架构师」→ **用户本人** |

激活 = 显式解封动作，落 §16 Feature Flag 注册表（六模式）+ 审计轨迹；解封前 flag 处 `disabled`，留观表照常攒料（v1）、经验专表 schema 建列不写数据（§03 §8「只建列不建能力」的兑现）。

#### 20.5 放弃清单 + §20↔§17 分层关系

- **放弃**：legacy 19 React web 壳不搬（信息架构启示已归档候选册）；**生成式 UI 仅限 CLI Markdown/Mermaid**（2026-07-03 用户决令废除 React 独立端）；独立工作台形态属「下一步」另行立项，不构成重开。
- **§20↔§17 分层关系**（module 17 §1.1 canonical）：legacy 14 不是「后置」也不是「照搬」，是「**分层**」——**守护回路（Detection 闻味 + Quarantine 隔离）v1 先上（§17），学习回路（Autopsy 解剖 + Distillation 提纯 + 回测）设计到位、账面 / 字段 / 验收单全落定、等证据扳机（§20.4）说话再启**。§20 是其封存半环的边界收口；§17 是其 v1 守护半环与激活半环的机制细稿。

**未决 → 已收束**：§20 架构级悬案（铁笼验收单、归因接缝、证据扳机、决策方译解）已随 26 号采编与用户五决令逐条落定；剩余为实现期工程细节（fuzz 覆盖工具链、哈希链具体算法、`attribution_metadata_blob` 内部特征 schema）与封存项激活（须过 §20.4 扳机 + 用户显式解封）——见附录 A3。

## 附录

### A1 三态借鉴矩阵总表

二十个 legacy 模块 × 最终三态 × 承接章 × 考古/证据锚点（逐行与各 module 定稿三态节核对一致；原料 = `legacy-tri-state-arc/tri-state-candidates.md`，最终判断以定稿章 + 用户决令为准）：

| Legacy 模块 | 最终三态 | 承接章 | 考古 / 证据锚点 |
|---|---|---|---|
| 01 System Lifecycle | 改造 | §01（生命周期总览）+ §05（入口收束协议，单一分析核心变硬约束） | 考古 01 §3/§11；三态册 EM-01；§05 §10（本行已定稿） |
| 02 Entry Surfaces | 被底座吸收 | §10（吸收验收单 §7.1） | 三态册 EM-02（L119-135）；§10 §11 |
| 03 Data Ingestion & Quality | **继承（全书唯一整体继承）** | §04 | 考古 03 §模块结论摘要、§精华 1-9；三态册 L139-159；§04 §9 |
| 04 LLM Provider Router | 被底座吸收 | §10（吸收验收单 §7.2；残留能力 a-d 各落位） | 三态册 EM-04（L165-180）；§10 §11 |
| 05 Decision Graph | 改造（协议→解释器全局规范，载体重写） | §05 | 考古 05 §3/§6；三态册 L697-712；§05 §10 |
| 06 Analyst | 改造（协议近全盘继承，载体重写） | §06 | 考古 06 摘要 3-5/13；三态册 L715-736；§06 §9 |
| 07 Persona | 改造（废弃 persona 顶级概念、拆为正交 profile 族：style/weight/material_profile + toolset_policy + prompt_fragment） | §06 | 考古 07 摘要 9-10/13-14；三态册 L738-759；§06 §9 |
| 08 Debate | 改造 + 继承（fact-fidelity 三分层继承 / 伪多轮放弃 / count 终止协议 → §05） | §06（+ §05 终止协议） | 考古 08 摘要 10-13、L1100-1104；三态册 L761-781；§06 §9、§05 §10 |
| 09 Trader-Risk-Portfolio | 改造（决策权分层契约继承，载体重写） | §07 | 考古 09 §职责边界、条目 1-9；三态册 EM-09 L390；§07 §8 |
| 10 Consensus Council | 改造（共识协议 / 投票数学继承，载体重写） | §07 | 考古 10 §内部运作机制 1-9；三态册 EM-10；§07 §8 |
| 11 State Contracts & Persistence | 改造（六条宪法继承，StateDB 巨型汇合库放弃） | §03 | 考古 11 §精华 1-8；三态册 L81-82；§03 §9 |
| **12 Skill System** | **被底座吸收（§10 · 2026-07-03 用户决令）**；版本治理理念残留改造 → §16 | **§10**（技能管线吸收）+ §16（治理理念残留） | v2.9 决令「12→§10 吸收」；§16 §7（版本治理理念改造）；三态册 L195/L215 |
| 13 Memory/Thesis/Context | 拆：会话面被底座吸收 → §03 / 投研历史语义改造 → §03 / 经验复用 → §03 经验专表 | §03（+ §17 §4.4） | 考古 13 条目 38；三态册 L237-238/L273；§03 §9、§17 §4.4 |
| **14 Backtest/Evolution/Attribution** | **分层升格**（原「整体后置」修订）：Detection/Quarantine v1 → §17；Autopsy/Distillation/回测 = 证据扳机激活 → §17（闸门 §20）；outcome 字段族 schema 预留 → §03 §8；演化壳 / 三臂实验后置 → §20 | §17（+ §03 §8 schema、§20 激活闸门） | 考古 14 摘要 9/51；三态册 L263；§17 §7、§03 §8 |
| 15 Copilot 控制面 | 被底座吸收（答案核验三层 → §14/§13 改造；static prefix → §10 SOUL.md 继承） | §10（吸收验收单 §7.3） | 考古 15 §5-§11；三态册 EM-15；§10 §11 |
| 16 Copilot 受控动作总线 | 改造（协议继承、载体全换）；影子账户后置 → §20 | §10（受控动作总线）+ §16（版本侧） | 考古 16 §7/§9；三态册 EM-16；§10 §11 |
| 17 Prism（透明度 / 知识层） | 拆开：透明度哲学横切继承 → §14 / 知识库·playbooks 实体后置 → §20 | §14（+ §20 后置） | 考古 17 §精华 1-6；三态册 README 分歧点 1、EM-17；§14 §9 |
| 18 Discovery/Supplychain | 升格融合：挖掘蓝图 + 跨域深挖 → §08 / Supplychain L1 实体后置 → §20 / SupplyChainEdge 契约纪律继承 | §08（+ §20 后置） | 考古 18 §模块结论摘要；三态册 README 分歧点 2、EM-18；§08 §8 |
| 19 Web UI | **放弃**（React 壳不搬；工作台形态属「下一步」另立项） | §20（放弃 / 边界） | 三态册 EM-19；README 分歧点 3 |
| 20 Ops | 改造（五纪律协议继承，载体重写）；xdist 测试隔离后置 → 实现期测试体系 | §15 | 考古 20 §模块结论摘要 1-10；三态册 EM-20；§15 §9/§11 |

**新增构件区**（无 legacy 直接对应；三态列「新增」，出处链 newfeature 报告 + 各章独立论证）：

| 新增构件 | 承接章 | 出处 |
|---|---|---|
| JIT 资源规划器（前置意图映射 + 双墙）、`[TASK_START]` 软裁剪、网关防腐层、主驾双路径、audit_label 双轨 | §10 | `10-resident-agent/jit-resource-planner.md`、24 号报告 |
| FSM 控制面路由、蓝图 DSL 外置、修改护栏、MAD 蓝图 B、确定性检查点挂起/恢复 | §05 | `05-blueprint-engine-control-plane/multi-blueprint-orchestration.md`、19 号报告 |
| 视角配置分解（profile 族 + viewpoint_lane 物理隔离）、跨视角对抗结构、回应性/翻转敏感度验证器 | §06 | 18 号报告、tensions 报告 |
| 定量风控节点（VTA + 时序 RAG）、TemporalValidity 契约、时序模式库、fast-path 条件分支、`risk_stale` 事件 | §07 | `07-funnel-back-half/risk-execution-agent-architecture.md`、20 号报告 |
| 事件哨兵、唤醒总线（UDS 基线 / ZeroMQ 候选）、指针化事件契约、防抖双层 + 分级聚合 | §09 | `09-event-trigger-wakeup/event-driven-trigger-architecture.md`、23 号报告 |
| 风控阈值表、组合申报表、三层存储遥测边界 | §03 | risk / ACI / observer / atomic 报告 |
| Feed Handler + mmap 高频面、keyring 密钥面 | §04 | 17 号报告 |
| Frame Lifetime Trace、W3C 环境变量传播、独立遥测库、AOI 只读面 | §11 | ACI 报告、observer 报告、25 号 |
| Inspector 审计智能体（双轨触发、三层只读、隔离归档） | §12 | observer 报告、25 号 |
| 双层评测框架、多裁判量规网络、特性开关消融、golden traces 通道 | §13 | ACI 报告、25 号 |
| truth_policy 双层字段、卫兵家族分级、呈现合同六条 | §14 | 25 号、tensions 报告 |
| 两期校验分层、三守护单元拓扑、SAFE_MODE 诊断、升版回归流程 | §15 | 25 号 |
| 结构哈希 + config snapshot 复合元组、flag 注册表六模式、候选四态状态机 | §16 | 25 号 |
| [Decaying] 正交路由态、留观表、元研究蓝图唤醒链、Golden Lesson 经验专表 + RAG 材料层、证据扳机激活闸门 | §17 | 26 / 27 / 28 号 |
| 数据温度分层（热/温/冷/冰）、冷 digest 预消化、运行时静态前缀缓存（**复用 hermes `system_and_3`**、修正冷前缀断点布局）、变更门控注入、缓存拓扑纪律 | §18 | 29 号报告 |
| 逐股画像 rollup 专表、时间加权聚合（EWMA + regime 分段）、漂移探测姊妹回路、可证伪契约、逐 lane 贡献归因持久化（§07 归因足**改造扩展**） | §19 | 30 号报告 |

### A2 hermes 证据映射与复核账清零

**A2.1 章级 hermes 证据索引**（各章证据路径的 canonical 家在各 module「hermes 机制证据索引」节，本表为汇总入口，不复制路径本体）：

| 章 | 证据索引位置 | 关键承重路径（举要） |
|---|---|---|
| §10 常驻主体 | modules/10 §12 | gateway/run.py:66-67,2581（LRU/常驻）；agent/system_prompt.py:113-467（三层 prompt）；hermes_cli/middleware.py:1-34（llm_request）；tools/approval.py（审批）；plugins.py:135-213（approval observers-only、pre_tool_call） |
| §05 蓝图引擎 | modules/05 §11 | tool_guardrails.py:73-78（hard_stop 默认关，销 A2 一条）；config.py:96-141（损坏 config 静默回退，销一条）；_parser.py:255-268（chat -q/-t）；plugins.py:135-176（pre_tool_call） |
| §06 漏斗前半 | modules/06 §10 | plugin_llm.py（complete_structured）、toolsets.py 收窄（转引 §05） |
| §07 漏斗后半 | modules/07 §9 | plugin_llm.py:1-58,140-156（结构化降级梯）；models_dev.py:60,118-119（structured 能力元数据） |
| §08 挖掘/深挖 | modules/08 §9 | toolsets.py:30-32,97-100（web_search/extract）；models_dev.py:528-532（嵌入被过滤）；mcp_tool.py（膜检索载体） |
| §09 事件触发 | modules/09 §8 | pyproject.toml:24-45（无 pyzmq/redis）；gateway/run.py:6894-6963（长驻 watcher 协程组）；mcp_tool.py:54-75（daemon 后台事件循环先例） |
| §03 状态库 | modules/03 §10 | hermes_state.py:123,695-785,858-889（SessionDB 四表 / 写锁 convoy）；hermes_constants.py:55-80（HERMES_HOME 传播）；memory_provider.py |
| §04 数据质量膜 | modules/04 §10 | mcp_tool.py:2-11,366-395（挂载/环境过滤/credential 擦除）；mcp_catalog.py（.env-is-for-secrets）；config.py:3001-3038（secrets.bitwarden）；本机 /dev/shm 不存在 ✅ |
| §11 ACI 遥测 | modules/11 §9 | pyproject.toml（零 OTel）；plugins.py:135-213 + middleware.py（hook/middleware 四类）；run_agent.py:426-498（回调族）；trajectory.py:31-56 |
| §12 Inspector | modules/12 §8 | plugins.py:135-213（无 on_crash / 无蓝图 run 收口钩子——否定性事实）；toolsets.py:31-80（只读白名单 vs 黑名单执法对象） |
| §13 双层评测 | modules/13 §11 | providers/base.py:39-90（ProviderProfile）；providers/__init__.py:140-191（三源发现）；batch_runner.py:1-22；负证据：三目录无 eval harness |
| §14 透明度 | modules/14 §10 | 纪律条文章，不新增 hermes 断言（转引 §05/§06 已核） |
| §15 部署铁律 | modules/15 §12 | cron/scheduler.py + cron/jobs.py（60s ticker / grace / 双心跳 / 权限 0700-0600）；backup.py:256-407（safe copy / torn restore 排除） |
| §16 版本治理 | modules/16 §6（证据转引 §05/§08/§03） | 结构哈希 / manifest 载体（转引已核） |
| §17 演化 | modules/17 §8 | 全部转引前章（cron/jobs.py、_parser.py、models_dev.py、memory_provider.py、plugins.py 无 on_crash） |
| §18 冷数据 token 经济 | modules/18 §10 | **agent/prompt_caching.py（`system_and_3` 四断点·docstring ~75%）、conversation_loop.py:60,883-888（`apply_anthropic_cache_control` 接线）、agent_init.py:509-526（`_cache_ttl` 由 config.yaml `prompt_caching.cache_ttl` 驱动）——本层复用既有缓存机制、只修正冷前缀断点布局语义**；memory_provider.py:94-106（digest RAG 注入载体·转引 §03 §3.4）；providers/base.py（缓存按模型隔离·⚠️实现期核对） |
| §19 逐股画像 | modules/19 §11 | memory_provider.py:94-106（画像 RAG 材料层注入·转引 §03 §3.4）、hermes_state.py:695-800（域库幂等 SCHEMA_SQL 参照）；转引 §11 §7 AOI 只读 + §08 §4.4 域内嵌入设施（⚠️相似度检索载体实现期核对） |

**A2.2 外部来源复核账 · 已销项**（硬闸：标「外部文档来源」的断言本地复核前不得进正文；canonical 清点在 modules/15 §04）：

| 条目 | 原状态 | 现状态 | 销于 |
|---|---|---|---|
| hard_stop_enabled 默认关 | 外部文档来源 | ✅ **已销**（本地已核 tool_guardrails.py:73-78） | §05 §6.2 |
| 损坏 config 静默回退 | 外部文档来源 | ✅ **已销**（config.py:96-141） | §05 §6.3 |
| role=orchestrator 静默降级 leaf | 外部文档来源 | **无需复核、存档即可**（delegation 整体排除、零依赖） | §05 §4.4/§11 |
| cron 60s tick / 密度 / 错过补偿 | fit-arc §5 未细读 | ✅ **已销**（cron/jobs.py、scheduler.py、run.py:19483-19493 活路径已核；run.py:19013-19025 为 deprecated shim） | §15 §6 |
| hermes backup 文件级行为 | §03 未读源码 | ✅ **已销**（backup.py 已核） | §15 §5.1 |
| HERMES_SAFE_MODE 跳过插件 | 转引 plugins.py:1243 | ✅ **已销并扩展**（MCP 同跳、--safe-mode 三开关叠加） | §15 §7 |
| pre_llm_call 承载角色路由（骨架 §10 桩旧述） | 骨架 §10 桩 | ✅ **已修正**（角色/节点路由走 llm_request middleware；写确认门在 pre_tool_call、approval observers-only） | §10 §11/§12、本书 §10 桩 |
| MCP 工具在 toolsets 的收窄粒度 | ⚠️ 待核实 | **留实现期**（影响收窄机制选型，不影响任何裁定） | §04 §7 |
| provider 行情 / 数据条款（连接配额 / PIT 支持度） | 外部事实 | **实现期逐厂商核实**（部署核验类） | §04 §2 |
| Anthropic/provider prompt caching 的具体数值与机制（TTL 档、最小前缀、折扣率、断点上限 ≤4、20-block 等） | 外部产品能力 · **hermes/provider 内部边界** | **非本架构承重项 · 我方不复核**——cache_control 应用、TTL 读取、按 provider 布局、按模型隔离全在 hermes `prompt_caching.py` 内部（config 仅暴露 `prompt_caching.cache_ttl`）。§18 只承重「稳定冷前缀落进既有缓存区即被复用」的**布局纪律** + TTL 档×工作流的**配置选择**（§05 §3.1 既有注入缝），**不依赖也不复核任何 provider 具体数字**（前缀-match 语义下冷前缀落进 system 断点即命中，≤4 断点上限对本层不构成约束）；报告 ~90% / docstring ~75% 之类一律示意不承重 | §18 §4 |

**A2.3 外部学术文献区**：新报告（24/25/26/27/28/29/30 号等）成文附带的 arXiv 编号、vertexaisearch、厂商链接**一律未经本地存在性核验**。按 2026-07-03 用户决令**硬闸**：**伪造 / 占位 arXiv 链接已物理删除**；其余外部文献一律**不作正文承重依据**——各章凡引其思想者均已将结论转化为可验证的本地设计（对照测试 / 安全边界 / 验证器 / 本地源码路径），文献仅作方向佐证。OTel GenAI semconv 与 W3C Trace Context 为公开标准，字段/字节级定稿归实现期对当版规范核对（§11 未决 #1）。

**A2.3 增补**：29 号报告**无伪造 arXiv**（正例），唯一外引 = Anthropic 官方 prompt-caching 页，已立 A2.2 待核账。30 号报告文献矩阵（适应性市场假说 / 异象后发表衰减 / 结构断裂因子溢价 / BOCPD / Bai-Perron / ADWIN / Regime-HMM / EWMA / RBSA / Style Drift / Brinson / FAJ / TECHPLS）同此硬闸**一律不作正文承重依据**。**核验记录**：`arXiv 2603.21672`（曾疑占位）**已核验为真实论文**（`2603`=2026 年 3 月 YYMM、非未来占位；Yimeng Qiu, q-fin.PM，两法独立确认）——#30 全部受核文献均真实且与主张匹配（作者预先核验了引用，与 29 号同为正例）；即便真实，按 A2 硬闸外部文献仍**一律不作正文承重依据**。§19 的「非平稳自指约束」改由系统既定纪律独立论证（legacy「无标签每次现算」§06 §1.3/§2.2 + §17 regime shift + §14 判断权），不靠外部文献背书。

### A3 未决问题总账 + 章→簇批归属（v3.0 终态）

**A3.1 未决总账**（汇总各 module §显式未决清单，按归属分类；架构级决策已定，剩余多为实现期工程细节——呼应 26 号 §4.2「未识别边缘 Case 降级为工程实施细节」）：

| 归属类 | 代表未决项（章 · 非穷举，逐章 canonical 见各 module §未决清单） |
|---|---|
| **A · 实现期 OpenSpec（数值定标 / schema 字段级 / 参数）** | 蓝图 schema 最小核心集、蓝图 B 聚合函数与超时数值（§05）；impact_score 预算函数、辩论轮次恢复量规（§06）；TemporalValidity 数值族、分歧度校准（0.10/0.30/0.6 为 legacy 默认待校准）、共识 schema 字段级（§07）；挖掘 DSL 白名单、GCD 载体强度、Assimilation 映射函数、beacon schema、候选表 schema（§08）；防抖节拍参数、event_packet 路由档位（§09）；advisory 分账 schema、决策账本↔遥测存储边界（§03）；gen_ai.* 字段对照、保留期/轮转参数（§11）；触发策略默认参数（§12）；量规库维度、及格线/样本量（§13）；结构哈希规范化算法、config snapshot 字段级、嵌入模型版本治理（§16）；Detection 阈值量纲、holding period 类别化（§17）；冷 digest schema 字段级 / 温度档阈值定标 / 缓存断点插入点 / digest 重算触发（source_hash vs effective_time）/ Tier-1 命中断言最小实现（§18）；画像聚合窗与 EWMA 半衰期 / 漂移探测器选型（BOCPD / Bai-Perron / ADWIN）与阈值 / 贡献向量字段级 schema / 可证伪标注结构（§19）；**证据链三切片**（§14 §7 北极星的实现期拆分登记）——`grounded-advisory-report-trace`（单离线 facts fixture + deterministic calculator + bounded analyst + report manifest 与 claim/evidence refs；验收 = 无 naked claim、数字 claim 只来自 tool/source、重型日志可缺席而轻量 manifest 完整）、`source-policy-resolution-and-snapshot`（provider/origin/domain 三轴 + allow/deny/prefer/lens/fallback + declaration→effective 子快照解析 + fetch 与 cached-consume 双闸；纯离线 fixture）、`source-policy-replay-ab`（baseline `as_ran` + 单一 counterfactual deny + policy snapshot/排除原因/PIT 与 historical availability + A/B 单变量守恒；不接真实 provider、不评收益、不打开晋升或正式写权）（§04 §8.7／§03 §3.8-§3.9／§13 §2.1·§3.6／§17 §5.8） |
| **B · 待用户产品拍板** | macro 默认进 roster、News 保留 LLM 定向、初始 lane roster（§06）；量规/golden 资产核准人角色（§16）；对话面不确定性/staleness 呈现底线（§14/§09） |
| **C · 下一步立项 / §20 封存激活** | 交易执行封存、远端部署封存（§20.1）；Autopsy/Distillation/回测/演化壳/三臂实验激活（须过 §20.4 证据扳机 + 用户显式解封）；legacy 17 知识库实体（§20.2）；独立工作台形态（legacy 19 放弃后的「下一步」） |
| **D · 跨章联动（等相邻章定稿回填）** | §05 #6 非破位事件族路由表（risk_stale/data_stale/packet 三行）← §09 已定稿；§09 唤醒钩子挂载点 ← §11/§05 执行面；§11 §08 payload trace 起点 ← §09 已定稿；§13 golden traces 回放接口 ← §11 AOI；§14 呈现合同在 §10 落地 ← §10 已定稿；§17 经验专表 schema ← §03 §8 补行（§17 §4.4 已给建议）；§18 冷 digest 专表 ← §03 承载物 #12（§18 §3 给 schema 建议）、§18 前缀组装器 ← §17 §5.4 共用（ponytail）；§19 逐股画像专表 ← §03 承载物 #13、§19 lane 贡献向量列 ← §07 §6.3 归因足升格（建议形态在 §19 §3，批执行时改 §07/§03） |

**注**：架构级悬案（因果归因、事件边界、哨兵并发、封存标准、决策方译解等）已通过定稿章 + 用户决令清零；上表 A/D 类为实现期落地任务，B 类候用户拍板，C 类候封存激活——均不阻塞本阶段（大型架构设计）交付。

**A3.2 章→簇批归属（最终态 · Director Plan Loop Breakdown v2 + §17 增补）**：

| 簇批 | 章 | 状态 |
|---|---|---|
| 1 骨架定调 | §00–§02 + 全书桩 | ✅（v2.1） |
| 2 状态契约 + 领域状态库 | §03（含 §20 归因接缝、风控阈值表预留） | ✅ |
| 3 数据质量膜 | §04 | ✅ |
| 4 蓝图引擎 + 控制面 + 漏斗前半 | §05、§06 | ✅ |
| 5 漏斗后半 + 定量风控 | §07 | ✅ |
| 6 挖掘蓝图 + 跨域深挖（专门设计轮） | §08 | ✅ |
| 7 事件触发与唤醒层 | §09 | ✅ |
| 8 常驻主体 + 吸收验收 | §10（回填 §01 画像细节） | ✅ |
| 9 守护与横切簇 | §11–§16 | ✅ |
| 10b 策略生命周期与演化 | §17（分层升格：Detection/Quarantine v1 + 证据扳机激活半环） | ✅ |
| 10c 附录 + 总书回填收束 | §02、§20、A1–A4、§01、成书收束语 | ✅ |
| **11 成书后增补** | §18 冷数据 token 经济层、§19 逐股·跨时间画像层（+ §06/§07/§08/§03/§04/§11/§13/§14/§15/§20/§17 交叉链回填） | ✅ |

### A4 全局统筹矩阵（Global Governance Matrix）

跨章总表族（A4.1 token **频率**/防抖 · A4.2 密钥信任 · A4.3 token **复用**/冷数据）：把分散在各机制章的**成本 / 信任边界**统一收口、逐行链回机制章，防「每章各自防一段、全局无人对账」。

**A4.1 Token 防抖 / 计费边界**（防高波动 / 深挖 / 长循环下的 token 爆炸与算力失控）：

| 机制 | 章 | 边界内容 | 链回 |
|---|---|---|---|
| 防抖双层 + 分级聚合微批 | §09 | 同向冷却锁 + ATR 动态噪声缓冲带（Static±k×ATR）；L0 致命破位直通绕过聚合池，L1/L2 新闻脉冲/数据异常进滑动窗微批池 + 语义去重 → Event Packet 定期递交 | modules/09 §4 |
| 混合有界熵 | §08 | 跨域深挖深度双截断：语义新颖度衰减**软**截断 + Max Hops **硬**截断；扫描产物 CQRS 分流（海量初筛入低持久化 advisory 流，抗腐败层裁决后才落账） | modules/08 §4.4、§3.2 |
| 两层熔断 + 三层超时预算 | §05 | 应用层 schema 校验 + hermes tool_loop_guardrails（hard_stop 默认关、显式开）；节点/蓝图/会话三级超时；MAD 蓝图 B 超时熔断 | modules/05 §6、tool_guardrails.py:73-78 |
| JIT 裁剪 + 同会话软裁剪 | §10 | JIT 沙盒化组装**未选能力对模型零可见**（防上下文超载 / 好奇心死循环）；`[TASK_START]` 断层屏障清冗余、保核心 prompt + JIT 能力视图 + 任务简报 | modules/10 §3-§6 |
| 回测降本三管线 | §17 | 云端批量 / 缓存降本三管线 + 「过早截断」陷阱防御；证据扳机前默认封存、不烧算力 | modules/17 §5.4、§4.1 |

**注 · 非 token 成本轴**（2026-07-03 补 · 用户拍板显式点名）：上表统 **LLM token / 算力**;行情·基本面·新闻 **provider API 的真金费用与连接配额**是另一条经常性成本轴（常驻轮询 + 挖掘扫描 + 哨兵 feed 下量随时间累积），本表不重复承载其数值——归 §04 数据质量膜（载体与订阅集边界）与 **A2.3「provider 数据条款（连接配额 / PIT 支持度）实现期逐厂商核实」**（部署核验类，激活期定档）。此处显式立牌，防「治理矩阵只管 token、漏了数据账」。

**注 · token 复用轴（正交于本表频率轴）**：A4.1 治的是**频率**轴（事件/循环发生频次 → token 爆炸）；**冷数据静态内容的重复注入**是另一条正交的 **token 复用**轴——收口在 **A4.3**（§18 冷数据 Token 经济层）。合起来成本治理四轴：token 频率（A4.1）/ token 复用（A4.3）/ provider 真金与配额（§04 + A2.2）/ 算力（A4.1）。

**A4.2 密钥信任边界**（域数据密钥 vs hermes 生态密钥物理隔离，agent 对密钥零信任）：

| 机制 | 章 | 边界内容 | 链回 |
|---|---|---|---|
| keyring 双域物理不相交 | §04 | 域数据 provider 密钥 → OS 原生凭据库（keyring），**agent 对密钥全盲**、不落明文 .env；hermes 生态 .env 惯例（optional-mcps）零干预——两域互不覆盖 | modules/04 §6 |
| 密钥部署面 + SAFE_MODE | §15 | 0700/0600 权限基线；keyring 使密钥文件本体消失（0600 对象缩至 hermes 生态 .env）；`--safe-mode` 三开关叠加跳过插件/MCP，诊断姿势 | modules/15 §7、§4.2 |
| hermes MCP 环境过滤 + credential 擦除 | §04（膜载体）/§10 | `_build_safe_env` stdio 子进程只透传安全基线环境变量 + 显式配置项（防密钥泄入）；`_sanitize_error` 在错误返回 LLM 前擦除 credential 形状内容；exfiltration 形状可疑 server 配置过滤 | mcp_tool.py:366-395、3229-3253 |

**A4.3 Token 复用轴 / 冷数据经济**（治**静态冷内容的重复注入**——与 A4.1 频率轴正交，逐行链回 §18 冷数据 Token 经济层）：

| 机制 | 章 | 边界内容 | 链回 |
|---|---|---|---|
| 数据温度分层 | §18 | 热/温/冷/冰四档按更新节拍决定 token 处置（消费 §04 staleness/TTL 族、不改膜主语义，成本视角叠加标签）；高频 tick 由 §09 哨兵确定性 O(1) 零 LLM 不进请求 | modules/18 §1–§2 |
| 冷数据预消化 digest | §18 | 源更新时一次性结构化摘要（Python 定量 / LLM 只写叙事，§14 材料层非数字权威），存 §03 冷 digest 专表（承载物 #12）append-only；后续注入 digest 而非原文 | modules/18 §3、§03 §1.1 #12 |
| 运行时静态前缀缓存 | §18 | **复用 hermes `system_and_3`**（agent/prompt_caching.py，modules/18 §10 已核）、把冷前缀折进缓存区并修正断点布局（冷前缀在前、易变在后）；把 §17 §5.4 只用于回测的提示词缓存下沉常驻运行时；合同只承重「稳定冷前缀可被缓存复用」、不承重折扣数字 | modules/18 §4、§17 §5.4 |
| 变更门控注入 | §18 | source_hash/effective_time 判 delta：未变引 handle 不重发、已变注入新 digest 标变化点；`source_hash` 是冷源原文指纹（canonical 字段家在 §18 冷 digest 专表 #12、**非归因接缝成员**），门控**消费** §20.3 双时态锚点（`effective_time`）判版本前推，`source_hash` 变化在 §18 内一信号双驱动重算 + 解门控 | modules/18 §5.2、§20.3 |
| 缓存拓扑纪律 | §18 | 冷前缀确定性序列化进 §15 部署铁律 + Tier-1 命中断言（`cache_read_tokens>0`）进 §13 + 命中率/复用/门控跳过留痕进 §11（防静默失效） | modules/18 §6、§15 §2、§13 §2.1、§11 §1.3 |

### A5 原子注册表（外置文件 · `appendices/atomic-registry.md`）

成书后新增的外置文件附录（A1–A4 为 inline，A5 为首个外置文件附录）：六层执行单元命名空间治理——Signal Atom / Tool Atom · Domain Analyst Node · Execution Node / Evaluation Node · Blueprint Family——作**设计参考池 + 命名空间治理**、非承诺资产清单。替代旧 15 号 newfeature 报告 `financial-signal-inventory-manifest`（该报告随本附录退役）。三受治理枚举成员集的 canonical 家在 §05 分类节 / §16 §1 清单 3；原子 → live 的唯一登记通道 = §16 资产版本治理。

---

## 成书收束

ValueHermes 架构总设计书大型架构设计阶段交付完成。§03–§19 的 module 细稿为章级 canonical 事实源；§00/§01/§02 前言·画像·三态与 §20 边界章正文即 canonical；附录 A1–A4 实体化（A1 二十模块三态矩阵、A2 hermes 证据映射与复核账、A3 未决总账与簇批归属、A4 全局统筹矩阵），A5 原子注册表为外置文件附录。

- **北极星守恒**：只 advisory 不执行交易 / 本地优先两不变量贯穿全书，封存接口（§20）使其只能被显式解封；agent-first 倒转延伸至运行时观测与测试期（§11–§13），并延伸至报告与证据面——**advisory report + machine-readable evidence manifest + replay handle** 三件套（canonical §14 §7；来源治理 §04 §8.7；承载 §03 #19/#20；快照 §16 §2.3 子快照；轨迹 §11；回放评测 §13/§17；呈现 §10 §10.4）——不新增顶层模块与第四数据库，用户来源控制不得削弱系统硬闸与判断权。
- **证据纪律**：每个「继承 / 改造 / 放弃 / 后置 / 升格」判断链回考古书或 evidence-map（A1）；hermes 断言均引真实本地路径（A2）；外部文献经硬闸过滤、不作承重依据；数值一律 no-invent。
- **成书后新增章**：用户续增报告收编为 **§18 冷数据 Token 经济层**（29 号：温度分层 + 冷 digest 预消化 + 运行时静态前缀缓存 + 变更门控 + 拓扑纪律）、**§19 逐股·跨时间画像层**（30 号：沿标的时间轴的类型/驱动/漂移三视图统计摘要，与 §17 策略衰减互为姊妹回路，是统计摘要非分类器）两新增章，与 §14 判断权域新增的**投资者本人建模纪律**（31 号，§14 §2.7）。17–28 号及更早命名报告已收编对应章；成书后新写的命名决议/契约稿亦已按 `docs/plans/archive/2026-07-04-pre-sync-index.md` 的对账地图与用户决议逐批折进对应章（该索引使命完成，留作对账历史记录）。旧 15 号报告 `financial-signal-inventory-manifest` 由附录 A5 原子注册表替代退役。
- **下一步待用户规划**：实现切片启动、OpenSpec 启用（overlay §4）、底座改造立项、§20 封存项激活——均属「下一步」，由用户与团队共同规划后进入 ms-loop 实现期。本阶段不写实现代码（overlay 架构期硬边界）。
