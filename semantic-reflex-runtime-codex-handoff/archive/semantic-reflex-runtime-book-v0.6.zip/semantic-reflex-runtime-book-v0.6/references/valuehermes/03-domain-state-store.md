# ValueHermes 模块 03：领域状态库与状态契约

> 状态：**✅ 定稿**（2026-07-02 用户评审通过；三拍板项：落位方案 A ✅ / memory provider 降级为读通道 ✅ / advisory 表级隔离 ✅）
> 骨架定位：**全书第一优先设计对象**（`docs/architecture/00-master-design-book.md` §03、A3）
> 证据纪律：hermes 事实只引 `hermes-agent/` 真实本地路径（本章引用的每条 hermes 断言均经本地源码复核，见 §04 证据索引）；legacy 事实引考古书 `docs/research/valueagent-legacy-archaeology/`（下称「考古 11」「考古 13」等）；三态候选引 `docs/research/legacy-tri-state-arc/tri-state-candidates.md`（下称「三态册」）。

---

## 0. 本章定位：为什么这是第一优先

**hermes 的最大空档就是这里。** hermes 的 `SessionDB` schema 只有四张业务表：`sessions` / `messages` / `state_meta` / `compression_locks`（另有一张 `schema_version` 版本记录表；`hermes-agent/hermes_state.py:695-785`），存的是对话会话、消息、token 成本与压缩锁——**它是会话存储，不是通用领域存储**。组合、决策账本、行情缓存、回测产物、thesis/投研记忆在 hermes 没有现成的 home，任何结合路线都必须自建（`docs/research/hermes-fit-arc/README.md` §结论 4、§3 轮子替换表末行）。

**它又是其他构件的地基。** 三态册跨模块注记明言：legacy 11 是 09/10 的地基，「state schema 是实际 IPC 协议」，新架构应**先定 11 层契约，再实现漏斗节点，最后共识收口**（三态册 L85）。映射到本书：§03 先定，§05-§07 蓝图与漏斗、§09 哨兵回路、§11 遥测边界、§20 归因接缝都以本章的合同为前提。骨架把本章列在所有蓝图章节之前，就是这条依赖顺序的落实。

本章回答四件事：

1. 这座库**装什么、怎么分账**（§1）；
2. 装进去的东西遵守**什么契约**——legacy 11 的血泪协议如何在自研蓝图解释器上重生（§2），legacy 13 的三条历史化机制拆到哪里（§3）；
3. 库**落在哪**——三选一决策矩阵与推荐（§4），以及与遥测（§5）、L2 节点（§6）的边界；
4. 新增职责：**风控阈值表**（§7）与 §20 归因接缝/封存接口的字段预留（§8）。

**本章不做的事**：不定义决策对象契约本体（`AnalystSignal`/`RiskLimit`/共识对象的字段语义归 §06/§07 章，本章只定它们的**落库形态与 round-trip 边界**）；不定义遥测表 schema（归 §11，本章只锁存储边界）；不定义行情数据的 provider/TTL/PIT 语义（归 §04，本章只裁定落盘位置关系）。

---

## 1. 承载物清单与分账

### 1.1 承载物总表

| # | 承载物 | 账别 | 写入方 | 主要读取方 | legacy 对应（考古锚点） | 接缝章 |
|---|---|---|---|---|---|---|
| 1 | **决策账本**（共识出口的权威产物） | 正式账 | 蓝图引擎（漏斗蓝图收口后统一写） | 常驻主体（回看/追问）、Past Context 注入、未来归因 | `consensus_decisions`（考古 11 §6 表组、条目 19） | §07、§20 |
| 2 | **风控阈值表**（新增） | 正式账附属 | §07 定量风控节点产物经引擎写入 | **§09 事件哨兵 O(1) 读**、报告呈现 | 无（新增构件，出处 `docs/research/newfeature/07-funnel-back-half/risk-execution-agent-architecture.md`） | §07→§09 回路 |
| 3 | **thesis / 投研假设账** | advisory 账 | 引擎（漏斗 buy 建议落 IDEA）、advisory 结算任务 | 常驻主体、win-rate 统计反馈、Past Context | `trade_theses` + `ThesisStore`（考古 13 条目 14-25） | §10、§20 |
| 4 | **蓝图运行史**（每次蓝图执行的元记录 + 极简结论） | 正式/advisory 随蓝图账别 | 蓝图引擎 | Past Context 注入、§12 Inspector 起点定位 | `analysis_runs`（考古 13 条目 2、考古 11 §6） | §05、§11 |
| 5 | **挖掘/深挖 advisory 产物**（扫描候选、深挖简报） | advisory 账（表级隔离） | 挖掘蓝图、跨域深挖回流 | 常驻主体、候选复看 | legacy Discovery `persist=False`（考古 01 §11 防污染机制；三态册 L104） | §08 |
| 6 | **组合视图 + IPS 申报**（三面：`portfolio_book_input` 用户显式申报持仓/关注 + `ips_constraints` 用户申报约束（`risk_cap`/`horizon`/`avoid_sectors`/集中度上限；§14 §2.7 承载①） + `portfolio_lens_snapshot` 确定性组合风险透镜摘要） | 申报账（book_input / ips_constraints）/ advisory 账（lens_snapshot） | book_input·ips_constraints=**只有用户显式申报/CRUD**（对话申报/导入）、agent 永不推断；lens_snapshot=引擎/calc-slot 确定性计算 | 漏斗入口（position/advisory mode 参数、§06 §1.4 avoid_sectors 宇宙预过滤、§07 §4.7 风险/集中度上限）、哨兵盯守范围、§07 Risk/PM 组合层消费 | `watchlist.json` + legacy「不假设持仓」纪律（考古 13 条目 24）；lens 为新增（`03-domain-state-store/portfolio-lens-summary-contract.md`）；ips_constraints 为新增（`14-transparency-and-judgment/31-investor-self-modeling-discipline.md`，§3.6） | §10、§06、§07、§14 |
| 7 | **行情缓存** | 寄存区（可重建，不入权威账） | §04 数据质量膜 | 蓝图节点、哨兵、常驻主体 | `dataflow_cache`（考古 11 §6 表组） | §04 |
| 8 | **回测产物**（预留） | 独立账（预留缝，不实现） | —（后置） | —（后置） | legacy 14 回测/归因（三态册 L263：后置，但 outcome 语义提前进数据模型） | §20 |
| 9 | **时序模式库**（波动特征向量 + 历史区间引用；源 §07 §7.3） | **习得库**（新账别，见 §1.2） | §07 定量风控特征工程管道（经引擎，§4.4 写入单点化） | §07 定量风控节点检索（唯一读者；**哨兵永不读它**） | 无直接对应（新增；出处 `07-funnel-back-half/risk-execution-agent-architecture.md` §二·轨二、20 号报告 §2.1） | §07、§04（边界） |
| 10 | **留观表 `decay_quarantine_log`**（[Decaying] 蓝图每日虚拟推演错题本；v1 即写；源 §17 §4.4） | advisory 账（表级隔离） | §17 Detection/Quarantine 半环（经引擎，§4.4） | §17 Autopsy 料源、Inspector/用户复看 | 无直接对应（legacy 14 outcome 回填 advisory 评估语义的水源实体；三态册 L263 ①、考古 14 摘要 16-21） | §17（§3.3/§4.4）、§16（版本绑定） |
| 11 | **经验专表 `golden_lessons`**（策略衰减因果教训 corpus；schema 建列、激活后写；源 §17 §4.4） | advisory 账（表级隔离） | §17 Distillation（Inspector 提议 → 用户核准准入，§4.3） | 未来 run 起手 RAG 检索注入（材料层，经 §3.4 past-context 通道） | 无直接对应（对 legacy 14 `skill_records` 语义过载的反面清偿——一表一权威语义；三态册 L268） | §17（§4.3/§4.4）、§12（`source_report_id`） |
| 12 | **冷数据 digest 专表**（§18 预消化流水线的机读产物；版本化键 (entity, source_type, effective_time)、append-only、每行携原文 handle；源 §18 §3） | advisory 账（表级隔离） | §18 预消化流水线（经引擎，§4.4） | 全体推理注入面（主体 / 漏斗节点） | 无直接对应（新增；出处 `docs/research/newfeature/18-cold-data-token-economy/29-cold-data-token-economy-architecture.md`） | §18、§04、§20 |
| 13 | **逐股画像专表**（§19 画像聚合流水线的机读产物；持久物化专表、版本化键 (ticker, 视图类型, effective_time 窗, regime 段, 聚合参数快照, 置信衰减曲线, 可证伪标注, status[active/superseded])、append-only、一表一权威、链回底料输入引用 + 原文 handle；源 §19 §7） | advisory 账（表级隔离） | §19 画像聚合流水线（经引擎，§4.4） | AOI 只读、主体 drilldown、§17 姊妹回路 | 无直接对应（新增；出处 30 号报告；呼应「无标签每次现算」） | §19、§07、§17 |
| 14 | **投资者行为诊断专表**（§14 §2.7 承载②；从券商成交记录确定性计算行为偏差的可证伪统计摘要；版本化键 (investor_scope, bias_kind, effective_time 窗, 置信衰减曲线, 证伪条件, status[active/superseded])、append-only、一表一权威；证据门控默认不激活、样本不足即报错不落表；schema 单一真相 §3.6） | advisory 账（表级隔离） | §3.6 行为诊断流水线（经引擎，§4.4） | AOI 只读、主体 drilldown（教练/反思材料）、读侧投影现场合成 | 无直接对应（新增；出处 `14-transparency-and-judgment/31-investor-self-modeling-discipline.md`；同 §19「可证伪统计摘要非分类器」范式、盯**投资者**的第三姊妹回路） | §14、§06/§07、§13、§10 |
| 15 | **券商成交记录导入账**（§14 §2.7 承载②料源；用户外部导入的真实成交史，行为诊断的确定性料源；FIFO lot 匹配等 schema 单一真相 §3.6） | **高敏 PII 独立账别**（本地、只读、永不云同步；四业务账别外的强隔离面，§1.2） | 用户导入（经受控导入面，只读入账、系统不改写） | §3.6 行为诊断流水线（唯一读者） | 无直接对应（新增；`14-transparency-and-judgment/31-investor-self-modeling-discipline.md` §5 PII 纪律）；**永不作持仓权威源**（持仓权威 = 申报账 #6）；orders 空表封存缝零改动（§8 / master §20.1） | §3.6、§20、§10 |
| 16 | **Run 收口 commit marker**（跨库提交完成事实索引；formal/advisory run 收口后的"是否完整提交"事实，本轮复核补强） | 控制面事实（跨四级分账、非 §1.2 四账别本体，物理落 domain.db 同库不同表，定位同 `schema_version` 元记录，详见 §4.5） | 蓝图引擎（run 收口时，经 §4.4 单点化写入拓扑，不新增写入方角色） | Inspector（§12）、`post_restore_audit`（§15） | 无（新增；出处 `docs/research/_claims/valuehermes-cross-layer-contract-gap-review.md` §3 F3） | §05、§11、§13、§15 |
| 17 | **维护请求控制表 `maintenance_request_v1`**（refresh/supersede/rollup 请求的统一落点，本轮复核补强） | 控制面事实（非 §1.2 四账别本体，物理落 domain.db 同库不同表，定位同 #16 `run_commit_marker`，详见 §4.6） | 发起方（Composer §10 / `sidecar_drift_watcher` 等 §19 producer）——只写本表、不碰源表 | §18 预消化流水线 / §19 画像聚合流水线 / §17 Distillation（各自 owner 消费待办后回写 status） | 无（新增；出处 `10-resident-agent.md` §9.2「refresh 请求非写」+ `19-per-stock-cross-time-profiling.md` §7.2 `sidecar_drift_watcher` 权限边界——两处只留发起权、从未给统一落点） | §10、§19、§18、§17 |
| 18 | **用户复盘记录专表 `advisory_replay_records`**（§05 `write_scope` `replay_records` 承载物落点回填） | advisory 账（表级隔离） | 蓝图引擎（`DECISION_REPLAY`/`MONTHLY_THESIS_REVIEW` 等 review/replay 蓝图收口后写，经 §4.4 单点化） | 常驻主体（用户复盘查询）、Past Context 注入 | 无直接对应（新增；出处 `05-blueprint-engine-control-plane.md` §2.4.4 `write_scope` 二分裁定，原括注「承载物待 §03 补行」） | §05、§10、§13 |
| 19 | **来源策略申报账 `source_policy_declarations`**（用户 allow/deny/prefer 来源声明与版本史；§04 §8.7 的声明侧承载） | 申报账（同 #6 家族：用户 CRUD、agent 永不推断/放宽） | 只有用户显式 CRUD（经 §10 §8.1 受控写面提案-确认门，引擎 §4.4 单点落库） | §04 §8.7 策略解析（fetch/cached-consume 双闸）、§16 §2.3 生效快照冻结、§10 §10.4 呈现 | 无直接对应（新增；出处 `00-cross-cutting/33-end-to-end-evidence-trace-and-replay-contract.md`） | §04、§16、§10 |
| 20 | **Advisory 报告证据 manifest `advisory_report_evidence_manifests`**（report/claim/evidence 轻量长期账——§14 §7 三件套的 durable 半边） | advisory 账（表级隔离、append-only） | 蓝图引擎（advisory report 收口时写，经 §4.4 单点化） | 常驻主体（§10 §10.4 Evidence Drilldown：**域库读面直读本表** + 按稳定 refs 可选下钻 §11 AOI 过程投影 `report_trace_public_view`）、§13 回放选择、审计 | 无直接对应（新增；出处同 #19；条文 canonical §14 §7） | §14、§04、§11、§13、§16、§10 |
| 21 | **Run Intake Record `blueprint_run_queue`**（control-plane 排队/认领/派发交接/派发前取消/取消命令/封窗 preimage 的 control ledger） | 控制面事实（非 §1.2 四账别本体，物理落 domain.db 同库不同表，定位同 #16/#17） | **physical DB write authority = 仅 `domain_store/run_queue.py` 窄 API**（零业务账联表写）；`control_plane/run_intake.py` = control-plane orchestration/caller（经窄 API 调用，**不直接持有 SQL/DB writer authority**） | control-plane intake/restart orchestration（restart 恢复分类的 intake 驱动只读面） | 无（新增；出处 live spec `blueprint-run-intake`） | §05（§5.3/§5.4）、§15 |

**新增承载物（行 9-15）字段级 schema 的单一真相在来源章**——`decay_quarantine_log` / `golden_lessons` 见 §17 §4.4（原样采纳），时序模式库见 §07 §7.3（向量索引载体选型归实现期），冷数据 digest 专表 schema 单一真相见 §18 §3、逐股画像专表 schema 单一真相见 §19 §7；**投资者行为诊断专表（#14）与券商成交记录导入账（#15）schema 单一真相见本章 §3.6**（field-level 授权实现期，§11 未决 #13）；本表只登记账别、写入/读取方与接缝，不复制 DDL，避免账面漂移（一表一权威语义 §1.3 同样约束文档：schema 单一真相在来源章）。逐股画像专表（#13）物理形态已由 §19 §7.2 裁定为**持久物化 advisory 专表**（append-only、表级隔离、归 advisory 账故落 HERMES_HOME 进备份，区别于寄存区），on-demand 现算与 sidecar 仅为生产/刷新策略、不改变本承载物存在。**行 16 `run_commit_marker`（本轮复核补强）field-level schema 单一真相见本章 §4.5**——它不计入 §1.2 四级分账本体，是收口事实索引这一控制面元记录，不改变四级分账纪律本身。**行 17 `maintenance_request_v1`（本轮复核补强）field-level schema 单一真相见本章 §4.6**——定位同行 16，控制面事实、非 §1.2 四账别本体。**行 18 `advisory_replay_records`（本轮复核补强）field-level schema 单一真相见本章 §3.7**——advisory 账新表，回填 §05 §2.4.4 `write_scope` 括注的「承载物待 §03 补行」缺口。**行 19 `source_policy_declarations` schema 单一真相见本章 §3.8**（申报账、彼此独立于行 20）；**行 20 `advisory_report_evidence_manifests` schema 单一真相见本章 §3.9**——二者是两个独立承载物、两种权威语义（用户声明 vs 报告证据索引），依 §1.3 一表一权威不得合并，且**均不复用行 18 `advisory_replay_records`**（其语义是用户复盘诊断记录，非通用报告证据账——复用即语义过载）。**行 21 `blueprint_run_queue` field-level schema 单一真相 = live capability spec `blueprint-run-intake`**——authority = pre-dispatch intake/control-command facts；**零执行快照列、不是第二份 run-state truth**（`begin_dispatch` 后执行真值归 `blueprint_run_checkpoints` + run FSM + `run_commit_marker`）；定位同行 16/17 控制面事实，不改变四级分账纪律。

**承载物 #5 简报边界**：beacon-triggered investigation 的 DeepDive_Briefing 落 #5 advisory 账简报表（§08 §5.2）；briefing 是被消费的 advisory 材料，**永不作为 wakeup event 重回 §09 事件池**（§09 §4.6）——状态是权威、事件只是边沿通知，简报的回流是主体 / thesis review 的消费面（§10），不构成新的唤醒源。

### 1.2 四级分账纪律：正式账 / advisory 账 / 寄存区 / 习得库

legacy 最重要的系统级协议之一是**正式决策写入与 advisory/展示路径严格分级**：Discovery 全程 `persist=False` 不污染 outcome/attribution/win-rate 基线（考古 01 §11；三态册跨模块注记 L185「这条分级必须原样重立，否则 outcome/attribution/win-rate 全部失真」）。新系统与 legacy 有一个关键差异：**挖掘扫描与深挖的 advisory 产物要求可回看**（骨架 §01 生命周期表「挖掘扫描 → §03（advisory 账）」），不能再用「干脆不写」实现隔离。因此本章把 legacy 的「不写=隔离」升级为**表级隔离**：

- **正式账**：只收完整漏斗共识出口的产物（决策账本 + 风控阈值表）。未来一切 outcome 回填、归因统计**只读正式账**。
- **advisory 账**：挖掘候选、深挖简报、thesis（其本质是 advisory 建议的生命周期记录）各自独立表，与正式账物理不同表；**禁止用行级 flag 混在决策账本里区分**——flag 漏查一次就污染基线，表级隔离让「误把 advisory 计入统计」在 SQL 层面就写不出来。冷数据 digest（§1.1 #12）、逐股画像（§1.1 #13）与投资者行为诊断专表（§1.1 #14）均归本 advisory 账——它们是材料层文本/机读产物，append-only、可版本回看、可标 `superseded`，但既非权威决策账、也**不入习得库账别**（它们不是「可重建但成本非平凡」的向量/索引载体，而是预消化/聚合/诊断的材料实体）；不变量守恒：digest/画像/行为诊断是材料层，其数字**永不获数字权威**、不进 voter 权重 / confidence / 阈值表（行为诊断另守归因墙——盯投资者不盯标的 alpha，§14 §2.7 通道二、§3.6），若其结论进入后续正式决策，同样经决策账本行的输入引用字段链回（§1.2 末段扫描/深挖分账标注同构）。用户复盘记录专表（§1.1 #18）同归本 advisory 账，但语义不同于上述三者——它是历史时点诊断快照，append-only 但**不追踪『当前有效版本』、不标 `superseded`**（无需被推翻的「当前版本」语义，区别于 digest/画像/行为诊断的 status 演化模型），schema 与写入合同见 §3.7。报告证据 manifest（§1.1 #20）同归本 advisory 账、append-only——它存的是**审计结论所需的轻量引用与指纹**（refs/hash/时间边界/replay handle），不是报告版式：渲染报告仍属展示层现场合成不落库（§2.2），manifest 永不成为「第二张决策账」，其引用的 advisory 结论进入后续正式决策仍走决策账本行输入引用链回（本段既有纪律不变）。
- **高敏 PII 导入证据（四业务账别外的强隔离面）**：券商成交记录导入账（§1.1 #15）不属上述四业务账别——它是用户外部导入的**高敏 PII** 证据（真实成交史），落**本地独立高敏账别、只读、永不云同步**（PII 强化本地优先不变量），仅 §3.6 行为诊断流水线可读；**永不作持仓权威源**（持仓权威仍是申报账 #6），系统只读用户执行史作证据、**永不产/执行订单**——orders 空表封存缝零改动（§8 / master §20.1）。**访问边界钉死（本轮复核补强）**：#15 physical authority 归本账，不是普通 MCP lookup 域——§04 §8.6 对其的 gated 登记（「用户显式导入 only、高敏 PII、LLM 语境 no、永不 portfolio 权威、永不云同步」）只是受控导入面的格式/来源校验（import-validation boundary），不产生 LLM 可见 `DataResult`、不对 L2 headless 节点开放、不接受主体或挖掘蓝图的通用查询；唯一合法读者是 §3.6 行为诊断流水线本身（经受控访问模块内部读取，非工具化暴露给任何 prompt）。**默认排除普通备份**：#15 默认不进入普通 `hermes backup` 覆盖面、不走 HERMES_HOME 通用 backup 扫描路径纳入的一致性承诺（区别于逐股画像等 advisory 专表落 HERMES_HOME 天然进备份，§1.1 表脚注）；若用户需要备份/迁移该账，须走独立显式导出流程（单独确认，且 restore 后仍保持本条账别隔离与唯一读者限制）——导出机制的部署级钉死（manifest 字段、加密方式）归 §15。
- **寄存区**：行情缓存等可重建数据。特征是删掉不丢事实、可随时重建；不参与备份一致性承诺（见 §4.2 备份维度）。
- **习得库**（第四账别，源 §07 §7.3「习得库第四账别」用户拍板 ✅）：系统内部**习得经验**的向量/索引载体（现唯一成员：时序模式库 §1.1 #9）。它介于寄存区与 advisory 账之间——**可重建但成本非平凡**（重建需重跑全历史特征工程与嵌入，不是寄存区那种「删掉随时廉价重建」），故**参与备份一致性承诺**（区别于寄存区不参与备份）；但它既非权威决策账、也非 advisory 建议的生命周期记录（区别于 advisory 账）——它存的是本系统对时序/波动的认知产物（特征定义与嵌入方式都是内部习得，§07 §7.3 认知边界论证）。跨特征/嵌入版本的向量不可比，版本字段随 §16 资产治理入库；载体物理落位与向量索引选型归实现期（本章未决 #12；统一合同见 §1.4 `embedding_facility_v1`）。**注意与 advisory 习得域的区分**：`golden_lessons`（§1.1 #11）虽属「习得」概念域，账别仍是 advisory 账（append-only、不可重建、料源为留观错题本），不入本账别——习得库专指「可重建但成本非平凡」的向量/索引载体。

**扫描/深挖分账标注**：深挖回流若改写了某次正式决策的输入（§08 待答「深挖结论自动改 signal/confidence 还是只作简报」），无论哪个方案，落库侧的合同是固定的——深挖产物本身永远在 advisory 账；若其结论进入了后续正式决策，由决策账本行的输入引用字段（§8 归因接缝）链回该 advisory 记录，而不是把 advisory 记录升格进正式账。

### 1.3 负面清单：不属于本库的东西

| 不装 | 归属 | 依据 |
|---|---|---|
| 对话会话/消息/上下文压缩状态 | hermes `SessionDB`（`hermes-agent/hermes_state.py:695-785`） | 13 拆分：会话面归底座吸收（骨架 §02） |
| 高基数遥测轨迹（Frame Lifetime Trace、评分张量、回退流） | 遥测挂载表（§11 定稿；本章边界裁定见 §5） | 状态流裁剪契约（骨架 §01 协议桩） |
| Inspector 溯源报告 | 物理隔离归档目录（§12） | `12-inspector-agent/observer-agent-telemetry.md` §五「隔离审计域」：防知识库污染 |
| 评测结果（Tier-2 评分张量 / 量规 / 晋升证据 `promotion_evidence`） | 评测库 `evaluation.db`（§13 §3.5；本章边界见 §5） | 评测裁定非业务账（§1.2 分账铁律；judge score 不进 voter 权重、不当 alpha，§13 §3.4） |
| 蓝图/SKILL 版本资产与 Feature Flag 注册表 | 文件态资产 + §16 版本治理 | legacy 12/14 教训：运行结果状态不进版本文件，版本文件不进运行库（三态册 L269） |
| 订单/交易执行记录 | **不存在**（封存接口，§8） | 不变量 advisory-only |

**一条从 legacy 12/14 带来的拆表纪律**：`skill_records` 同时承载 persona vote、reflection、outcome、attribution、thesis_id，是三层共用且语义过载的水源表（三态册 L268「新架构应显式拆分事实表，这是三篇文档共同指向的最大数据模型教训」）。本库从第一天起执行**一表一权威语义**：上表每行承载物就是一张（组）独立事实表，禁止「顺手复用」现有表的空列装新语义（legacy 把 `analysis_runs.market_context` 复用为 skill assignment JSON 容器即反例，考古 12 §包袱 5）。

### 1.4 `embedding_facility_v1`：嵌入设施统一主家（销账：store/version/index/backup/sensitivity 合一）

时序模式库（§1.1 #9）、深挖语义新颖度 IG（§08 §4.4）、逐股画像相似度检索（§19 §7）、经验专表 Golden Lesson RAG（§17 §4.3/§4.4 `embedding_ref`）共用同一套「域内自带嵌入设施」（hermes 无一等嵌入 API 是四处共同论据，§08 §4.4 已核）——但此前 store/version/consumers 散落四章、无一处合并主家。本节立 `embedding_facility_v1`：**收拢既有裁定为一份合同，不推翻任何既有归属**（§07 §7.3「模式库/向量库归 §03 领域状态库」、§16 §1 清单 #7 版本治理均原样采编）：

- **store（本节持有）**：向量库/索引物理落 §03 域库同目录，§1.1 #9 时序模式库表已是范例；`golden_lessons.embedding_ref`（§17 §4.4）与逐股画像相似度检索载体（§19 §7）指向同一物理落位家，索引结构/检索载体具体选型仍归实现期（本章未决 #12）。
- **version（§16 是主家，本节只引不重裁）**：嵌入模型换版的版本记录义务、库重建留痕、跨版本向量不可比，全部由 §16 §1 清单 #7 定义与治理；本节不重复其条款，只作双向指针。
- **index / backup（随 store）**：索引载体与备份边界随 store 走——习得库账别的备份一致性承诺（§1.2）覆盖时序模式库；`golden_lessons`/逐股画像专表的 `embedding_ref` 字段随其宿主 advisory 表落 HERMES_HOME，天然进普通备份（同 §1.1 表脚注纪律）。
- **🔴 sensitivity（新角度，本节新增）**：thesis 账（承载物 #3）/ 持仓与 IPS 申报（承载物 #6）/ 投资者行为诊断专表（承载物 #14）派生的 embedding 是 **PII 派生物**——不外部同步、不进 provider 侧可跨调用命中的缓存前缀。分类**复用**（不新发明维度）§11 §1.5 `telemetry_pii_classification` 账别边界 + §18 §6-4 `sensitivity_class` 枚举：`user_thesis` / `user_portfolio` / `behavior_derived` 三类默认 `provider_cache_allowed = false`，本节把该默认延伸到「嵌入设施自身」这一此前未被 §18 §6-4 覆盖的落点（该条原文只治前缀组装器准入，未提嵌入设施本体）；`public_cold` 类事实（财报/宏观等公开材料）派生的 embedding 无此限。
- **consumers（四方共用，本节只作汇总指针）**：§07 时序模式库、§08 深挖语义新颖度 IG、§19 逐股画像相似度检索、§17 Golden Lesson RAG——四处各自已声明「固定嵌入模型下确定性」「跨版本分数不可比」（§08 §4.4、§07 §7.3 同款纪律），本节确认四处共用同一设施与同一版本治理家（§16 §1 #7）；各消费方读侧合同/字段（如 `embedding_ref`）仍以来源章为准，不在本节复制。

**共享程度与模型选型不在此拍板（no-invent）**：本地轻量嵌入模型的具体选择、四个消费方间的共享程度（同一份嵌入 vs 各自独立）授权实现期（§08 未决 #4 承接）；本节只锁「谁拥有 store/version/index/backup/sensitivity」这份合同框架，不发明选型或数值。

---

## 2. 状态契约宪法（legacy 11 协议继承，载体重写）

考古 11 的结语：这层的精华「不是某个表或某个模型，而是把图内松耦合和边界强约束分清楚」（考古 11 §模块结论摘要条目 25）。以下六条是本库的宪法条款——**继承的全部是协议，载体（LangGraph TypedDict / StateDB 单类 / SQLite 单文件布局）全部重写**。

### 2.1 六条宪法条款

**第一条：read⟹declared，且静默丢弃升级为显式错误。**
legacy 最深的事故是 plan-63 persona channel bug：`_persona` 未在 `TradingState` 声明，LangGraph invoke 时被静默 strip，gated 多 persona run 全部退回推断 persona——「看似写入成功实则每个 persona 不是独立视角」（考古 11 条目 2-3、§内部运作机制 1）。修复靠声明 sidecar + survive-invoke 测试。三态册的裁定是本章直接采纳的：**新解释器自研，可以把『静默 strip』直接设计成显式错误，比 legacy 更强**（三态册 L81）。落到蓝图状态合同：
- 每个蓝图声明其状态白名单（节点可读/可写的键与类型）；
- 节点读未声明键 → 解释器**报错**而非返回 None；节点写未声明键 → 解释器**报错**而非静默丢弃；
- 白名单本身是蓝图 DSL 的一部分（§05），随 §16 版本治理。

**第二条：弱运行态 + 强边界，但边界收紧程度重新论证。**
legacy 刻意保持图内 `TypedDict(total=False)` + defensive reads，只在出口/持久化点强校验，其最强警告是「不要全量 Pydantic 化」（考古 11 条目 25、§危险边界 1）。三态册同时提醒：该警告的前提是 legacy LangGraph + 渐进演化现实，「新解释器自研时可重新权衡，只是必须重新证明 partial-dict / mode-gated 缺失语义后再收紧，不能默认『新=全强类型』」（三态册 L92）。本章的裁定：
- **节点边界（进/出解释器）与库边界（进/出本库）强类型强校验**——这两处是跨进程、跨生命周期的真边界；
- **节点内部运行态不做规定**——L2 节点是独立进程（§6），其内部怎么组织数据不属于状态合同；
- **可选字段的缺失语义显式声明**：白名单里每个键标注 required/optional 及缺失含义（「功能关闭」vs「上游失败」），继承 legacy「advisory/shadow sidecar 缺失是状态不是错误」的语义（考古 11 §异常与降级）。

**第三条：分级失败策略——运行态宽、长期持久化严。**
继承 legacy 的三档（考古 11 条目 20、§内部运作机制 3、三态册 L66）：
- 运行态 coerce 失败：warning + 降级值，不阻断当次蓝图；
- 落库写端：**hard fail**——坏 shape 的记录 raise、不 INSERT，绝不让畸形数据污染长期历史（legacy `write_consensus_decision` 的 Pydantic round-trip gate 模式）；
- 落库失败对用户：**不吞已算出的决策**——决策失败 / 持久化失败 / 序列化失败三分层，持久化失败时用户仍看到结果 + 系统承认落库失败（考古 11 §5 `analyze_core` 出口路径，条目 12）。

**第四条：JSON 双防线（+ 可选第三层）。**
凡 JSON blob 列：写前对象级校验（round-trip validate，拦「合法 JSON 但 shape 错」）+ 读路径 fail-soft（warning + 跳过坏项，拦历史坏行），SQLite `json_valid()` trigger 作为可选第三层（SQLite 版本不支持时跳过）——三层精确对应三种坏法（考古 11 条目 18、§精华 5）。同时继承教训的另一半：trigger 和 warning 只是守卫不是 schema 规范化（考古 11 §包袱 7），**新表设计优先列级字段、JSON blob 仅用于真正开放式结构**（如 S&R 位数组），不重演 legacy「JSON blob 仍然很多」的债。

**第五条：atomic write + always-apply 幂等 schema。**
- 文件态写入一律同目录 tmp + `os.replace`（考古 11 条目 22 `atomic_write_text`：单一职责，不做内容校验）；
- 库 schema 迁移采用 always-apply：每次连接无条件跑 `CREATE TABLE IF NOT EXISTS` + PRAGMA-guarded ALTER，`schema_version` 只作人读记录——legacy 曾因「加表忘 bump 版本」让老用户库永远缺表（考古 11 条目 14-15、§为什么做 5）。旁证：hermes `SessionDB` 同样走 `CREATE TABLE IF NOT EXISTS` 全量 SCHEMA_SQL + 延迟索引补列的路线（`hermes-agent/hermes_state.py:695-800`），两个独立演化的系统收敛到同一模式，说明这是 SQLite 长生命周期库的稳态解。

**第六条：运行数据出 repo，进 HERMES_HOME。**
legacy 用 `VA_HOME`（默认 `~/.valueagents`）把 DB/watchlist/auth/cron 移出仓库（考古 11 条目 23）；ValueHermes 是 HERMES_HOME profile 发行配置（骨架 §00 前提 3），对应物即 HERMES_HOME 下的自持目录（§4 推荐方案）。这同时是**本地优先**不变量的存储面落实。测试隔离协议一并继承：测试一律指向 tmp 库，绝不 ambient 依赖本机真实库（考古 11 条目 24）。

### 2.2 决策账本的落库形态：core record ≠ trace store

legacy 的有损 round-trip 是一条必须显式设计的边界：`write_consensus_decision` 只存每票的 persona/win_rate/decision，affinity、debate、bull/bear case 等展示 sidecar 不 round-trip，「读回 CD 不等同原始 runtime CD」（考古 11 条目 19、§04、§危险边界 4）。legacy 的问题不是有损本身，而是**边界从未显式声明**，导致「StateDB 能读回，所以它保存完整 consensus」的误读（考古 11 §误读表）。

新库把这条边界写进合同，并与北极星增补的遥测层配合，变成**三层存储分工**：

| 层 | 存什么 | 落哪 | 保真承诺 |
|---|---|---|---|
| **权威层**（决策账本行） | 共识出口极简信号契约 + 权威字段（action/size/一致度/信念/理由摘要/输入引用） | 本库正式账 | 永久、强 schema、可完整 round-trip |
| **过程层**（评分张量、辩论全文、回退流、每票 sidecar） | 追踪元数据 | 遥测挂载表（§11） | 高保真但可按保留策略裁剪 |
| **展示层**（报告渲染、卡片） | 由权威层+过程层现场合成 | 不落库 | 不承诺 round-trip |

这正是骨架 §01「状态流裁剪」协议桩在存储侧的另一半：业务节点输出契约压缩至极简结论进权威层，元数据由底座中间件捕获进过程层——本库**因此可以承诺权威层完整 round-trip**，legacy 做不到这点正是因为两层混在一张表里只好有损取舍。

### 2.3 字段语义一次定死

- **一致度与信念拆成两个独立字段。** legacy `final_confidence` 在 voter/council/DB/CLI/web 五处语义不同（非 council 时是票份额 tally，council 后变成被选 persona 的信念），三态册明言「新架构定契约时应一次定死『一致度 vs 信念』两个独立字段」（三态册 L88、考古 10 教训）。决策账本从第一行起就是两列，禁止任何消费方从单字段猜语义。
- **display/shadow 字段绝不进权威字段。** 三篇考古共同锁定的红线（三态册 L86）：shadow 对比、council shadow meta、展示 sidecar 一律进过程层（遥测），权威层没有它们的列。
- **advisory sell sentinel 语义保留。** 无仓位时的方向性看空表达为 `sell: 0.0` 而非折叠成 hold（考古 09 精华，三态册 L18）——账本 schema 必须允许 size=0 的方向性记录。
- **honest None / honest empty。** 缺数据就是 NULL/空表，禁止 0.5 兜底信心、禁止编造 invalidation signals（考古 13 条目 28、§危险边界 5-6）。
- **共识出口极简信号契约**是账本行与阈值表的共同上游：`{ticker, signal, confidence, horizon}` 形态（`07-funnel-back-half/risk-execution-agent-architecture.md` §一；字段级定稿归 §07 待答）。

---

## 3. legacy 13 拆分落位：会话面归底座，投研历史语义在本章

### 3.1 分工线（hermes 吸收面，源码证据）

三态判断「13 拆」的分工线，经本地源码复核如下：

| 面 | 归属 | 本地证据 |
|---|---|---|
| 对话会话/消息持久化、FTS 搜索 | hermes `SessionDB`（吸收） | `hermes-agent/hermes_state.py:695-785`（表）、`:802-855`（FTS5 + trigram 触发器） |
| 上下文压缩、压缩前抢救 | hermes 记忆/压缩面（吸收） | `agent/memory_provider.py:220-230`（`on_pre_compress` 钩子，语义与 legacy `InvestmentMemoryProvider.on_pre_compress` 同构）；`agent/context_compressor.py`、`agent/conversation_compression.py`（文件存在，未深读，细部归实现期） |
| 记忆 provider 编排 | hermes `MemoryManager`（吸收） | `agent/memory_manager.py:1-24`（单一集成点；**同时仅允许一个外部 provider**，防工具 schema 膨胀） |
| 投研历史实体（决策账本/thesis/运行史）的 schema 与语义 | **本章**（域层自建） | hermes 无对应（§0） |
| 域历史 → 常驻主体 prompt 的注入 | 域层实现、经 hermes 接缝挂载（§3.4） | `agent/memory_provider.py:94-106`（`prefetch` 返回 formatted string） |

一条防复活警告直接继承：legacy 自己已删除早期 OpenSpec 里的 `MemoryProvider` ABC 和 `MemoryManager` 编排器，「不要因早期 spec 复活 MemoryManager 抽象」（考古 13 条目 1、§危险边界 9）。新系统**不自建**任何记忆编排抽象——hermes 已有 `MemoryManager`，域层最多做一个 provider/工具实现，绝不再造一层 manager。

### 3.2 三条历史化机制不可合并

考古 13 的最大危险警告：「不要把 `analysis_runs`、`trade_theses`、`consensus_decisions` 合并成一个 history 概念。它们的写入时机、权威语义和消费方不同」（考古 13 条目 38、§危险边界 1）。新库的对应三实体：

| 新实体 | legacy 前身 | 权威语义 | 写入时机 |
|---|---|---|---|
| 蓝图运行史 | `analysis_runs` | 「跑过什么、结论摘要是什么」——Past Context 的热层源 | 每次蓝图执行收口 |
| thesis 账 | `trade_theses` | 「给过什么建议、这个假设后来怎样」——advisory 生命周期 | buy 建议落 IDEA、结算任务关闭 |
| 决策账本 | `consensus_decisions` | 「正式决策是什么」——权威事实源 | 漏斗共识出口 |

三者由 §8 的引用字段（decision_id / thesis_id / run_id / trace_id）弱关联，**不做外键强制**（legacy 松耦合的正确部分：不是每个决策都有 thesis，考古 13 条目 15），但每条关联列必须显式建列，不重演 legacy「`entry_price_source` 算出来了却没地方存」的包袱（考古 13 §包袱 7）。

**蓝图运行史的场景/流派维度列**：运行史表（承载物 #4，legacy `analysis_runs`）**加四维切片列**——`scenario_class`（场景轴，IMC）/ `style_profile_ref` / `style_profile_hash` / `weight_profile_hash`（`blueprint_struct_hash` + `config_snapshot_id` 沿 §16 §2.1 复合元组已有；流派/权重版本亦含于 config snapshot 生效资产版本集，§16 §2.3，加列是切片归因便利、非新权威语义）。三条纪律：① **先加列、不建专表**（与逐股画像表 `view_kind` 列分维同构，一表一权威 §1.3）；② **禁止双写**——场景产物按语义路由回既有权威家（formal 账 = 仅蓝图 A / MAD 简报 / thesis 账 / 经验库），运行史只收「没有更具体归宿」的场景 run provenance；③ `scenario_class` 是 run 参数，**不产新蓝图版本、不改结构哈希**（§16 §2.2）。字段级 schema 归实现期（§05 §2.4.7 锁语义、字段组授权实现期），本表只锁语义与列位。

### 3.3 thesis / 投研记忆重设计

继承的纪律（写死，与不变量同构——三态册 L273「三模块中最应写死继承的纪律」）：

- **advisory 不假设持仓**：thesis 记录建议，不代表用户真实开仓；`close_advisory`（建议的事后结算）与真实平仓语义分离（考古 13 条目 19-24）；
- **win-rate 是统计反馈不是硬门**：closed thesis 按 entry_signal 聚合的 win-rate 只调后续参考阈值，不阻断当次决策（考古 13 条目 23）；
- **PnL 语义诚实**：advisory close 的 PnL 是「建议若被跟随会怎样」的 proxy，不是账户收益（考古 13 §危险边界 4）。

清偿的债（legacy 自己点名的包袱）：

- **状态机 enforce**：legacy 除 `close_advisory` 外不拒绝任何非法转换，「状态机主要是产品语义不是 Store enforce」（考古 13 §内部运作机制 8、§包袱 5）。新库把 `idea → entry_ready → active → closed/invalidated` 与 `idea → closed(advisory)` 的合法转换表写进写端合同，非法转换 hard fail（对齐宪法第三条：持久化边界严）；
- **entry_price_source 入表**：区分「真实 0」与「缺价格 fallback」（考古 13 §包袱 7）；
- **`pending` 之类的幽灵状态**不再出现：接口枚举与存储枚举同源（考古 13 §包袱 8）。

**组合视图与 thesis 的关系**：legacy 的 `has_existing_position` 被硬编码 False，真实持仓无处表达（考古 09 包袱，三态册 L28）。新系统的常驻对话形态第一次给了用户**显式申报持仓**的自然入口（对话中告知/导入），申报落组合视图表（§1.1 #6）。三态册跨模块注记 L89 的要求由此闭环：漏斗入口显式传 position/advisory mode，值**只来自申报表**，agent 永不从 thesis 或决策历史推断持仓。

**组合视图的两层化（`portfolio_book_input` / `portfolio_lens_snapshot`）**：承载物 #6 分两层——`portfolio_book_input` 是用户显式申报/导入的原始组合（唯一合法 book 来源，agent 不得从 thesis / watchlist / 历史建议 / 聊天暗示推断持仓，归申报账）；`portfolio_lens_snapshot` 是引擎/calc-slot 对 book_input + 市场数据 + 分类映射做**确定性计算**得到的组合层风险摘要（单股/行业暴露、主题重叠、相关性、因子暴露、组合动作温度），归 advisory 账、只作材料层、不写正式账。硬边界：Portfolio Lens 是**组合层 advisory 风险透镜、非组合优化器**——只读用户显式 book、Python 算暴露、LLM 只解释不计算、**只能收缩 buy/add 动作温度（shrink-only）**，不生成 target weight / 再平衡指令 / 订单，不写 formal ledger、不推断持仓（出处 `03-domain-state-store/portfolio-lens-summary-contract.md`；§07 Risk/PM 消费接缝见 §07 §4.6）。

**盯守集（watch_scope）只读合成契约**：§09 非破位事件 producer 与 §04 Feed Handler 订阅集消费的盯守集族——`active_holdings`（申报持仓 #6）/ `candidate_pool`（挖掘候选 #5）/ `user_watchlist`（用户关注 #6）/ `thesis_linked_entities`（thesis #3 关联标的）/ `temporary_conversation_focus`（§10 对话临时关注，时限化 expires_at）/ `strategy_watchlist` / `sector_watchlist` / `supply_chain_watch_scope`——全部由 §03 已有承载物 + §10 临时关注集**只读合成**下发；producer / Feed Handler **不自造盯守权**、不新增盯守状态实体，盯守集派生自 #6 组合视图与既有 advisory 账，供给侧与临时关注集时限语义归 §10。

### 3.4 Past Context 注入通道（读侧）

legacy 的注入协议整体继承（考古 13 §精华 1-5）：域历史格式化为 prompt-ready 字符串；same-ticker 细（含 reflection narrative）/ cross-ticker 短教训分段；只取有结论的记录；注入位置在 skill/persona 指引后、当前事实前；**fail-soft——历史是参考不是事实权威，读取失败只省略段落，绝不阻断当次分析、绝不覆盖 Python 计算的当前事实**（考古 13 条目 7-8、§危险边界 2）。

hermes 侧的挂载点有三个候选，本章**不定稿**（归 §10，与 JIT 规划器一并看）：

1. **外部 memory provider**：`prefetch(query) -> str` 的形态与 `get_past_context` 完全同构（`agent/memory_provider.py:94-106`）；但 hermes 限制**同时仅一个外部 provider**（`agent/memory_provider.py:1-9`、`agent/memory_manager.py:6-9`），占用后用户便不能再挂 Honcho/Mem0 类通用记忆——这是真实代价；
2. **只读查询工具**：把「查过往决策/thesis」注册为 hermes tool，由主体按需调用（对应 legacy Copilot `lookup_recent_decisions` 的白名单裁剪协议：不透传大字段、截断摘要、详情走 drilldown——考古 13 条目 30-32 整体继承）;
3. **pre_llm_call hook 注入**：插件 hook 在每轮前拼接 Past Context 段（`hermes-agent/hermes_cli/plugins.py:135-176` VALID_HOOKS 含 pre_llm_call——该行段已由 §05 §11 / §10 §7.3 核对；且 pre_llm_call 注入的是 user message 非 system prompt，§10 §2 #4）。

无论选哪条通道，**存储决策（§4）都不受影响**——通道读的是同一座领域库。这正是把「落位」与「注入」拆成两个问题的意义。

**读侧合同已由 §10 §9 收口（记忆预取合成合同）**：域 memory provider 主通道 + 只读工具族辅通道的双通道裁定见 §10 §9；hermes 单外部 provider 限额（候选 1 的真实代价）下的**多源合并**——§17 经验库 / §18 冷 digest / §19 逐股画像 / thesis / 候选上下文都要进主体注入面——由 §10 §9.1 的唯一 `ValueHermesMemoryProvider` + 内部确定性 `PrefetchComposer` 仲裁，合并/排序/预算/冲突/渲染合同全文归 §10（不复活自建 MemoryManager 抽象，§3.1 防复活警告不破）。本库只作各源材料表（thesis 账 §1.1 #3、冷 digest #12、逐股画像 #13、候选 #5）的**读侧被组合对象**——表权威不因组合改变、Composer 只读不写任何源表，past-context 注入的 fail-soft 铁律（本节）随合同进 provider 实现。

### 3.5 经验复用的落点裁定（Legacy 13 兜底 · 用户决令）

用户决令要求「在 §03 Schema 里给 legacy 13 的经验复用语义确保专表落点」。本章的裁定是**分流承接、不新造一张 catch-all「经验复用」表**——一表一权威语义（§1.3）禁止一张表装两种权威语义：

- **投研假设/建议的经验复用**（same-ticker reflection narrative、cross-ticker 短教训、win-rate 统计反馈）——**已由 thesis 账（§3.3）+ Past Context 注入通道（§3.4）完整承接**，语义 = 「回看过往给过什么建议、假设后来怎样」。这一半是 legacy 13 `get_past_context` 的直接继承，**无需新表**（另造即重复 thesis 账语义，违反 §1.3）。
- **策略衰减因果教训的经验复用**（Autopsy 陪审团归因 → Inspector 提炼的失效教训，经 RAG 塑造未来 run 推理上下文）——由**经验专表 `golden_lessons`（§1.1 #11）承接**。它与 thesis 账不是同一权威语义：thesis 记「某条 advisory 建议的生命周期」，golden_lessons 记「某类方法为何失效的因果教训」，料源（留观错题本 vs advisory 结算）、写入时机（证据扳机激活 vs buy 建议落 IDEA）、消费面（RAG 材料层注入 vs Past Context 段）皆不同，故各自独立事实表合法（§3.2「三条历史化机制不可合并」的同构延伸）。

**兜底闭合**：legacy 13 经验复用的两瓣各有专表落点（thesis 账 / `golden_lessons`），无遗漏、无重复造表——用户决令的「专表兜底」由 `golden_lessons` 承接**新增**的失效教训语义，既有 thesis 语义则显式说明其已覆盖、不重复建表（§1.3 一表一权威语义）。

### 3.6 投资者本人建模的承载分账（§14 §2.7 carrier 落点）

§14 §2.7「投资者本人建模纪律」把「在给谁建议」立为判断权第三维（前两维 = 「标的是什么样」§06/§07/§19、「策略是否失效」§17），其契约本体（三通道钉子 + 判断权守恒 + 三态）在 §14 canonical；本节是该纪律在领域库侧的 **carrier 细稿**——「投资者本人 = 读时合成的概念/视图，统一在契约与读侧投影、拆散在存储与计算」的存储面落实。**否决「统一投资者数字孪生层」**：一个横跨「申报约束/行为诊断/决策记忆/目标锚」四正交域（溯源、信任级、写入时机、消费方两两正交）的孪生表，正是 schema 级重演 legacy `skill_records` 语义过载（§1.3），同违一表一权威与「多历史化机制不可合并」（§3.2）。**承载物新增两处（器官粒度）**：承载① 申报账升格、承载② 行为诊断器官（依 §1.3 一表一权威语义**物理落两张表**——成交记录导入账 #15 料源 + 行为诊断专表 #14 派生，不可合并；两处 = 申报账升格 + 行为诊断器官）；其余复用/后置。神经连接由**器官之间的边**（cross-reference + 校准扳机）实现，不由合并数据结构实现（同 §3.2 三历史化机制靠 `decision_id`/`trace_id` 弱关联而闭环真实）。

**承载① · IPS 约束申报（#6 申报账升格）**：组合视图申报账（#6）加一面 `ips_constraints`——`risk_cap` / `horizon` / `avoid_sectors` / 集中度上限，同一申报账家族、无需新库。纪律：**用户 CRUD、agent 永不推断**（同 #6 book_input「agent 不假设持仓」§3.3），写入复用 hermes「LLM 只出更新提案、不直接改画像文件」写入门（§10 §7.3 #11）+ 组合视图申报同族的写确认门（§10 §8.1，经受控写工具 §4.4 单点化）。消费面全为 **suppress-only**（§14 §2.7 通道一 = veto 家族第五支）：`avoid_sectors` 在漏斗入口做宇宙预过滤（§06 §1.4，塑造「分析什么」、不碰信号/置信）；`risk_cap`/集中度上限复用 §07 PM 修饰乘子与 size clamp（§07 §4.7）。🔴 **只收紧、永不放大授权**（「高风险偏好」≠ 授权更大仓位）；无申报 = no-op fail-soft（honest None，非默认激进型）。

**承载② · 行为诊断器官（#15 料源 → #14 派生）**：

- **券商成交记录导入账（#15）**：用户外部导入的真实成交史（交割单），是行为诊断的确定性料源。**高敏 PII 独立账别**——本地、只读、永不云同步（PII 强化本地优先，§1.2）；**永不作持仓权威源**（持仓权威仍是 #6 申报账）；系统只读用户执行史作证据、**永不产/执行订单**，orders 空表封存缝零改动（§8 / master §20.1）——它是「关于用户的外部证据」，不是「系统的订单」（区别于 §10 §8.3 后置影子账户的「raw CSV 不落库」：那是 legacy 16 后置能力的数据边界；本账是行为诊断的**现行**料源、落独立高敏账，随 §14 §2.7 canonical）。
- **投资者行为诊断专表（#14）**：从 #15 **确定性**计算行为偏差（处置效应 / 过度交易 / 追涨 / 锚定）的**可证伪统计摘要**——与 §17 盯策略衰减、§19 盯标的漂移**同一台机器换诊断对象**（盯投资者），故范式直接复用逐股画像专表（#13）：携 `effective_time` + 置信衰减曲线 + 证伪条件、被推翻标 `superseded`、append-only 保留审计、advisory 账表级隔离、一表一权威（**可证伪统计摘要非分类器**，同 §19）。**证据门控默认不激活**（本地优先系统多数用户无成交记录导入）、**样本不足即报错、不落表、不伪造分类**（对齐 §03 honest None：NULL 不兜默认值）。field-level schema 与 4 偏差指标算法/阈值定标授权实现期（no-invent，§11 未决 #13）。

**承载③ · 决策记忆/校准 facet（复用既有 thesis 账，零新建承载）**：建议→采纳→结果的校准闭环九成已在——thesis 账（#3）+ win-rate 统计反馈 + outcome 回填族（§8）。本纪律只补一条 **per-user 采纳/校准 facet**（系统对该用户的建议置信 vs 已实现命中），作为**边**挂上既有 thesis 账，不新建库。校准的 Brier 评测轴归 §13（§14 §2.7 通道三、§13 §3.8）；校准分 ≠ alpha、禁进 win_rate/voter 权重（归因墙）。

**承载④ · 目标锚（后置封存）**：人生目标现金流 Monte Carlo 规划判为向理财规划师的**使命漂移**（超投研 advisory 边界），落 master §20 封存缝、不建——现仅在承载① 申报账预留一个目标申报字段（master §20.2 后置资产池登记）。

**读侧投影（display 层现场合成不落库）**：不建「投资者数字孪生」层——「投资者本人」由各器官在读时现场拼装「在给谁建议」视图（走 §2.2 展示层「权威层+过程层现场合成、不落库」模式）；**自陈 ↔ 行为矛盾在此投影里浮现作材料**（申报「长期价值」vs 成交记录实测短持仓），只产反思提示、**永不静默改写申报画像**（用户自己 CRUD、gate 用新值；合法的「行为→收紧 IPS」通道只能收紧、且回环用户确认——§14 §2.7 通道二证伪边）。

**hermes volatile 记忆层的分层边界（承重 gate 走 §03、软语境走 volatile）**：hermes 三层软记忆（memory snapshot / USER.md / external MemoryProvider）全是 volatile / never-cached 的对话软记忆（§10 §2 三层 prompt 的 volatile 层）；**IPS 结构化约束（承载①）与行为诊断（承载②）永不塞进 volatile tier**——否则 (a) 确定性 gate 退化成「LLM 从自由文本读约束」（违 §14 判断权），(b) 承重可审计事实混进 never-cached 软记忆（丢审计、违 §1.3 一表一权威）。软语境（塑造 agent 语气/理解的自由文本）走 volatile，**承重 gate 与可审计诊断走本库结构化账**；同一事实可双表达，但只有结构化那份进 gate。行为诊断/thesis 的**材料层召回**（召回用户历史类似偏差案例作反思材料）可复用 hermes 原生 `MemoryProvider.prefetch`（authority 仍落本库，承载选型实现期定——§10 §9.4 / §11 未决 #13）。

**判断权守恒 + 三态**：三通道钉子（IPS suppress-only / 行为诊断材料层归因墙 / 校准 Brier 评测轴）逐条守恒于 §14 §2.7；本节承载纯约束/材料层，不产决策信号、不构成执行解封（不变量守恒）。三态：承载① **改造扩展**（#6 升格）、承载② **新增**、承载③ **复用**、承载④ **后置封存**。同行参考实现（LangAlpha / Vibe-Trading / claude-trading-skills / financial-services，`ValueAgents-dev/reference/` 本地可核验）各实现一器官、无一合成统一孪生——正是本纪律主张的空白（§14 §2.7）。

### 3.7 用户复盘记录承载物 `advisory_replay_records`（§05 `write_scope` `replay_records` 落点回填，本轮复核补强）

§05 §2.4.4 `write_scope` 枚举二分裁定「`replay_records` 二分落点——用户复盘材料落 §03 advisory 复盘记录、评测回放落 §13 evaluation.db」，当时承载物本身括注「待 §03 补行」（`05-blueprint-engine-control-plane.md:205`）。本节正式补行，登记为 **§1.1 承载物 #18**。

**物理边界（与 §13 评测回放二分不混）**：`DECISION_REPLAY` / `MONTHLY_THESIS_REVIEW` 等 review/replay 蓝图（`blueprint_kind ∈ {review, replay}`，§05 §2.4.4）收口产出 `output_authority=replay_diagnosis`——该产物落**本表**（用户看的复盘结论材料，advisory 账、表级隔离）；`replay_eval` / `decision_replay` 两种 `eval_type` 的评测方法学产物（裁判评分、归因稳定性度量、一致性判定）仍归 §13 `evaluation.db`（§13 §3.3 `eval_type` 枚举；§13 §3.4「replay 不反向改写历史结论」）。同一次复盘活动可能同时产两份记录，权威不混——用户材料 vs 评测证据——二者只经 `trace_id` 弱关联（同 §3.2 引用协议），无跨库外键。

**字段（no-invent，字段级 schema 授权实现期）**：`replay_id`（主键）/ `decision_id`（弱引用被复盘的决策账本行，同 §3.2 引用协议，非外键）/ `blueprint_id` + `blueprint_version`（复盘所用蓝图，§16 版本治理联动）/ `replay_diagnosis`（材料层文本结论，对齐 §05 硬规则「`replay_diagnosis`≠事后标签」——不得被消费方误读为对原决策的重新贴标）/ `trace_id`（§11 遥测关联，同宪法防篡改纪律 §5）/ `effective_time` / `recorded_time`（复用 §8 双时态锚点字段族，非新建字段族）/ `created_at`。

**写入合同**：写入方 = 蓝图引擎（经 §4.4 单点化，不新增写入方角色，权限模型同决策账本/thesis 账）；**只 INSERT 新复盘记录，不 UPDATE 被复盘的原决策账本行**——复盘是新增材料层证据，不是历史改写（§13 §3.4「replay 不反向改写历史结论」在存储侧的对应义务，同构 §3.5 `golden_lessons` 的 append-only 精神）。

**账别与三态**：advisory 账、append-only；不参与 supersede 语义（复盘结论是历史时点诊断快照，不追踪『当前有效版本』，区别于冷数据 digest/逐股画像/行为诊断专表的 `status[active/superseded]` 模式，同 §1.2 已补的一句）；三态判断 = **新增**（回填既有 `write_scope` 缺口；legacy 13 `analysis_runs`/`trade_theses` 未含「用户复盘专表」这一语义切片，三态册跨模块注记未点名，属本轮识别的纯缺口，非 legacy 继承对象）。

### 3.8 来源策略申报账 `source_policy_declarations`（§1.1 #19 · §04 §8.7 的声明侧承载）

用户对数据来源的 allow／deny／prefer／lens 默认与 fallback 偏好，是「在给谁建议」之外的第四类用户申报事实（同 #6 申报账家族纪律：**用户 CRUD、agent 永不推断、永不静默放宽**）。本表承载 account/workspace 等作用域的**声明本体与版本历史**：每次变更 = 新版本行（append 版本史，供审计与「声明 vs 生效」差异呈现，§10 §10.4）。

- **字段（no-invent，字段级 schema 授权实现期）**：`declaration_id`／`scope`（account｜workspace｜blueprint｜run 默认层）／三轴 selector 集（`acquisition_provider`／`origin_publisher`／`data_domain`，§04 §8.7 轴定义）×（allow｜deny｜prefer 序）／`fallback_policy`／`disclosure_policy`／`version`／`declared_at`／`declared_via`（对话提案-确认｜导入）。
- **写入合同**：只有用户显式 CRUD——经 §10 §8.1 受控写面（提案-确认门，同 #6 组合申报），引擎 §4.4 单点落库；agent 不得代写、不得从对话暗示推断偏好（§3.3「agent 永不推断持仓」同族）。
- **消费边界**：**当前声明不是历史 run 的重放真相**——run 生效策略由引擎解析后冻结进 §16 §2.3 `source_policy_snapshot_id` 子快照，历史回放只认快照（§13 `as_ran`）；本表只供「下一次 run 的解析输入」与「用户当前声明视图」。用户删除偏好 ≠ 删除历史证据（§04 §8.7 purge 独立流程）。
- **声明 vs 任务 lens 分层**：本表保存用户**明确持久化**的 allow／deny／prefer、default fallback、disclosure policy，以及用户明确执行「保存为默认」的 lens（均经同一受控写面）；**一次性 task retrieval lens 只进入 §16 §2.3 effective snapshot**（作为本次 run 的输入随快照冻结），不得未经「保存为默认」写成长期 declaration。
- **三态**：新增（legacy 无用户来源声明面；出处 `00-cross-cutting/33-end-to-end-evidence-trace-and-replay-contract.md`）。

### 3.9 Advisory 报告证据 manifest `advisory_report_evidence_manifests`（§1.1 #20 · §14 §7 三件套的 durable 半边）

§14 §7 立「report + evidence manifest + replay handle」报告级 canonical；本表是其**长期轻量承载**——永久保存足以审计结论的证据链索引，重型过程材料按需保存（§11 blob/TTL），二者以 refs 弱关联。

- **字段（no-invent，字段级 schema 授权实现期）**：`report_id`（主键）／`report_hash`（渲染产物指纹——报告本体不落库；**验证边界**：仅当原始渲染字节或 `render_contract_hash` 可指认时才可用于验证，缺 render contract 不得宣称可精确重建报告版式）／`render_contract_hash`（确定性 renderer/template 版本指纹）／`report_type`／`subject`（ticker/portfolio/theme 引用）／**claim rows·refs**（每关键 claim：`claim_id`／`claim_kind`（assertive｜insufficient_outcome，§14 §7 两态合同）／stance（positive｜negative｜neutral｜mixed——**仅 assertive 型**）／`evidence_status`（ok｜insufficient｜unavailable——**与 stance 分列两枚举**）／confidence_label／supporting_evidence_refs（assertive 型 ≥1）／contradicting_evidence_refs／`reason_codes` + 可得时 `missing_required_evidence`（insufficient_outcome 必带）／uncertainty_notes）／**evidence refs**（typed id + `content_hash` + 最小 provenance：source_ref／`evidence_type`／effective_time·recorded_time）／source·tool·analyst·blueprint run refs（`blueprint_run_id` 等沿 §05 既有身份，弱引用）／**来源策略事实（随 manifest 长期保存，不能只存在 DataResult/telemetry/eval_run）**：`actual_selected_source_refs`／`excluded_sources_and_reasons`（§04 §8.7 同源 reason 结构）／`fallback_decisions`／`evidence_coverage_status`（full｜partial_evidence_coverage｜evidence_blind_spot）／`config_snapshot_id` + `source_policy_snapshot_id` + `policy_hash`（§16 §2.3 根快照与子快照）／`data_snapshot_id` 或唯一 canonical 的 `input_snapshot_manifest_ref`／时间边界（`as_of_time`／`data_cutoff_time`）／**replay handle**（**至少锁** `config_snapshot_id` + `source_policy_snapshot_id`(+`policy_hash`) + `data_snapshot_id`／`input_snapshot_manifest_ref` + `as_of_time` + `data_cutoff_time`；`trace_id` 为过程下钻引用、不作唯一回放承重物——回放执行复用 §13 §8.1 `golden_trace_replay_v1`/§3.6 `eval_run`，**不新立回放 schema**）／`created_at`。**独立可答性**：telemetry payload 过期只降低 process fidelity——本表必须在 TTL 后仍能独立回答「本报告实际用了什么、排除了什么、为何回退」，来源选择历史不随遥测消失。
- **Evidence ID 生成纪律（typed/namespaced producer-owned refs，不设中央万能 registry）**：source evidence id 在 §04 DataResult/provenance 边界产生（`meta.provenance.source_refs` 族）；deterministic derived evidence 在引擎 **canonical-output acceptance gate** 接受后由引擎登记；claim/report id 在报告收口时由引擎登记——**本表只汇集引用，不接管任何 producer 的权威语义**（一表一权威 §1.3：manifest 是索引账，evidence 本体的权威仍在各 producer 落点）。
- **写入合同**：蓝图引擎在 advisory report 收口时写入（经 §4.4 单点化）；append-only、不 UPDATE 历史行（同 §3.7 精神：报告是历史时点产物，非「当前版本」演化模型）；**重型过程 payload 不复制入本表**（原始 prompt、长文本、完整 tool payload 归 §11——telemetry blob 已过期时本表仍保留 hash、版本、最小 provenance 与**显式 blind-spot 状态**，缺失如实标注、不冒充完整）。
- **不变量守恒**：manifest 是审计材料层——report_id/claim/evidence refs **永不写回** signal/confidence/size/voter 权重/阈值表（§14 §7 条 7）；contradicting refs 不得静默缺席（条 8）；渲染报告/卡片不作为新权威表（§2.2 展示层不落库不变）。
- **三态**：新增（legacy 报告是纯文本产物、无证据图账；出处同 §3.8；条文 canonical §14 §7）。

---

## 4. 落位三选一：决策矩阵与推荐

### 4.1 候选定义

- **方案 A：插件自建 SQLite，落 HERMES_HOME 下自持目录**（如 `HERMES_HOME/valuehermes/domain.db`，目录名待定）。含一个必须显式否决的变体 **A′：直接往 hermes `state.db` 加表**。
- **方案 B：以 hermes memory provider 为存储 home**——投研领域状态作为记忆条目存进 provider 后端。
- **方案 C：外部服务**（本机 Postgres/Redis 常驻服务，或云端存储）。

### 4.2 决策矩阵

| 维度 | A：自建 SQLite in HERMES_HOME | A′：state.db 加表 | B：memory provider 作 home | C：外部服务 |
|---|---|---|---|---|
| **本地优先（硬约束）** | ✅ 单文件本地库 | ✅ 本地 | ⚠️ 取决于 provider 后端（外部 provider 多为云服务，`agent/memory_provider.py:7` 例举 Honcho/Hindsight/Mem0） | ❌ 云端直接违反；本机常驻服务也引入部署依赖 |
| **并发/事务** | ✅ WAL + 应用层 retry（§4.4 写入拓扑单点化后写竞争极小）；跨进程读（哨兵）WAL 原生支持 | ❌ 与 hermes 全部进程抢同一写锁——hermes 自述 gateway + CLI + worktree agents 共享 state.db 已有写锁 convoy 问题，需 15 次 jitter retry + 定期 checkpoint/optimize 自救（`hermes_state.py:866-889`）；域写入再挤进去是自找竞争 | ❌ provider 接口无事务语义：`sync_turn` 非阻塞尽力写（`memory_provider.py:116-132`），无法承诺「坏 shape 不入库」的 hard gate | ✅ 事务能力最强（但为用不上的并发度付部署成本） |
| **哨兵 O(1) 读（跨进程）** | ✅ 哨兵作为独立进程直接只读打开同一 SQLite 文件（WAL 允许读写并行） | ✅ 技术可行但同锁竞争 | ❌ **结构性不可行**：MemoryManager 活在 agent 进程内，哨兵与 LLM 层物理隔离（CONTEXT.md「事件哨兵」），无法经 provider API 读；provider 也没有结构化点查接口（只有 prefetch 字符串召回） | ✅ 可行 |
| **遥测表边界** | ✅ 域库/遥测库可分文件、边界清晰（§5） | ⚠️ 三种数据（会话/域/遥测）挤一文件，边界最糟 | ❌ 遥测根本不是记忆条目 | ⚠️ 可分库但过度 |
| **备份/迁移** | ✅ `hermes backup` 只走 HERMES_HOME（`agent/memory_provider.py:299-311` docstring 明言），域库落 HERMES_HOME 天然进备份；单文件拷走即迁移 | ✅ 同左 | ⚠️ provider 外部状态需 `backup_paths()` 显式申报才不丢（同上 docstring——该机制的存在本身就是「状态不在 HERMES_HOME 会丢」的官方承认） | ❌ 备份/迁移各自另做 |
| **与 hermes 升版解耦** | ✅ 独立文件 + 自持 always-apply schema，hermes 升版改 state.db schema 与我无关 | ❌ hermes 的 schema 迁移/修复工具会碰这个文件（`hermes_state.py:556` `repair_state_db_schema` 含 `writable_schema` 级手术），域表可能被当异物 | ⚠️ 依赖 provider 插件 API 稳定性 | ✅ 解耦但代价过高 |
| **实现最小性（ponytail）** | ✅ stdlib `sqlite3` + 已被 legacy/hermes 双重验证的模式，零新依赖 | ✅ 同左但破坏边界 | ❌ 把表存储硬塞进召回接口，形状不合 | ❌ 新增部署件 |

### 4.3 推荐与理由链

> **推荐：方案 A**——插件自建独立 SQLite 文件，落 HERMES_HOME 自持目录。**（✅ 2026-07-02 用户拍板通过）**

理由链收束：

1. **两条硬约束各自独杀一个候选**：本地优先杀 C（云端）且令 C（本机服务）失去必要性——本系统写入方经 §4.4 单点化后并发度撑不起一个常驻 DB 服务的部署成本；哨兵的跨进程 O(1) 读结构性地杀 B——B 的接口形态（prompt 召回字符串、非阻塞尽力写、单外部 provider 限额）与「权威账本 + 阈值点查」的需求正交。
2. **A′ 必须显式否决而不是默认滑入**：往 state.db 加表看似「复用现成库」最省事，实际同时踩中写锁竞争（hermes 自述已是痛点）、升版耦合（hermes 的 schema 修复手术会碰域表）、边界混账三条线。`00-cross-cutting/atomic-composable-architecture.md` §2 称统一挂载点为「前期确定的 state.db SQLite 机制」——骨架 §00 已标注**本书未定此项**；本章正式裁定：**报告所指的挂载点语义由本章领域库承接，但物理上不落 hermes state.db，落独立域库文件**。
3. **B 降级为读通道候选而非存储**：§3.4 的注入通道候选 1 仍然可能用 memory provider——那是「域库之上的一个消费面」，与存储落位无关。
4. **legacy 的反面教材已内化**：A 不是复刻 legacy StateDB——legacy 的教训恰恰是「单类装 20 张业务表的汇合库」（考古 11 §包袱 1，三态册 L81「放弃 StateDB 巨型汇合库形态」）。A 的形态是：单库文件（备份/迁移单元）+ 按 §1.1 领域分组的表族 + **按领域拆分的数据访问模块**（每组承载物一个窄访问面，不建统一 ORM/repository 框架——ponytail：stdlib sqlite3 足够，access 模块只是函数集合）。**插件自建独立 SQLite 有现成落位模板**：`hermes-agent/plugins/memory/holographic/store.py:98-140`（`__init__` 直连 `HERMES_HOME` 下独立 `.db` + `_init_db` 调 `apply_wal_with_fallback` + `CREATE TABLE IF NOT EXISTS`/PRAGMA-guarded ALTER 幂等 schema）即「插件在 HERMES_HOME 自持一座独立 SQLite」的现成范例，域库照此形态、不从零起（ponytail：reuse 档）。
5. **部署铁律联动**（§15）：SQLite WAL 在 NFS/SMB/FUSE 文件系统上不可用——域库**直接调用现成助手** `apply_wal_with_fallback(conn, db_label="valuehermes/domain.db")`（`hermes-agent/hermes_state.py:341-391`；SessionDB 与 `hermes_cli.kanban_db` 共用、每 `db_label` 去重告警一次、on-disk 已 WAL 不降级，一行调用即得 WAL→DELETE 回退、网络盘自动降级），**不自实现 PRAGMA 探测**（ponytail：reuse 档）。**本地优先在存储面的精确含义是「本地真实文件系统」**，HERMES_HOME 落网络盘属于非默认部署，须进 §15 配置规范。

### 4.4 写入拓扑：全构件→状态库的写入合同

骨架 §01 协议桩「全构件→状态库的写入合同」在本章的实体化。原则：**写入单点化，读取多点化**。

| 角色 | 对本库的权限 | 说明 |
|---|---|---|
| 蓝图引擎（插件内，§05） | **唯一的漏斗产物写入方** | L2 节点产物经互斥输出路径 + 内存合并（骨架 §01 协议桩）由引擎校验后统一落库；节点自身零库权限（§6） |
| 常驻主体（§10） | 读：账本/thesis/组合/候选；写：**仅组合视图申报**（经受控写工具，走 §10 写确认门） | 主体不直接写决策类表——决策产物只能从漏斗出口来 |
| 事件哨兵（§09） | **只读**（阈值表 + 组合视图盯守范围） | 独立进程直连库文件只读；零写权限 |
| 非破位事件 producer（§09 §4.5） | **只读**（仅 watch_scope projection，见 §3.3） | 与事件哨兵同构的第二个只读常驻进程，权限收窄于哨兵：只消费 §3.3 watch_scope 只读合成结果（active_holdings / candidate_pool / user_watchlist / thesis_linked_entities / temporary_conversation_focus 等派生集）；**禁止裸读 domain.db 全表**、禁止写任何域表；不得读取 thesis 全文、候选全文、用户对话历史或 broker_import；无阈值表读权（该权限专属哨兵） |
| advisory 结算任务（cron） | 写：thesis 关闭 | 经引擎/插件同一访问模块，非绕行裸 SQL |
| 维护请求发起方（Composer §10 / `sidecar_drift_watcher` 等 §19 producer，本轮复核补强） | 写：**仅 `maintenance_request_v1`**（新增待办行）；无其余库读写权限 | 延续 §10 §9.2 / §19 §7.2 既有边界（只读源表、只写本请求表），非新增权限面；owner 消费待办、回写 status 的写权仍是各自来源章既有写入方角色，不因本表新增角色（§4.6） |
| Inspector（§12）/ 评测（§13） | **只读** | 且主要消费遥测库（§5），域库只作关联查询 |

并发结论：写入方收敛为「插件访问模块」一个代码路径（引擎、结算、申报工具都经它），SQLite 单写者模型天然够用；写协议继承 legacy `BEGIN IMMEDIATE` + locked retry jitter（考古 11 条目 16-17）与 hermes 应用层 jitter retry（`hermes_state.py:866-877`）的共同模式。跨进程场景只剩「哨兵读 vs 引擎写」，WAL 下读不阻塞写。**幂等语义在业务层而非 `_write` 层**：legacy 教训「不要把 `_write` 当业务幂等保证」（考古 11 §危险边界 5），账本/阈值表的幂等靠业务键 `ON CONFLICT` 或 read-latest 规则显式声明。

**HERMES_HOME 解析纪律**：hermes 官方声明「subprocess spawners 必须显式传播 HERMES_HOME」（`hermes-agent/hermes_constants.py:55-80`，含 profile 误配的 loud warning 机制）。本库路径由 `HERMES_HOME` 推导，因此**引擎拉起 L2 节点、部署哨兵进程时必须显式传 HERMES_HOME 环境变量**，否则子进程可能解析到默认 profile 的另一座库——这条写进 §15 部署铁律清单。

### 4.5 Run 收口 commit marker（新控制面事实，本轮复核补强）

问题：三库（domain.db / telemetry.db / evaluation.db）之间只有 trace_id / eval_run_id / asset_id / config_snapshot_id 等弱引用（§5、§3.2），不做跨库外键——这个方向本身是对的（三库生命周期、TTL、权威语义不同）。但弱引用回答不了「这个 run 最终是否完整提交、哪一库失败、失败后如何恢复、Inspector / `post_restore_audit` 该先信哪一个」——半提交状态（domain.db 决策已写但 telemetry 尾部未 flush、或反之）不可判定。

⚠️ **与三库弱引用无外键纪律的关系（先说清，防误读）**：`run_commit_marker` 不是给三库补一条外键。它是弱引用之上的一张**收口事实索引表**，自身对 telemetry.db / evaluation.db 仍只持弱引用（携 `trace_id` / `eval_run_id`，不做外键约束）。它解决的是「有没有一条记录能回答某 run 是否完整提交」，不是给三库补事务——§5 「三库经…弱关联、无跨库外键」的裁定原样不变。

裁定：**formal/advisory run 收口后必须在 domain.db 写入 `run_commit_marker`；eval-only run 的提交主家在 evaluation.db（§13 owner，本章不越界）；telemetry 侧记录 mirror span + `telemetry_commit_status`（§11 §5.5，本章不越界）**。落点理由与 §4.3 理由链同构：domain.db 已是 formal/advisory 权威产物（决策账本、阈值表等）的提交主家，`run_commit_marker` 作为「这些产物是否完整提交」的索引理应与被索引对象同库，而非放进只持过程轨迹、不持业务权威判定的 telemetry（§2.2）；eval-only run 没有 domain.db 侧权威产物，提交主家因此在 evaluation.db。

字段合同：

| 字段 | 值域 | 语义 |
|---|---|---|
| `run_id` | string | 蓝图/eval 执行的唯一 id |
| `trace_id` | string | 跨库弱关联键（同本章既有弱引用协议，非外键） |
| `account` | formal / advisory / shadow / eval | run 账别——本表专用的最小枚举，与更广的运行/输出权威语汇拆分（另案议题，本轮不处理、不预判其结论）是两件事 |
| `decision_id` | string / null | 关联决策账本行（formal/advisory 适用，eval-only 为 null） |
| `eval_run_id` | string / null | 关联评测运行（eval 适用；权威在 evaluation.db，§13 owner） |
| `domain_commit_status` | not_applicable / pending / committed / failed | 本库（domain.db）侧提交状态——本表权威列 |
| `telemetry_commit_status` | pending / flushed / tail_gap / failed | 遥测侧 flush 状态镜像；权威值在 telemetry.db（§11 §5.5），本列为跨库只读镜像，不是第二权威 |
| `eval_commit_status` | not_applicable / pending / committed / failed | 评测侧提交状态镜像；权威在 evaluation.db（§13 owner） |
| `committed_at` | datetime / null | 收口完成时刻 |
| `partial_failure_reason` | string / null | 未完整提交／提交义务未履行原因（honest None，同 §2.3 字段语义纪律） |
| `recovery_action` | none / retry_domain_commit / mark_telemetry_tail_gap / orphan_eval_record / rollback_advisory_output / manual_review_required | 恢复动作枚举 |
| `marker_schema_version` | string | schema 版本（同 §2.1 宪法第五条 always-apply 幂等 schema 纪律） |

写入方：蓝图引擎在 run 收口时写入本表（经 §4.4 单点化写入拓扑，不新增写入方角色）——挂钩 §05 run 收口协议的具体步骤（哪一步触发写入、失败重试次序）归 §05（seam，不在本章展开）。

读取方与规则：Inspector / `post_restore_audit`（§12/§15）**必须先查 commit marker，再查三库弱引用**；无 marker 的 run 不得被视为完整提交；`promotion_evidence` 不得引用 `domain_commit_status != committed` 的 formal run（该引用条件的强制校验实现归 §13，本章只锁裁定，不改 §13）。

**收口义务登记控制对象 `run_closure_obligation`（配套 marker 的待履行收口义务 durable 登记）**：marker 回答「run 是否完整提交」（缺席 = 未提交），但不回答「哪些 run 尚欠一笔权威收口、其收口 request 是什么」。为使 fail-closed 收口在受控重启后不遗忘未决 closure、并使受控重启不默认重开 fail-closed lane，域库另开控制对象 `run_closure_obligation`——定位同 §4.5 `run_commit_marker`：**控制面事实、非 §1.2 四级分账本体**，物理落 domain.db 同库不同表。它登记 standalone 收口面（`closure_context` 在场、非 W7-fenced 派发）run 的**待履行收口义务 + terminal closure request preimage**（`write_scope` / `domain_products` / 终态 status·reason），并携 `producer_incarnation_id`——登记进程 incarnation 这一**非权威来源坐标**（把「本进程健康 in-flight 义务」与「前代进程崩溃遗留的 restart-orphan 义务」机械分区）。硬边界：**非第二终态账 / 非第二 run FSM / 非 marker 替代品 / 非调度队列**——「run 是否完整提交」仍**只**由 `run_commit_marker.domain_commit_status` 回答，义务解决判定恒经 marker 存在性派生（无 cleanup 写步骤、marker 在场即义务已解决）。写入方 = 收口协调器经窄访问面（§4.4 单点化拓扑内、不新增写入方角色）；登记 / preimage / 撤销各自单事务、写读一律经窄面。收口协议侧的时序（首次派发前登记、terminal marker 前落 preimage、fail-closed lane 由 DB 健康 + 未决 durable restart-orphan 义务派生、单登记者机械强制）归 §05 §4.7。

### 4.6 维护请求控制表 `maintenance_request_v1`（refresh/supersede/rollup 请求的统一落点，本轮复核补强）

问题（回应前轮 partial-fix 剩余缺口）：§10 常驻主体的 `PrefetchComposer` 可发 `profile_refresh_request` / `cold_digest_refresh_request` 等 non-writing follow-up 给对应来源章 owner（`10-resident-agent.md` §9.2「refresh 请求非写」，Composer 只读、不写任何源表）；§19 `sidecar_drift_watcher` 旁路监听画像漂移、产 `drift_alert`、建议 supersede，但「不拥有权威存储」（`19-per-stock-cross-time-profiling.md` §7.2）。两处的权限边界（发起方只读源表、写入权仍在来源章 owner）已经清楚，但 **request 本身从未有统一落点**——无状态机、无去重键、无重试/过期/失败记录：同一 ticker 的 refresh 请求可能被 Composer 与 sidecar 各发一次、无人去重；请求发出后 owner 迟迟未处理，无从诊断是「排队中」还是「已丢」。

裁定：域库开控制表 `maintenance_request_v1`——定位同 §4.5 `run_commit_marker`：**控制面事实、非 §1.2 四级分账本体**（登记为 §1.1 承载物 #17），物理落 domain.db 同库不同表。

字段合同：

| 字段 | 值域 | 语义 |
|---|---|---|
| `request_id` | string（主键） | 请求唯一 id |
| `request_type` | profile_refresh / cold_digest_refresh / supersede / rollup | 请求类型——覆盖 §10 §9.2 `profile_refresh_request`/`cold_digest_refresh_request`、§19 §7.2 `sidecar_drift_watcher` 的 supersede 建议、及 §19 `scheduled_rollup_pipeline` 的显式 rollup 触发 |
| `target_entity` | string（ticker / entity ref） | 请求作用的标的或实体引用 |
| `origin` | composer / sidecar_drift_watcher / … | 发起方标识（开放枚举，随实际 producer/consumer 增补，本表不锁死首发集） |
| `dedup_key` | string（如 `request_type + target_entity`） | 去重键；同键在时间窗内幂等合并为一条，防重复请求风暴（同 ticker 被 Composer 与 sidecar 各发一次不应产两条待办；合并算法 no-invent，归实现期） |
| `status` | pending / processing / done / failed / expired | 状态机；owner 消费待办后回写 |
| `retry_count` | int | 已重试次数 |
| `expires_at` | datetime | 过期时点；到期未处理即转 `expired`，不静默悬挂 |
| `last_error_ref` | string / null | 失败诊断引用（honest None，同 §2.3 字段语义纪律；不吞失败） |
| `owner_章` | §18 / §19 / §17 | 消费该请求类型的来源章 owner：`cold_digest_refresh` → §18 预消化流水线；`profile_refresh`/`supersede`/`rollup` → §19 画像聚合流水线；未来若经验专表也开放请求 → §17 Distillation |

写入方：发起方（Composer §10 / `sidecar_drift_watcher` 等 §19 producer）**只写本表一行、不碰任何源表**（延续 §10 §9.2 / §19 §7.2 既有权限边界，原文不改；权限登记见 §4.4 新增行）。读取方与规则：owner（§18/§19/§17 各自流水线）消费本表待办、执行实际 refresh/supersede/rollup 后回写 `status`——这是 owner 对源表的**唯一**写入路径未变，本表只是待办队列，不代理 owner 的写权限；过期/失败**可诊断、不静默**（`expired`/`failed` 连同 `last_error_ref` 留痕，供 Inspector/用户复看，同 §2.1 宪法第三条「落库失败对用户不吞」精神的控制面版）。**本表不产生任何决策信号**——它只是维护性待办，消费方处理结果（新画像行/新 digest 行/新经验行）才是权威产物，本表行本身不进 voter 权重/confidence（同 §1.2 材料层不变量守恒）。

---

## 5. 与 §11 遥测/因果链的存储边界

§11 待答「遥测表并入 §03 还是独立 store」——本章从领域库侧给出边界裁定建议（最终归 §11 定稿）：

> **建议：遥测挂载表独立成库文件**（如同目录 `telemetry.db`），与域库分离；两库以 `trace_id` 关联。

理由：

1. **写入速率与保留策略不同构**：遥测是高基数、每次迭代/工具调用都写的流水（`11-aci-telemetry/agent-computer-interface-eval.md` §1）；域库正式账是低频权威写。混在一个文件里，遥测 churn 会持续抢域库写锁、膨胀备份体积，并把「可裁剪的过程数据」和「永久权威数据」绑进同一份保留策略。
2. **消费者不同**：遥测的第一消费者是 AOI 只读接口 / Inspector（北极星增补）；域库的第一消费者是主体与哨兵。分库让 §12 Inspector 的只读边界（骨架 §12 待答）可以按库文件粒度授予。
3. **报告偏离标注**：`11-aci-telemetry/agent-computer-interface-eval.md` §1 与 `12-inspector-agent/observer-agent-telemetry.md` 摘要均写「持久化于本地的 `state.db`（SQLite 遥测挂载表）」——报告成文时挂载点尚未裁定（骨架 §00 前提 1 的 ⚠️ 已声明）。本书裁定链：报告的「state.db」≠ hermes `state.db`（§4.3 已否决 A′），也不落域库主文件（本节理由 1-2），落独立遥测库；「本地 SQLite、禁止强制推送云端 SaaS」的本地优先承诺原样保留。

本章锁定的边界合同（域库侧义务，与 §11 双向）：

- **域库不承载高基数轨迹**——评分张量、回退流、上下文快照、每票 sidecar 一律进遥测库（状态流裁剪契约的存储面，§2.2 三层分工）；
- **域库权威行携带 `trace_id`（及产生它的 `span_id`）作为跨库关联键**——这是 §20 归因接缝的一半（§8）；
- **轻量证据 manifest 归域库、重型过程 payload 归遥测库**：`advisory_report_evidence_manifests`（#20）持有审计结论所需的 refs/hash/时间边界/replay handle，属长期 advisory 账；其引用的原始 prompt/长文本/完整 tool payload 一律在遥测库 blob/TTL 域（§11），二者以 evidence/tool-run refs 弱关联——blob 过期不损 manifest 的审计完整性（显式 blind-spot 态，§3.9），仍无跨库外键；
- **防篡改纪律在写入合同层执行**：引擎落库时原样透传上游 trace_id，业务节点/引擎不得清洗或改写（`12-inspector-agent/observer-agent-telemetry.md` §四；骨架 §01 协议桩）；
- 遥测库的 schema（OTel GenAI `gen_ai.*` 对齐）、AOI 接口形态（SQL 直查 vs API）、span 穿 CLI 进程边界的传递机制——全部归 §11，本章不越界。

**三库 triad 的第三库：评测库 `evaluation.db`（§13 owner，域库不承载评测结果）**：遥测独立成库之外，守护数据的**第三座库**是评测库——§13 双层评测的评测运行记录（`eval_runs`）、逐裁判评分张量（`judge_score_tensors`，与 §2.2 过程层的**决策**评分张量不同物：前者是 Tier-2 评测裁判打分，后者是漏斗共识投票 sidecar，二者分库互不混）、量规绑定、聚合判定、消融结果、晋升证据（`promotion_evidence`）一律落 `evaluation.db`（归 §13，§13 §3.5）。守护数据三库分工由此补齐：**`domain.db`/域库（§03，业务权威状态）· `telemetry.db`（§11，过程轨迹）· `evaluation.db`（§13，评测权威结果）**，三库经 `trace_id/eval_run_id/asset_id/config_snapshot_id` 弱关联、**无跨库外键**（§3.2「三条历史化机制弱关联、不做外键」的三库版）。域库侧的对应义务：决策账本行可携 `promotion_evidence` 引用与 eval candidate 引用（资产晋升拿证据），但**域库永不承载评分张量/量规维度分/晋升证据主记录**——评测裁定不是业务账（§1.2 分账铁律的评测域延伸：quality eval 分不当 alpha、judge score 不进 voter 权重，§13 §3.4）。

**与三库弱引用无外键纪律的关系（本轮复核补强）**：新增的 `run_commit_marker`（§4.5）不改变本节「三库经 trace_id/eval_run_id/asset_id/config_snapshot_id 弱关联、无跨库外键」的裁定——它是弱引用之上的一张收口事实索引表，本身对 telemetry.db/evaluation.db 仍只持弱引用，不新增任何跨库外键约束；它解决的是「有没有一条记录能回答某 run 是否完整提交」，不是给三库补事务。

---

## 6. L2 无状态节点的跨次状态外置协议（统一挂载点）

四级分形下 L2 = CLI headless 按次拉起的**无状态进程**（骨架 §01 分形映射；对报告「持续能力单元」语感的偏离已在骨架标注）。`00-cross-cutting/atomic-composable-architecture.md` §2 要求「层级间上下文传递不可依赖混乱的全局变量，必须通过统一的只读/只写挂载点完成」。本章给出该挂载点的协议实体：

**L2 节点对领域库零直连。** 节点的全部状态 IO 是：

```text
引擎从域库读出快照（按蓝图状态白名单裁剪、显式声明）
  → 以结构化输入交给节点（CLI 参数/输入文件）
  → 节点计算，产出结构化 response（节点不直接写 canonical ipc 输出文件，ISR s7-7C 废立）
  → 引擎在 termination/schema/boundary gate（宪法第二/三条为其 schema/边界半边）通过后，
    作为 canonical ipc 唯一写者写入互斥输出路径（ipc/{run}/... 命名空间，幂等覆写、原子写；
    gate 未过不产生 canonical ipc 产物）
  → 引擎合并进运行态，收口时统一落库
```

（termination/schema/boundary gate 与 engine-only writer 均为设计裁定、当前无活体，实现归实现期——同 §05 §3.2。）

这样设计的理由链：

1. **read⟹declared 的进程级版本**：节点能看到什么状态，白名单在蓝图 DSL 里写死——比 legacy 靠 TypedDict 过滤更强，因为快照是物理裁剪（未声明的数据根本不进子进程），「静默读到不该读的」也被杜绝；
2. **崩溃恢复白得**：互斥输出路径 + 幂等输出（hermes-fit-arc §1 已收敛的决策）意味着节点崩溃重拉不需要库端回滚——库从未见过半成品；
3. **SQLite 并发模型的成全**：节点不写库，跨进程写竞争不存在（§4.4）；
4. **跨次连续性归 L3**：深挖 hop 计数、辩论轮次等「跨节点拉起的连续状态」由解释器（L3）持有——解释器自身的运行检查点（运行/恢复/取消/超时语义归 §05 待答）在本库预留一张蓝图运行检查点表作为存储面，schema 随 §05 定稿；
5. **禁全局变量的字面落实**：节点间不共享任何进程内状态、不共享环境变量携带的业务数据，唯一合法通道是「引擎中转的显式快照/输出文件」与「引擎落库后的下次读出」。

---

## 7. 风控阈值表（§07 → §09 决策后监控回路的存储枢纽）

本库的新增职责（骨架 §03 桩），决策后监控回路的物理接点：§07 定量风控节点写入 → 本表持有 → §09 事件哨兵 O(1) 盯守 → 破位发事件 → 紧急重估。

**写侧合同（对 §07）**：

- 阈值行是**共识出口产物的附属**：每行锚定一条决策账本记录（decision_id），继承其 ticker/horizon/trace_id；
- 内容为 §07 双轨产物：SL/TP、支撑/阻力位、趋势判定，附**置信度与时效标注**（§07 待答项；本章只锁「必须有时效」这一 schema 义务）；
- **量纲纪律（no-invent）**：本章不规定任何阈值数值——SL/TP 与 S&R 全部来自 §07 的 VTA/时序检索计算（`07-funnel-back-half/risk-execution-agent-architecture.md` §二），表只存计算结果与其依据引用；`{ticker, signal, confidence, horizon}` 上游契约的字段级定稿归 §07；
- 报告偏离标注（骨架 §07 已声明）：报告原文仅「封装入最终报告」，**写入状态库是本书为决策后监控回路所作的超集扩展**——advisory 语义不变：表中阈值是「建议的风险参数」，破位触发的是重估建议，无任何执行语义。

**读侧合同（对 §09）**：

- **点查形态**：哨兵按 ticker 取「当前有效」阈值行——表结构面向读优化：ticker 上有唯一「当前有效版本」语义（新阈值写入即取代旧版，旧版本保留为历史行供审计），哨兵单索引点查即 O(1)；
- **跨进程只读**：哨兵直连库文件只读（§4.4），不经 agent 进程、不经任何 API 层——这是「哨兵与 LLM 层物理隔离」（CONTEXT.md）在存储面的成全；
- **时效语义**：过期阈值（超出 horizon/valid_until）哨兵如何处理——静默停盯、还是发「阈值过期」事件请求重估——是行为语义，归 §09 定稿（本章未决 #4）；
- **防抖参数落位**：同向冷却期与 ATR 噪声缓冲带是哨兵层机制（骨架 §09）；其中 ATR 缓冲带需要 ATR 量纲输入——该值由 §07 计算，可作为阈值行的附带字段随行下发，亦可由哨兵从行情缓存自算——归 §09 事件 payload 契约一并定（本章未决 #4）；
- **延迟预算**：哨兵读表的延迟预算（§09 待答）不在本章定数值；本章的义务是表设计不引入超出「本地 SQLite 索引点查」量级的读路径。

**盯守范围联动**：哨兵理论上只需盯「有活跃阈值行的 ticker」；组合视图（§1.1 #6）中用户申报的持仓是否自动进入盯守范围（即便无近期决策）——归 §09 与 §10 的交互设计（本章未决 #7）。

---

## 8. §20 归因接缝与封存接口字段预留

§20 待答「决策 trace 归因接缝在 §03 schema 预留哪些字段」——本章正面作答。预留原则：**只建列、不建能力**——字段从第一天写入，消费它们的系统（回测归因、执行）后置或封存。

**归因接缝字段族（决策账本行）**：

| 预留字段 | 未来消费者 | 依据 |
|---|---|---|
| `decision_id`（稳定主键） | 一切后验系统的锚点 | — |
| `trace_id` / 产生 span | §11 遥测关联、§12 Inspector 跨域归因 | `12-inspector-agent/observer-agent-telemetry.md` §四 |
| `blueprint_id` + `blueprint_version` | §16 版本治理绑定（「蓝图版本与决策账本记录的绑定粒度」§16 待答的存储面预留） | 骨架 §16 |
| `skill_version` 族 | 后置的 skill 归因（legacy 14） | 三态册 L263 |
| 输入引用（本次决策消费的 advisory 产物/深挖简报 id 列表） | §08 深挖回流追溯、归因 | §1.2 分账合同 |
| **outcome 回填族**：实际收益、相对 SPY alpha、`correct`（=相对 SPY alpha 方向）、`outcome_unavailable` 标记、回填时间 | 后置的回测/归因（§20） | 三态册 L263：14 整体后置，但「outcome 回填的 advisory 评估语义……是任何后验能力的水源」应**提前继承进数据模型**；`correct=相对 SPY 方向` 是 advisory 系统自我评估的现成语义（三态册 L248、L273） |

**逐 lane 贡献向量列**：归因接缝字段族增一列**「逐 lane 贡献向量」**——决策账本行的持久归因原子（§07「归因足」升格产物），是逐股画像聚合（§19）与后置归因回测（§20）的水源。它与 outcome 回填族同为「只建列、不建能力」：lane 级贡献第一天写入，消费它的系统后置；建议 schema 形态在 §19 §3 / §07，本表只锁「建列预留」义务、不复制 DDL（链 §19 §3）。不变量守恒：该向量是归因材料层，不进 voter 权重 / confidence，LLM 叙事永不据它获数字权威。

**归因接缝双时态 / 因果链字段族（canonical · master §20.3 委托本节落表）**：master §20.3（封存/后置边界章）只作**消费说明 + 封存接口说明、不拥有 schema**——归因接缝的双时态锚点、因果链血缘、扩展占位符三组字段的**字段级 canonical 主家在本节**，与上「归因接缝字段族」表同为「只建列、不建能力」（字段第一天预留、消费系统后置/封存）：

| 字段族 | 字段 | 语义 | 适用对象 / 消费方 |
|---|---|---|---|
| **双时态锚点** | `effective_time` / `recorded_time` | 真实世界发生 / 生效时点 · 系统落库时点——彻底消灭回测未来函数（look-ahead），对接 §17 §5.3 动态物理脱敏 | 权威决策账本行（`decision_ledger`）；§18 冷 digest 专表（承载物 #12）与 §19 逐股画像专表（承载物 #13）**只读引用**双时态锚点（§18 变更门控消费 `effective_time` 判源版本前推、§19 历史窗回放据以切断未来函数），**不改本 schema、不越权另立** |
| **因果链血缘** | `causation_trace_id` / `parent_state_hash` / `generator_context_hash` | 因果链 trace id（串联上下文、§11 遥测关联）· 上一状态快照哈希（连续演化证明）· 生成上下文结构哈希（**定义主家在 §16 §2.6**，证明「产物在什么生成上下文下产生」，非 `blueprint_struct_hash`） | 决策账本行；thesis / advisory record（如适用） |
| **扩展占位符** | `attribution_metadata_blob` | 未来归因扩展 JSON（默认 `{}`）——复活时直接注入特征权重 / 梯度日志，做到 **Zero ALTER TABLE** | 决策账本行 |

**账别**：随宿主表账别、不单独成账（§18/§19 消费面对双时态锚点属材料层只读引用，不越权改宿主 schema）。**消费面 / 解封说明**（非 schema 主家）留 master §20.3；后置 §20 的 outcome / attribution 能力激活时直接复用本族、Zero ALTER。本节承载**全归因接缝字段族的 canonical**——决策账本归因字段族（上表）与双时态 / 因果链 / 占位符字段族（本表）两组，字段级定义一律以本节为准；§17 / §18 / §19 等消费方引本节字段、不另立。

**封存接口 ×2 的存储面（骨架 §20）**：

- **交易执行封存**：本库**没有** orders/execution 表——不是「预留空表」，是不存在（空表本身就是诱饵）。封存缝的位置 = `decision_id` 稳定主键：未来若显式解封，执行记录作为**新表**外键引用账本，现有 schema 零改动。legacy 的 staged/committed orders 表（考古 11 §6）**不继承**——那是 legacy 在 advisory 边界上的试探性越界（其 thesis check 从未接牢，考古 13 条目 36），新系统不带这个诱惑进门。
- **远端部署封存**：解封时单文件 SQLite 可能需要换 client-server 引擎。缝的位置 = §4.3 的**按领域拆分的数据访问模块**——所有访问经窄访问面、不裸 SQL 散落，引擎替换的爆炸半径被限制在访问模块内。注意 ponytail 边界：这不是要建 ORM/抽象仓储层，只是「集中访问函数」这一最低限度的纪律。

---

## 9. 对 legacy 的三态判断（链考古锚点）

| legacy 对象 | 三态 | 判断明细 | 锚点 |
|---|---|---|---|
| **11 状态契约层 · 协议面**（read⟹declared、弱运行态+强边界、分级失败、JSON 三层防御、atomic write、always-apply schema、运行目录出 repo、测试隔离、contracts 不反向依赖） | **改造（协议继承、载体重写）** | 六条宪法全数继承（§2.1），且 read⟹declared 升格为显式错误、静默 strip 物理杜绝（§6） | 考古 11 条目 2-3/14-18/22-25、§精华 1-8；三态册 L81 |
| **11 · StateDB 巨型汇合库载体** | **放弃** | 单类 20+ 业务表的汇合形态不带走；按领域分表族 + 窄访问模块（§4.3）；会话/记忆/cron 持久化外围被 hermes 吸收 | 考古 11 §包袱 1；三态册 L81-82 |
| **11 · 有损 round-trip 现状** | **改造** | 「core record ≠ trace store」从暗债变显式三层分工（§2.2）：权威层承诺完整 round-trip，过程层移交遥测库 | 考古 11 条目 19、§危险边界 4；三态册 L82 |
| **11 · `atomic_write_text` / WAL+retry 写协议** | **继承（协议）** | 同目录 tmp+replace、BEGIN IMMEDIATE+jitter retry 原样继承；幂等归业务键不归 `_write` | 考古 11 条目 16-17/22、§危险边界 5-6 |
| **13 · 会话面**（Copilot 会话、上下文压缩、压缩前抢救、记忆编排） | **被底座吸收** | SessionDB/MemoryManager/`on_pre_compress` 逐项对上（§3.1 表）；不复活任何自建记忆编排抽象 | 考古 13 条目 1/9-10；三态册 L237-238；`hermes_state.py:695-785`、`agent/memory_manager.py:1-24`、`agent/memory_provider.py:220-230` |
| **13 · 投研历史语义**（三条历史化机制、Past Context 注入协议、advisory thesis 纪律、honest None、白名单裁剪摘要工具） | **改造** | 三实体分立（§3.2）；注入协议整体继承、挂载点换 hermes 接缝（§3.4）；thesis 状态机补 enforce、`entry_price_source` 入表（§3.3） | 考古 13 条目 7-8/19-24/28/30-32/38、§包袱 5/7/8；三态册 L237-238、L273 |
| **13 · order workflow thesis check、冷层透明查询愿景** | **放弃** | 前者是从未接牢的 API drift（不继承为事实门）；后者是 spec 与实物的漂移，冷层归档需求在新库随保留策略重新评估 | 考古 13 条目 13/36、§危险边界 8/10 |
| **12/14 · `skill_records` 语义过载、SKILL.md frontmatter 存运行结果** | **放弃（教训承接）** | 一表一权威语义（§1.3）；运行结果状态不进版本文件（§1.3 负面清单） | 三态册 L268-269 |
| **14 · outcome 回填语义**（PIT alpha、correct=相对 SPY 方向、outcome_unavailable） | **后置，schema 提前预留** | 回填能力后置 §20，字段族第一天建列（§8） | 三态册 L263、L273 |
| **01 · 正式写 vs advisory 分级**（persist=False 防污染） | **改造（加强）** | 「不写=隔离」升级为表级隔离，advisory 可回看且统计只读正式账（§1.2） | 考古 01 §11；三态册 L104、L185 |

新增构件（风控阈值表、三层存储分工中的遥测边界、组合申报表、**run_commit_marker 收口控制表**、**`maintenance_request_v1` 维护请求控制表**、**`advisory_replay_records` 用户复盘记录专表**）三态列「新增」，出处链 `07-funnel-back-half/risk-execution-agent-architecture.md`、`11-aci-telemetry/agent-computer-interface-eval.md`、`12-inspector-agent/observer-agent-telemetry.md`、`00-cross-cutting/atomic-composable-architecture.md`、`docs/research/_claims/valuehermes-cross-layer-contract-gap-review.md`（本轮复核补强，§3 F3）；`maintenance_request_v1`（本轮复核补强）出处链 `10-resident-agent.md` §9.2「refresh 请求非写」+ `19-per-stock-cross-time-profiling.md` §7.2 `sidecar_drift_watcher` 权限边界（两处只留发起权、从未给统一落点的缺口）；`advisory_replay_records`（本轮复核补强）出处链 `05-blueprint-engine-control-plane.md` §2.4.4 `write_scope` 二分裁定（`replay_records` 承载物原括注「待 §03 补行」）。**§14 §2.7 投资者本人建模承载**（§3.6）出处链 `14-transparency-and-judgment/31-investor-self-modeling-discipline.md`：承载① IPS 约束申报 = **改造扩展**（#6 升格）、承载② 行为诊断器官（#15 料源 + #14 派生）= **新增**、承载③ 校准 facet = **复用**（thesis 账）、承载④ 目标锚 = **后置封存**（master §20）。**证据链承载**（§3.8/§3.9，#19/#20）出处链 `00-cross-cutting/33-end-to-end-evidence-trace-and-replay-contract.md`：`source_policy_declarations` = **新增**（申报账家族扩员）、`advisory_report_evidence_manifests` = **新增**（advisory 账 append-only 索引账；条文 canonical §14 §7）——二者独立承载、不复用 #18 复盘专表。

---

## 10. hermes 机制证据索引（本章引用的真实本地路径）

本章正文引用的 hermes 断言均经以下本地源码复核（✅），唯一例外已标注：

- `hermes-agent/hermes_state.py:123` — `DEFAULT_DB_PATH = get_hermes_home() / "state.db"` ✅
- `hermes-agent/hermes_state.py:695-785` — `SCHEMA_SQL`：sessions/messages/state_meta/compression_locks 四表，证实「只存会话，非通用领域存储」✅
- `hermes-agent/hermes_state.py:787-800` — 延迟索引（legacy DB 兼容的补列模式）✅
- `hermes-agent/hermes_state.py:802-855` — messages FTS5 + trigram 触发器 ✅
- `hermes-agent/hermes_state.py:858-889` — SessionDB 写竞争自述：多 hermes 进程共享一个 state.db、WAL 写锁 convoy、应用层 15 次 jitter retry、定期 checkpoint/FTS optimize ✅（§4.2 否决 A′ 的主证据）
- `hermes-agent/hermes_state.py:341-391` — `apply_wal_with_fallback(conn, db_label=…)`：WAL→DELETE 回退现成助手（NFS/SMB/FUSE 自动降级 DELETE、每 `db_label` 去重告警一次、on-disk 已 WAL 不降级），SessionDB 与 `hermes_cli.kanban_db` 共用 ✅（§4.3 部署铁律联动：域库一行调用、不自实现）
- `hermes-agent/plugins/memory/holographic/store.py:98-140` — 插件自建独立 SQLite 范例：`__init__` 直连 `HERMES_HOME` 下独立 `.db`、`_init_db` 复用 `apply_wal_with_fallback` + `CREATE TABLE IF NOT EXISTS` 幂等 schema ✅（§4.3 方案 A 落位模板）
- `hermes-agent/hermes_state.py:556-692` — `repair_state_db_schema` 的 `writable_schema` 级修复手术 ✅（升版耦合风险证据）
- `hermes-agent/hermes_constants.py:55-80` — `get_hermes_home`：HERMES_HOME env → 平台默认；子进程必须显式传播 HERMES_HOME；profile 误配 loud warning ✅（§4.4 部署纪律）
- `hermes-agent/agent/memory_manager.py:1-24` — MemoryManager 单一集成点、仅一个外部 provider ✅
- `hermes-agent/agent/memory_provider.py:1-32,94-132,220-230,299-315` — MemoryProvider ABC：prefetch 返回格式化字符串、sync_turn 非阻塞、`on_pre_compress`、`backup_paths`（hermes backup 只走 HERMES_HOME）✅
- `hermes-agent/agent/context_compressor.py`、`agent/conversation_compression.py` — 仅确认文件存在（§3.1）；压缩面细部已由 §10 §4.2/§7.3 收口
- `hermes-agent/hermes_cli/plugins.py:135-176` — VALID_HOOKS 含 pre_llm_call：转引骨架 §01/hermes-fit-arc §2，该行段已由 §05 §11 / §10 §7.3 核对（仅影响 §3.4 通道候选 3 的可行性，不影响本章任何裁定）

---

## 11. 显式未决问题清单

1. ~~落位三选一终审~~ → **✅ 已拍板方案 A**（2026-07-02 用户评审）；自持目录命名（`valuehermes/`？）仍开放，归 §15 部署规范或实现期定。
2. **遥测库独立成文件**：本章从 §03 侧建议独立 `telemetry.db` + trace_id 关联（§5）——归 §11 定稿；遥测保留/裁剪策略、AOI 接口形态均归 §11。
3. **Past Context 注入通道**：memory provider（占用单 provider 限额）vs 只读工具 vs pre_llm_call hook（§3.4）——归 §10，与 JIT 资源规划器的能力注册表形态一并看。
4. ~~阈值表时效与防抖参数落位~~ → **✅ 已由 §09 定稿作答**（§09 §1.4）：vol_input 基线 = 随行下发 `atr_snapshot`（哨兵自算否决）；过期行为 = `risk_stale` 边沿事件（每行至多一次）+ 失效行停破位判定 + 失明窗口诚实入账。
5. **蓝图运行检查点表 schema**：解释器运行/恢复/取消/超时语义归 §05；本章只预留存储面（§6）。
6. **决策账本与阈值表的字段级 schema**：共识出口极简信号契约的字段定稿归 §07；本章锁定的是账本骨架（两信心字段、advisory sell sentinel、归因字段族、三层分工）。
7. **组合申报流与哨兵盯守范围**：申报 UX 与写确认门归 §10（§10 §8.3 承接、§10 未决 #11 联动）；盯守半边 **✅ 已由 §09 §1.2 作答**——破位盯守范围 = 有活跃阈值行的 ticker（结构性必然），申报持仓已进 Feed Handler 订阅集，无阈值持仓的异动感知归非破位事件族 producer 边界（§09 §4.5）。
8. **数据访问模块的粒度**：按 §1.1 领域分组的窄访问面如何切分、与插件内蓝图引擎的代码边界——实现期 OpenSpec 立项时定，本章只立「集中访问、禁散落裸 SQL、禁 ORM 框架」三原则（§8）。
9. **行情缓存库的物理落位细部**：寄存区独立文件 vs §04 数据质量膜自管目录——归 §04，本章只裁定「不入权威账、不参与备份一致性承诺」。
10. **备份一致性**：`hermes backup` 拷贝 HERMES_HOME 时域库若正被写入，WAL 未 checkpoint 的增量是否完整——是否需要备份前 PASSIVE checkpoint 钩子，**待实现期实测核验**（hermes backup 的文件级行为本章未读源码）。
11. **冷层/保留策略**：蓝图运行史与遥测的长期增长治理（legacy 冷层 JSONL 归档的需求是否在新库复现）——随 §11 保留策略与实现期数据量证据再议。
12. **新增承载物（#9–#11）下沉实现期的残留**：(a) 时序模式库向量索引载体选型 + 特征/嵌入版本治理（§07 未决 #4、§16 资产治理；统一合同见 §1.4 `embedding_facility_v1`）；(b) `golden_lessons` 字段级 schema、RAG 检索 top-k/相似度阈、教训 `superseded` 判定（§17 未决 #5）；(c) 习得库/留观表/经验专表的物理落位（域库同目录独立文件 vs 内联）——全归实现期 OpenSpec，本章只锁账别与接缝合同。§1.4 `embedding_facility_v1` 已收口 store/version/index/backup/sensitivity 归属，§08 §4.4 未决 #4/§19 §7/§07 §7.3/§17 Golden Lesson RAG 侧回指该统一主家属跨文件 seam（不在本章展开）。
13. **投资者建模承载（#14/#15）下沉实现期的残留**（§3.6；出处 `14-transparency-and-judgment/31-investor-self-modeling-discipline.md` §7 未决 #2-#8）：`ips_constraints` 结构化枚举 vs 富文本取舍；行为诊断专表 field-level schema + 4 偏差指标算法/阈值定标（no-invent）；成交记录导入账的受控导入面与高敏 PII 独立落位；per-user 校准 facet 的 Brier 实现与样本量门槛（§13 §3.8）；行为诊断/thesis 材料层召回复用 `MemoryProvider.prefetch` vs 自建检索的承载选型（§10 §9.4）——全归实现期，本章只锁账别、器官边界与判断权守恒。
14. **`run_commit_marker` 与 §05/§13/§15 的挂钩细节**（§4.5，本轮复核补强）：写入时机与 §05 run 收口协议具体步骤的绑定、`promotion_evidence` 引用条件（`domain_commit_status != committed` 拒绝引用）的强制校验实现、`post_restore_audit` 「先查 marker 再查弱引用」的查询顺序具体实现——归各自章节（seam），本章只锁裁定与字段合同。——已由 seam 4 作答（ISR README §5 簇 B 行 s4-4A~4H：挂钩协议语义已裁，参数与字段清单归实现期）。
15. **`maintenance_request_v1` 与 `advisory_replay_records` 下沉实现期的残留**（§4.6/§3.7，本轮复核补强）：(a) `maintenance_request_v1` 的 `dedup_key` 合并算法、`expires_at` 默认时长、`retry_count` 上限与重试退避策略——no-invent，归实现期；(b) `origin` 枚举随实际 producer/consumer 名录增补（本表不锁死首发集），登记面是否与 §09 `producer_registry` 核对/联动——归 §09（seam，不在本章展开，二者是正交机制：`producer_registry` 管事件总线准入，本表管维护请求去重，互不替代）；(c) `advisory_replay_records` 的 `replay_diagnosis` 字段级内容形态、与 §16 版本治理的绑定粒度——归实现期 OpenSpec，本章只锁账别、写入合同与 §13 评测回放的物理分表边界。
16. **证据链承载（#19/#20）下沉实现期的残留**（§3.8/§3.9）：`source_policy_declarations` 的 selector 语法与作用域覆盖/继承字段级、声明版本史的保留策略；`advisory_report_evidence_manifests` 的 claim rows 物理形态（内联 JSON 行 vs 子表）、evidence id 各 namespace 的编码细则、manifest 保留期治理——全归实现期 OpenSpec（语义合同与账别本章已锁）；作用域覆盖/继承的用户呈现归 §10 §10.4，`origin_publisher` 注册表归 §04 未决 #11。
