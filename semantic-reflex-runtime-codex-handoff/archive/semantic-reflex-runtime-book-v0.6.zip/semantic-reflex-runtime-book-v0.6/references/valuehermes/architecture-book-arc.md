# Architecture Book（大型架构设计期主计划）

**Goal:** 产出 `docs/architecture/` 全书（master book + modules + appendices），全部章节经用户评审标 ✅ 定稿；阶段完成后与用户共同规划下一步（实现期）。

**Inputs:**
- grill 决议（2026-07-02，Q1-Q4）：北极星 / 结合方式 / 成书流程 / 能力范围三态——durable records 在 `docs/CONTEXT.md`、overlay §2/§9、下列两册
- `docs/research/hermes-fit-arc/` — hermes 机制地图 + newfeature 决策链 + 轮子替换表
- `docs/research/legacy-tri-state-arc/` — 20 模块三态候选全册（含拍板结果）
- `docs/research/newfeature/*.md`（现 15 篇、以 `ls` 为准；2026-07-02 用户三批新增 8 篇已收编骨架 v2.2）与考古书（对照书）

**Decisions:**
- 北极星：agent-first 常驻投研 agent，漏斗为被调用能力；不变量 advisory-only + 本地优先（各留封存接口）；增补 ×2（2026-07-02 骨架评审）：agent-first 延伸至观测与评测（ACI/AOI/Inspector/双层评测）+ 组织原则「原子化与分形组合」（四级分形 L1–L4，扩展自 L1 逐级向上）
- 结合方式 A：混合三层发行配置，不 fork hermes（常驻主体 = gateway 原生 agent；决策漏斗 = 插件内自研确定性 blueprint 解释器；节点 CLI headless 按次拉起）
- 成书流程：骨架先行 → 簇批模块细稿 → 总书回填；每章 = 正文 + 三态判断 + hermes 证据 + 未决清单；用户评审过 = ✅，否则 draft
- 三态总表：见 legacy-tri-state-arc README（16 默认 + 4 裁定）；**18 升格融合进蓝图体系（专章 + 专门设计轮）**

**Open Questions:**
- 挖掘蓝图 + 跨域深挖的清晰架构（专章设计轮解决；用户明言现在没有）
- 跨域深挖结论自动改分析师 signal/confidence 还是只作简报（报告三点名「现在就要决定」→ 放进蓝图引擎章设计轮）
- 投研领域状态库落位：插件自建 SQLite（HERMES_HOME 下）vs memory provider vs 外部服务
- ~~新系统命名~~ → 已定 **ValueHermes**（2026-07-02 骨架评审）
- hermes 外部文档来源的配置默认值本地复核清单（hermes-fit-arc §5）
- 事件总线选型（报告建议本地 Redis；有无更轻机制/hermes 可复用件）→ §08 细稿
- 蓝图修改护栏核准流程细则（谁核准、几次、如何留审计轨迹）→ §04/§16 细稿
- 时序模式库（向量检索）落位与 §09/§10 边界 → §06 细稿
- 新报告引用的 arXiv 2025-2026 文献需逐一核实真实存在后才可进正文（A2 文献引用区）
- JIT 规划器的能力注册表与任务会话沙盒形态（hermes toolsets/skills 渐进披露够不够）→ §03 细稿

**Loop Breakdown v2:**（每批 = 一次簇批送审；2026-07-02 收编用户分两批新增的 7 篇报告后扩为 10 批，章号对应骨架 draft v2.1）
1. ✅ master book 骨架已定调（2026-07-02 用户授权 Director 终审；v1 `32c3349` → v2 `2dcd484` → v2.1 `8212934` → 核查修正 `0d332eb`）
2. ✅ 状态契约 + 领域状态库簇完成（§09 定稿 2026-07-02；三拍板项通过：落位方案 A / memory provider 降级读通道 / advisory 表级隔离）
3. ✅ 数据质量膜簇完成（§10 定稿 2026-07-02；四确认项通过：mmap 理由重构 / darwin 普通文件 / 密钥双域 / 订阅集新缝）
4. ✅ 蓝图引擎 + 控制面 + 漏斗前半完成（§04/§05 定稿 2026-07-02；Safe Point 两档 / advisory 恢复三族 / 事实层跑一次中间案 / 先启 B 再挂 A / 层级裁剪 A-B 变体）
5. ✅ 漏斗后半 + 共识 + 定量风控完成（§06 定稿 2026-07-02；fast-path 正名 / PM 止损降格移交 / 风险叙事单轮 / 习得库第四账别待批 9 回填 §09）
6. ✅ 挖掘蓝图 + 跨域深挖专章完成（§07 定稿 2026-07-03；Assimilation 只缩不增 / Tier-U 锁 advisory / 检索走膜）
7. ✅ 事件触发与唤醒层完成（§08 定稿 2026-07-03；UDS 基线 / shm_ref 修正 / 诚实失明窗口）
8. ✅ 常驻主体完成（§03 定稿 2026-07-03；SOUL.md / JIT 双墙 / §10.3 按 UI 决令改写为 CLI Markdown/Mermaid）
9. ✅ 守护与横切簇完成（§11–16 定稿 2026-07-03；零 OTel / spool 间接写 / 晋升验收单模板 / checksum 基线 / 结构哈希绑定）
10. 收束（2026-07-03 用户五决令后扩容）：**10a** 文献伪造链接物理清扫（全 newfeature 目录）；**10b** §18《策略生命周期与演化》新章（方向一 A 分层升格 / 方向二 B 新章）；**10c** 附录 A1–A4（A4 全局统筹矩阵新增）+ §01/§02/§17 回填 + §09 经验专表修订（Legacy 13 兜底）+ A1 写死 Legacy 12→§03 吸收 + 骨架缝位修正（§03 报两处）+ 总书收束 + plan 归档

**Validation Line:**
- 架构期验证 = 证据纪律（overlay §3）：每断言可溯源（考古锚点 / newfeature 报告 / hermes 真实路径）；外部文档来源的 hermes 事实必须本地源码复核后才可写进正文；愿景与事实分离标注
- 每簇送审前 Director 自查 + 可选 Validation 证据审计

**Exit / Archive Rule:**
- 全章 ✅ → 本 plan 移至 `docs/plans/archive/2026-MM-DD-architecture-book-arc.md`；overlay §2 回填章节索引；MEMORY 记教训索引；Ops 收口 commit；**不自动开实现期**——与用户共同规划下一步。
