#!/usr/bin/env python3
"""Build authored paired-world diagnostics; destination must not exist."""
from pathlib import Path
import argparse
import json
from discovery_lab import build_diagnostics


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    try:
        result = build_diagnostics(args.out)
    except (ValueError, OSError) as error:
        parser.exit(2, f'diagnostic refused: {error}\n')
    print(json.dumps({k: result[k] for k in ('evidence_kind', 'families', 'pairs', 'worlds',
                                           'candidate_world_records', 'model_calls')}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
