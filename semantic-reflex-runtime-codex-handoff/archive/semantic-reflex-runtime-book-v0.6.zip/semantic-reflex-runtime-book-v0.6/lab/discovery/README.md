# 需求发现反例实验室｜v0.6

这里是**有限候选和手工证据位置的诊断器**，不是一个 agent、实际 selector、通用 repair benchmark 或生产工具服务。

## 使用

在资料包根目录运行：

```bash
python lab/discovery/run_checks.py
python lab/discovery/run_diagnostics.py --out /tmp/srr-v06-discovery-new
```

Python 3.10+ 标准库即可；输出目录必须不存在。`discovery_lab.py` 包含四个模板、来源投影、受限读取方法、两份固定候选及显式预期检查。它只执行模块内写定的可信候选，不接收外部 Python。

## 已保存的内容

[diagnostics/REPORT.md](diagnostics/REPORT.md) 为可读记录，[report.json](diagnostics/report.json) 含全部 13 对；每个世界的 `agent/input.json` 是初始导出，`server` 存完整源、selector 输入、检查预期与四条脚本观察记录。

32 项 unittest 方法检查相同投影、不同验收集合、捕获外证据、Required Reads、无关变化、导出 allowlist、读取范围、非覆盖与复现。158 份诊断文件在第二次同输入运行中逐字节相同。测试中循环和控制并不代表独立统计样本。

## 关键限制

本地映射不是实时鉴权；独立文件夹不是安全边界。真正运行 agent 时只能挂接收方导出与允许的工具，不能把整个资料包作为工作目录。`left/right` 和配对名只给实验驱动器，不给模型。

公开视图使用会话内别名，不沿用 v0.5 显示源 hash 的 wire。比较是在这个诊断投影上的精确相同，不能外推为生产字节碰撞或所有可观察历史相同。

每个世界两份有限实现的通过集合不覆盖任意真实修复。脚本知道 `docs/contract.md` 路径，因此仓库读取只证明资源可访问，不是自然需求识别。所有反例已公开，不能算留出任务；同一作者的显式预期不是外部独立 oracle。

完整实验解释见 [E3 诊断](../../docs/experiments/E3-discovery-counterexamples.md)，设计争点见 [第六轮审查](../../docs/research/2026-09-18-offline-bull-bear-round-6.md)。真实宿主、模型和任务结果仍为空。
