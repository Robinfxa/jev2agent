# v0.6：需求发现的有限反例记录

> 手工构造，实际执行固定候选与读取探针。没有调用模型，不报告自然需求发现或任务总体成功率。

| 配对 | 首次视图相同 | 完整捕获对 selector 相同 | 目录后仍相同 | 取全快照后仍相同 | 读取仓库契约后仍相同 | 验收集合不相交 |
|---|---|---|---|---|---|---|
| deadline--deferred | 是 | 否 | 是 | 否 | 否 | 是 |
| deadline--outside_snapshot | 是 | 是 | 是 | 是 | 否 | 是 |
| deadline--protected | 否 | 否 | 否 | 否 | 否 | 是 |
| empty_name--deferred | 是 | 否 | 是 | 否 | 否 | 是 |
| empty_name--outside_snapshot | 是 | 是 | 是 | 是 | 否 | 是 |
| empty_name--protected | 否 | 否 | 否 | 否 | 否 | 是 |
| duplicate_key--deferred | 是 | 否 | 是 | 否 | 否 | 是 |
| duplicate_key--outside_snapshot | 是 | 是 | 是 | 是 | 否 | 是 |
| duplicate_key--protected | 否 | 否 | 否 | 否 | 否 | 是 |
| unique_order--deferred | 是 | 否 | 是 | 否 | 否 | 是 |
| unique_order--outside_snapshot | 是 | 是 | 是 | 是 | 否 | 是 |
| unique_order--protected | 否 | 否 | 否 | 否 | 否 | 是 |
| deadline--irrelevant_difference | 是 | 否 | 是 | 否 | 否 | 否 |

## 口径

4 个手写行为族，12 个关键证据位置控制＋1 个无关内容变化控制，共 13 对／26 个构造世界。
每个世界检查两份固定候选，共 52 份不同的世界×候选记录；每份包含 2 个公共检查与 1 个区分检查。构建与自检会重复调用函数，52 不是所有调用总次数，更不是 52 次 agent 修复。

“目录后相同”等字段比较的是包含首次视图的完整脚本观察历史，而非只比较最后一个响应。
8 对关键证据未出现在首次视图的输入，公共输入逐字节相同，固定候选的通过集合不相交。只提交同一个固定候选时每对至多通过其中一个世界；这不是实际模型 50% 准确率。
deferred 控制下 selector 可见的完整捕获不同，允许真正的选择器利用信息；outside_snapshot 控制下捕获也相同，需新的仓库读取。
protected 控制首次就不同，不能套用相同观察的限制。irrelevant_difference 控制验收集合相同，不能把任何隐文差异都判为危险遗漏。

## 隔离与复现

每个世界的 agent/input.json 是唯一初始可导出文件；server 中保存来源、selector 输入、验收预期与探针记录。实际实验不得把整个资料包或包含配对身份的路径提供给 agent。
这里只实现 allowlist 导出与读接口，不验证宿主沙箱、挂载或真实模型请求；server 标签没有被称作独立第三方 oracle。

所有检查输入均已随本书公开，只能用作开发回归。测试其自然需求行为需重新建立未公开、独立审核的任务集。

主合同：[E3 需求诊断](../../../docs/experiments/E3-discovery-counterexamples.md)。
