"""Run the finite diagnostic/export checks and persist actual output."""
from pathlib import Path
import io
import json
import platform
import unittest

root = Path(__file__).resolve().parent
suite = unittest.defaultTestLoader.discover(str(root), pattern='test_*.py')
stream = io.StringIO()
result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
(root/'check-results.txt').write_text(stream.getvalue(), encoding='utf-8')
report = {
    'kind': 'finite_discovery_counterexample_and_export_checks',
    'python': platform.python_version(), 'tests_run': result.testsRun,
    'failures': len(result.failures), 'errors': len(result.errors), 'successful': result.wasSuccessful(),
    'not_tested': ['agent_demand_discovery', 'semantic_selector', 'real_host', 'real_sandbox',
                   'population_performance', 'billing', 'tokenizer', 'cache'],
}
(root/'check-results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
print(stream.getvalue()); print(json.dumps(report, indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
