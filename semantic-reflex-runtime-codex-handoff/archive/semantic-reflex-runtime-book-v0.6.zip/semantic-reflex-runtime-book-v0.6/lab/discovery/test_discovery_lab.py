"""Regression checks on finite counterexamples, not tests of model ability."""
from pathlib import Path
import copy
import json
import tempfile
import unittest

from discovery_lab import (FAMILIES, OPERATIONS, PROBES, World, audit_pair,
                           build_diagnostics, canonical, export_public, paired_worlds, transcript)


class DiscoveryContracts(unittest.TestCase):
    def test_counterexample_inventory(self):
        pairs = paired_worlds()
        self.assertEqual(len(pairs), 13)
        self.assertEqual(len({key for key, _, _ in pairs}), 13)
        self.assertEqual(len(FAMILIES), 4)

    def test_all_contracts_are_equal_length(self):
        for _, left, right in paired_worlds():
            self.assertEqual(len(left.repository()['docs/contract.md'].encode()), 256)
            self.assertEqual(len(right.repository()['docs/contract.md'].encode()), 256)

    def test_deferred_public_inputs_identical(self):
        for f in FAMILIES:
            a, b = World(f.name, 'deferred', 0), World(f.name, 'deferred', 1)
            self.assertEqual(canonical(a.public_input()), canonical(b.public_input()))

    def test_outside_public_inputs_identical(self):
        for f in FAMILIES:
            a, b = World(f.name, 'outside_snapshot', 0), World(f.name, 'outside_snapshot', 1)
            self.assertEqual(canonical(a.public_input()), canonical(b.public_input()))

    def test_protected_public_inputs_differ(self):
        for f in FAMILIES:
            a, b = World(f.name, 'protected', 0), World(f.name, 'protected', 1)
            self.assertNotEqual(canonical(a.public_input()), canonical(b.public_input()))

    def test_protected_contract_is_kept(self):
        for f in FAMILIES:
            w = World(f.name, 'protected', 0)
            kept = {b['path'] for b in w.public_input()['initial_response']['included']}
            self.assertIn('docs/contract.md', kept)
            self.assertNotIn('docs/contract.md', {b['path'] for b in w.deferred()})

    def test_deferred_contract_in_capture_not_kept(self):
        w = World('deadline', 'deferred', 0)
        self.assertIn('docs/contract.md', {b['path'] for b in w.snapshot_blocks()})
        self.assertIn('docs/contract.md', {b['path'] for b in w.deferred()})

    def test_outside_contract_not_in_capture(self):
        w = World('deadline', 'outside_snapshot', 0)
        self.assertNotIn('docs/contract.md', {b['path'] for b in w.snapshot_blocks()})
        self.assertIn('docs/contract.md', w.repository())

    def test_directory_metadata_cannot_separate_unprotected_pairs(self):
        for _, a, b in paired_worlds():
            if a.placement != 'protected':
                self.assertEqual(canonical(transcript(a, PROBES['directory_only'])),
                                 canonical(transcript(b, PROBES['directory_only'])))

    def test_full_snapshot_separates_deferred_pair(self):
        for f in FAMILIES:
            a, b = World(f.name, 'deferred', 0), World(f.name, 'deferred', 1)
            self.assertNotEqual(canonical(transcript(a, PROBES['full_snapshot'])),
                                canonical(transcript(b, PROBES['full_snapshot'])))

    def test_full_snapshot_does_not_separate_search_miss(self):
        for f in FAMILIES:
            a, b = World(f.name, 'outside_snapshot', 0), World(f.name, 'outside_snapshot', 1)
            self.assertEqual(canonical(transcript(a, PROBES['full_snapshot'])),
                             canonical(transcript(b, PROBES['full_snapshot'])))

    def test_repository_read_separates_all_decisive_pairs(self):
        for _, a, b in paired_worlds():
            if not a.neutral:
                self.assertNotEqual(canonical(transcript(a, PROBES['repository_contract'])),
                                    canonical(transcript(b, PROBES['repository_contract'])))

    def test_selector_can_see_deferred_difference(self):
        for f in FAMILIES:
            a, b = World(f.name, 'deferred', 0), World(f.name, 'deferred', 1)
            self.assertNotEqual(canonical(a.selector_input()), canonical(b.selector_input()))

    def test_selector_cannot_see_uncaptured_difference(self):
        for f in FAMILIES:
            a, b = World(f.name, 'outside_snapshot', 0), World(f.name, 'outside_snapshot', 1)
            self.assertEqual(canonical(a.selector_input()), canonical(b.selector_input()))

    def test_fixed_candidates_both_pass_public_checks(self):
        for _, a, b in paired_worlds():
            for w in (a, b):
                for cid in ('candidate_0', 'candidate_1'):
                    checks = w.evaluate(cid)['checks']
                    self.assertTrue(all(c['pass'] for c in checks if c['kind'] == 'public'))

    def test_decisive_checks_separate_accepted_sets(self):
        for key, a, b in paired_worlds():
            r = audit_pair(key, a, b)
            if not a.neutral:
                self.assertEqual(r['accepted_candidate_sets'], [['candidate_0'], ['candidate_1']])
                self.assertTrue(r['accepted_sets_disjoint'])

    def test_neutral_difference_does_not_change_acceptance(self):
        key, a, b = paired_worlds()[-1]
        r = audit_pair(key, a, b)
        self.assertFalse(r['accepted_sets_disjoint'])
        self.assertEqual(r['accepted_candidate_sets'], [['candidate_0'], ['candidate_0']])
        self.assertNotEqual(canonical(a.snapshot_blocks()), canonical(b.snapshot_blocks()))

    def test_same_answer_finite_ceiling_only_when_input_same(self):
        for key, a, b in paired_worlds():
            r = audit_pair(key, a, b)
            expected = 2 if a.neutral else (None if a.placement == 'protected' else 1)
            self.assertEqual(r['same_final_candidate_success_ceiling'], expected)

    def test_unknown_candidate_rejected(self):
        with self.assertRaises(ValueError):
            World('deadline', 'deferred', 0).evaluate('exec arbitrary code')

    def test_invalid_world_parameters_rejected(self):
        for args in [('unknown', 'deferred', 0), ('deadline', 'unknown', 0),
                     ('deadline', 'deferred', 9), ('deadline', 'deferred', True)]:
            with self.assertRaises(ValueError):
                World(*args)

    def test_invalid_read_scope_rejected(self):
        w = World('deadline', 'deferred', 0)
        for operation, args in [('delete', {}), ('list_repo', {'variant': 0}),
                                ('read_repo', {'path': '../server/definition.json'}),
                                ('read_repo', {'path': '/etc/passwd'}),
                                ('read_repo', {}), ('recall_block', {'block_id': 'b999'}),
                                ('recall_block', {'block_id': []})]:
            with self.assertRaises(ValueError):
                w.read(operation, **args)

    def test_recall_exact_original_bytes(self):
        w = World('empty_name', 'deferred', 1)
        for b in w.snapshot_blocks():
            self.assertEqual(w.read('recall_block', block_id=b['block_id'])['block'], b)

    def test_repository_read_is_separate_operation(self):
        w = World('deadline', 'outside_snapshot', 0)
        full = w.read('recall_snapshot')
        repo = w.read('read_repo', path='docs/contract.md')
        self.assertNotIn(repo['path'], {b['path'] for b in full['blocks']})

    def test_reads_do_not_mutate_original_partition(self):
        w = World('deadline', 'deferred', 0)
        initial = canonical(w.public_input())
        d = canonical(w.deferred())
        for req in PROBES['repository_contract'] + PROBES['full_snapshot']:
            w.read(req['operation'], **req['arguments'])
        self.assertEqual(initial, canonical(w.public_input()))
        self.assertEqual(d, canonical(w.deferred()))

    def test_public_exports_only_allowlisted_initial_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'agent'
            export_public(World('deadline', 'deferred', 0), path)
            self.assertEqual(sorted(p.name for p in path.iterdir()), ['input.json'])
            data = json.loads((path / 'input.json').read_text())
            self.assertEqual(set(data), {'schema', 'task', 'candidate_menu', 'public_examples',
                                        'initial_response', 'read_capabilities'})
            serialized = canonical(data).decode()
            for key in ['"variant"', '"accepted"', '"decisive_expected"', '"pair_id"']:
                self.assertNotIn(key, serialized)

    def test_export_refuses_existing_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileExistsError):
                export_public(World('deadline', 'deferred', 0), Path(tmp))

    def test_malformed_trace_request_rejected(self):
        w = World('deadline', 'deferred', 0)
        with self.assertRaises(ValueError):
            transcript(w, [{'operation': 'list_repo', 'arguments': {}, 'answer': 'candidate_0'}])

    def test_trace_copies_requests(self):
        w = World('deadline', 'deferred', 0)
        requests = copy.deepcopy(PROBES['full_snapshot'])
        t = transcript(w, requests)
        requests[0]['operation'] = 'list_repo'
        self.assertEqual(t[1]['request']['operation'], 'recall_snapshot')

    def test_report_explicitly_avoids_model_and_cost_claims(self):
        with tempfile.TemporaryDirectory() as tmp:
            r = build_diagnostics(Path(tmp) / 'out')
            self.assertEqual(r['model_calls'], 0)
            for key in ['host_integration', 'natural_demand_discovery', 'synthetic_task_success_rate',
                        'production_success_rate', 'token_count', 'cost']:
                self.assertIsNone(r[key])
            self.assertEqual(r['candidate_world_records'], 52)

    def test_public_and_private_outputs_differ_only_as_expected(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / 'out'; build_diagnostics(out)
            root = out / 'pairs/deadline--deferred'
            self.assertEqual((root / 'left/agent/input.json').read_bytes(),
                             (root / 'right/agent/input.json').read_bytes())
            self.assertNotEqual((root / 'left/server/definition.json').read_bytes(),
                                (root / 'right/server/definition.json').read_bytes())

    def test_diagnostic_output_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileExistsError):
                build_diagnostics(Path(tmp))

    def test_diagnostics_repeat_deterministically(self):
        with tempfile.TemporaryDirectory() as tmp:
            a, b = Path(tmp) / 'a', Path(tmp) / 'b'
            build_diagnostics(a); build_diagnostics(b)
            af = {p.relative_to(a).as_posix(): p.read_bytes() for p in a.rglob('*') if p.is_file()}
            bf = {p.relative_to(b).as_posix(): p.read_bytes() for p in b.rglob('*') if p.is_file()}
            self.assertEqual(af, bf)


if __name__ == '__main__':
    unittest.main()
