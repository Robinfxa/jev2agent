"""Finite evidence-discovery counterexamples; no agent or external model.

All source snippets and candidate implementations are authored trusted fixtures.
The evaluator executes only candidate text from the checked-in family definitions,
not supplied code. Export separation is a data contract, not an OS security boundary.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import copy
import json
from pathlib import Path
from typing import Any

VERSION = 'discovery-fixture-0.6'
OPERATIONS = ('list_deferred', 'recall_block', 'recall_snapshot', 'list_repo', 'read_repo')
BLOCK_IDS = ('b0', 'b1', 'b2')


def canonical(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')


def digest(raw: bytes) -> str:
    return sha256(raw).hexdigest()


def padded_contract(text: str) -> str:
    raw = (text + '\n').encode('utf-8')
    if len(raw) > 256:
        raise ValueError('fixture contract too long')
    return (raw + b' ' * (256 - len(raw))).decode('utf-8')


@dataclass(frozen=True)
class Family:
    name: str
    task: str
    stub: str
    candidates: tuple[str, str]
    contracts: tuple[str, str]
    public_probes: tuple[tuple[Any, ...], ...]
    decisive_probes: tuple[tuple[Any, ...], ...]
    public_expected: tuple[Any, ...]
    decisive_expected: tuple[tuple[Any, ...], tuple[Any, ...]]


FAMILIES = (
    Family(
        'deadline', '完成 app.py 的 decide(now, deadline)，遵循仓库既有边界契约；不改契约。',
        'def decide(now, deadline):\n    raise NotImplementedError\n',
        ('def decide(now, deadline):\n    return now > deadline\n',
         'def decide(now, deadline):\n    return now >= deadline\n'),
        ('At exactly the deadline, decide must return False. Otherwise compare times normally.',
         'At exactly the deadline, decide must return True. Otherwise compare times normally.'),
        ((9, 10), (11, 10)), ((10, 10),),
        (False, True), ((False,), (True,))),
    Family(
        'empty_name', '完成 app.py 的 decide(value, fallback)，遵循仓库既有空值契约；不改契约。',
        'def decide(value, fallback):\n    raise NotImplementedError\n',
        ('def decide(value, fallback):\n    return fallback if value is None else value\n',
         'def decide(value, fallback):\n    return fallback if not value else value\n'),
        ('None uses fallback. An empty string is an explicit value and must be preserved.',
         'None uses fallback. An empty string is absent and must also use fallback.'),
        ((None, 'Guest'), ('Ada', 'Guest')), (('', 'Guest'),),
        ('Guest', 'Ada'), (('',), ('Guest',))),
    Family(
        'duplicate_key', '完成 app.py 的 decide(rows)，把键值行整理成字典并遵循仓库重复键契约；不改契约。',
        'def decide(rows):\n    raise NotImplementedError\n',
        ('def decide(rows):\n    out = {}\n    for key, value in rows:\n        out.setdefault(key, value)\n    return out\n',
         'def decide(rows):\n    out = {}\n    for key, value in rows:\n        out[key] = value\n    return out\n'),
        ('When a key appears repeatedly, preserve the first value supplied for that key.',
         'When a key appears repeatedly, preserve the final value supplied for that key.'),
        (([['x', 1], ['y', 2]],), ([],)), (([['x', 1], ['x', 2]],),),
        ({'x': 1, 'y': 2}, {}), (({'x': 1},), ({'x': 2},))),
    Family(
        'unique_order', '完成 app.py 的 decide(values)，输出去重序列并遵循仓库排序契约；不改契约。',
        'def decide(values):\n    raise NotImplementedError\n',
        ('def decide(values):\n    return list(dict.fromkeys(values))\n',
         'def decide(values):\n    return sorted(set(values))\n'),
        ('Remove duplicate values, retaining the order of their first occurrence.',
         'Remove duplicate values, sorting the remaining values in ascending order.'),
        ((['a', 'b', 'b'],), ([],)), ((['b', 'a', 'b'],),),
        (['a', 'b'], []), ((['b', 'a'],), (['a', 'b'],))),
)
BY_NAME = {family.name: family for family in FAMILIES}


@dataclass(frozen=True)
class World:
    family: str
    placement: str
    variant: int
    neutral: bool = False

    def __post_init__(self) -> None:
        if self.family not in BY_NAME:
            raise ValueError('unknown fixture family')
        if self.placement not in ('deferred', 'outside_snapshot', 'protected'):
            raise ValueError('unknown placement')
        if type(self.variant) is not int or self.variant not in (0, 1):
            raise ValueError('variant must be 0 or 1')
        if type(self.neutral) is not bool:
            raise ValueError('neutral must be bool')

    @property
    def family_definition(self) -> Family:
        return BY_NAME[self.family]

    def repository(self) -> dict[str, str]:
        f = self.family_definition
        rule_variant = 0 if self.neutral else self.variant
        contract = f.contracts[rule_variant]
        if self.neutral:
            contract += '\nEditorial note: ' + ('amber' if self.variant == 0 else 'cobalt') + '.'
        return {
            'app.py': f.stub,
            'docs/contract.md': padded_contract(contract),
            'docs/notes.md': padded_contract('This note describes the package layout, not its edge-case contract.'),
        }

    def snapshot_blocks(self) -> list[dict[str, str]]:
        repo = self.repository()
        paths = ['app.py', 'docs/notes.md'] if self.placement == 'outside_snapshot' else list(repo)
        return [{'block_id': f'b{i}', 'path': path, 'text': repo[path]} for i, path in enumerate(paths)]

    def kept_ids(self) -> list[str]:
        return [b['block_id'] for b in self.snapshot_blocks()
                if b['path'] == 'app.py' or (self.placement == 'protected' and b['path'] == 'docs/contract.md')]

    def deferred(self) -> list[dict[str, str]]:
        kept = set(self.kept_ids())
        return [b for b in self.snapshot_blocks() if b['block_id'] not in kept]

    def public_input(self) -> dict[str, Any]:
        f = self.family_definition
        task = f.task
        if self.placement == 'protected':
            task += '\nRequired Reads: docs/contract.md；该内容已在 included 中，不可延后。'
        blocks = self.snapshot_blocks()
        kept = set(self.kept_ids())
        # Session-local aliases deliberately exclude content hashes and evaluator IDs.
        # This diagnostic projection is NOT the frozen v0.5 wire format.
        return {
            'schema': VERSION,
            'task': task,
            'candidate_menu': [
                {'candidate_id': 'candidate_0', 'app_py': f.candidates[0]},
                {'candidate_id': 'candidate_1', 'app_py': f.candidates[1]},
            ],
            'public_examples': [
                {'args': list(args), 'result': expected}
                for args, expected in zip(f.public_probes, f.public_expected)
            ],
            'initial_response': {
                'source_alias': 'source-0', 'view_alias': 'view-0',
                'scope': 'hand-authored capture; not a live search or entire repository',
                'presentation_kind': 'selected_snapshot',
                'included': [b for b in blocks if b['block_id'] in kept],
                'deferred_count': len(self.deferred()),
                'declared_capture_complete': True,
                'task_sufficiency': 'not_assessed',
            },
            'read_capabilities': {
                'list_deferred': 'List original D of this view; metadata only.',
                'recall_block': 'Read a block in this saved snapshot by block_id.',
                'recall_snapshot': 'Read all captured blocks; not the whole repository.',
                'list_repo': 'List authorized fixture repository paths; new resource discovery.',
                'read_repo': 'Read one authorized repository path; not a snapshot recall.',
            },
        }

    def selector_input(self) -> dict[str, Any]:
        public = self.public_input()
        return {
            'task': public['task'],
            'public_examples': public['public_examples'],
            'candidates': self.snapshot_blocks(),
            'hard_block_ids': self.kept_ids() if self.placement == 'protected' else ['b0'],
        }

    def read(self, operation: str, **args: Any) -> dict[str, Any]:
        """Fixture-only allowlisted reads; not an authenticated runtime adapter."""
        if operation not in OPERATIONS:
            raise ValueError('unknown operation')
        required = {'recall_block': {'block_id'}, 'read_repo': {'path'}}.get(operation, set())
        if set(args) != required:
            raise ValueError('operation arguments must exactly match its scope')
        if operation == 'list_deferred':
            return {'entries': [{'block_id': b['block_id'], 'path': b['path'],
                                 'utf8_bytes': len(b['text'].encode('utf-8'))}
                                for b in self.deferred()]}
        if operation == 'recall_block':
            key = args['block_id']
            if not isinstance(key, str):
                raise ValueError('block_id must be a string')
            for b in self.snapshot_blocks():
                if b['block_id'] == key:
                    return {'block': b}
            raise ValueError('unknown snapshot block')
        if operation == 'recall_snapshot':
            return {'source_alias': 'source-0', 'blocks': self.snapshot_blocks()}
        repo = self.repository()
        if operation == 'list_repo':
            return {'entries': [{'path': p, 'utf8_bytes': len(v.encode('utf-8'))}
                                for p, v in sorted(repo.items())]}
        path = args['path']
        if not isinstance(path, str) or path not in repo:
            raise ValueError('unknown or out-of-scope repository path')
        return {'path': path, 'text': repo[path]}

    def evaluate(self, candidate_id: str) -> dict[str, Any]:
        """Finite trusted candidates with independent explicit expected values."""
        if candidate_id not in ('candidate_0', 'candidate_1'):
            raise ValueError('not an allowed candidate; arbitrary code is not accepted')
        family = self.family_definition
        index = int(candidate_id[-1])
        namespace: dict[str, Any] = {}
        # Code comes ONLY from this checked-in module's trusted literal definitions.
        exec(compile(family.candidates[index], '<trusted-fixture-candidate>', 'exec'), namespace)
        decide = namespace['decide']
        rule_variant = 0 if self.neutral else self.variant
        checks = []
        for kind, probes, expects in (
            ('public', family.public_probes, family.public_expected),
            ('decisive', family.decisive_probes, family.decisive_expected[rule_variant]),
        ):
            for args, expected in zip(probes, expects):
                try:
                    observed = decide(*copy.deepcopy(args))
                    # Avoid treating True and 1 as equivalent result types.
                    ok = type(observed) is type(expected) and observed == expected
                    error = None
                except Exception as exc:
                    observed, ok, error = None, False, type(exc).__name__
                checks.append({'kind': kind, 'args': list(args), 'expected': expected,
                               'observed': observed, 'pass': ok, 'error': error})
        return {'candidate_id': candidate_id, 'accepted': all(c['pass'] for c in checks), 'checks': checks}

    def private_definition(self) -> dict[str, Any]:
        return {'family': self.family, 'placement': self.placement, 'variant': self.variant,
                'neutral': self.neutral, 'repository': self.repository(),
                'snapshot_blocks': self.snapshot_blocks(),
                'selector_input': self.selector_input(),
                'evaluation': [self.evaluate('candidate_0'), self.evaluate('candidate_1')]}


def paired_worlds() -> list[tuple[str, World, World]]:
    pairs = []
    for f in FAMILIES:
        for placement in ('deferred', 'outside_snapshot', 'protected'):
            pair_id = f'{f.name}--{placement}'
            pairs.append((pair_id, World(f.name, placement, 0), World(f.name, placement, 1)))
    pairs.append(('deadline--irrelevant_difference',
                  World('deadline', 'deferred', 0, True), World('deadline', 'deferred', 1, True)))
    return pairs


def transcript(world: World, requests: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = [{'initial': world.public_input()}]
    for req in requests:
        if set(req) != {'operation', 'arguments'} or not isinstance(req['arguments'], dict):
            raise ValueError('malformed scripted request')
        response = world.read(req['operation'], **req['arguments'])
        result.append({'request': copy.deepcopy(req), 'response': response})
    return result


PROBES = {
    'initial_only': [],
    'directory_only': [{'operation': 'list_deferred', 'arguments': {}}],
    'full_snapshot': [{'operation': 'recall_snapshot', 'arguments': {}}],
    'repository_contract': [{'operation': 'read_repo', 'arguments': {'path': 'docs/contract.md'}}],
}


def audit_pair(pair_id: str, left: World, right: World) -> dict[str, Any]:
    accepts = []
    for world in (left, right):
        accepts.append([cid for cid in ('candidate_0', 'candidate_1') if world.evaluate(cid)['accepted']])
    public_same = canonical(left.public_input()) == canonical(right.public_input())
    row: dict[str, Any] = {
        'pair_id': pair_id, 'family': left.family, 'placement': left.placement,
        'neutral_control': left.neutral, 'world_count': 2,
        'public_initial_equal': public_same,
        'selector_capture_equal': canonical(left.selector_input()) == canonical(right.selector_input()),
        'accepted_candidate_sets': accepts,
        'accepted_sets_disjoint': set(accepts[0]).isdisjoint(accepts[1]),
        'probe_transcript_equal': {},
        'same_final_candidate_success_ceiling': None,
        'model_calls': 0, 'natural_demand_outcome': None,
        'task_population_accuracy': None, 'actual_billing': None,
    }
    if public_same:
        row['same_final_candidate_success_ceiling'] = max(sum(cid in s for s in accepts)
                                                          for cid in ('candidate_0', 'candidate_1'))
    for name, requests in PROBES.items():
        row['probe_transcript_equal'][name] = (
            canonical(transcript(left, requests)) == canonical(transcript(right, requests)))
    return row


def export_public(world: World, destination: Path) -> dict[str, Any]:
    """Only public input is exported. Do not expose the parent diagnostics tree to an agent."""
    if destination.exists():
        raise FileExistsError('refusing to overwrite agent export')
    destination.mkdir(parents=True)
    raw = canonical(world.public_input())
    target = destination / 'input.json'
    target.write_bytes(raw)
    return {'file': 'input.json', 'bytes': len(raw), 'sha256': digest(raw)}


def build_diagnostics(destination: Path) -> dict[str, Any]:
    if destination.exists():
        raise FileExistsError('refusing to overwrite diagnostics')
    destination.mkdir(parents=True)
    rows = []
    for pair_id, left, right in paired_worlds():
        pair_dir = destination / 'pairs' / pair_id
        for side, world in (('left', left), ('right', right)):
            root = pair_dir / side
            export_public(world, root / 'agent')
            server = root / 'server'; server.mkdir()
            (server / 'definition.json').write_bytes(canonical(world.private_definition()))
            for name, requests in PROBES.items():
                trace = transcript(world, requests)
                (server / f'{name}.json').write_bytes(canonical(trace))
        row = audit_pair(pair_id, left, right)
        rows.append(row)
    report = {
        'schema': VERSION, 'evidence_kind': 'authored_finite_counterexamples',
        'families': len(FAMILIES), 'pairs': len(rows), 'worlds': len(rows) * 2,
        'candidate_world_records': len(rows) * 4,
        'probe_definitions': PROBES,
        'rows': rows,
        'model_calls': 0, 'host_integration': None, 'natural_demand_discovery': None,
        'synthetic_task_success_rate': None, 'production_success_rate': None,
        'token_count': None, 'cost': None,
        'limits': [
            'Four authored families with dependent controls; not representative coding tasks.',
            'Projection uses session-local aliases, not the v0.5 wire with source hashes.',
            'Only the two declared trusted candidate functions are evaluated.',
            'Chosen reads are scripted probes, not discovered needs or an executable optimal policy.',
            'Filesystem separation is not a sandbox; mounting the whole bundle leaks evaluator data.',
            'All fixtures are published here and must not be called a held-out benchmark.',
        ],
    }
    (destination / 'report.json').write_bytes(canonical(report))
    lines = ['# v0.6：需求发现的有限反例记录', '',
             '> 手工构造，实际执行固定候选与读取探针。没有调用模型，不报告自然需求发现或任务总体成功率。', '',
             '| 配对 | 首次视图相同 | 完整捕获对 selector 相同 | 目录后仍相同 | 取全快照后仍相同 | 读取仓库契约后仍相同 | 验收集合不相交 |',
             '|---|---|---|---|---|---|---|']
    flag = lambda value: '是' if value else '否'
    for r in rows:
        probes = r['probe_transcript_equal']
        lines.append('| ' + ' | '.join([r['pair_id'], flag(r['public_initial_equal']),
                     flag(r['selector_capture_equal']), flag(probes['directory_only']),
                     flag(probes['full_snapshot']), flag(probes['repository_contract']),
                     flag(r['accepted_sets_disjoint'])]) + ' |')
    lines += ['', '## 口径', '',
              '4 个手写行为族，12 个关键证据位置控制＋1 个无关内容变化控制，共 13 对／26 个构造世界。',
              '每个世界检查两份固定候选，共 52 份不同的世界×候选记录；每份包含 2 个公共检查与 1 个区分检查。构建与自检会重复调用函数，52 不是所有调用总次数，更不是 52 次 agent 修复。', '',
              '“目录后相同”等字段比较的是包含首次视图的完整脚本观察历史，而非只比较最后一个响应。',
              '8 对关键证据未出现在首次视图的输入，公共输入逐字节相同，固定候选的通过集合不相交。只提交同一个固定候选时每对至多通过其中一个世界；这不是实际模型 50% 准确率。',
              'deferred 控制下 selector 可见的完整捕获不同，允许真正的选择器利用信息；outside_snapshot 控制下捕获也相同，需新的仓库读取。',
              'protected 控制首次就不同，不能套用相同观察的限制。irrelevant_difference 控制验收集合相同，不能把任何隐文差异都判为危险遗漏。', '',
              '## 隔离与复现', '',
              '每个世界的 agent/input.json 是唯一初始可导出文件；server 中保存来源、selector 输入、验收预期与探针记录。实际实验不得把整个资料包或包含配对身份的路径提供给 agent。',
              '这里只实现 allowlist 导出与读接口，不验证宿主沙箱、挂载或真实模型请求；server 标签没有被称作独立第三方 oracle。', '',
              '所有检查输入均已随本书公开，只能用作开发回归。测试其自然需求行为需重新建立未公开、独立审核的任务集。', '',
              '主合同：[E3 需求诊断](../../../docs/experiments/E3-discovery-counterexamples.md)。']
    (destination / 'REPORT.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return report
