# v0.5 恢复协议局部诊断

> 冻结 v0.4 的三个 4096/paged 视图。读取需求由脚本指定，不是 agent 需求发现、E2 强基线或 E4 任务实验。

总量含旧首次视图、单独的公共能力描述、本地请求与响应；公共描述没有被偷偷塞进旧 4096 字节预算。原 v0.4 数字不改写。所有数值为 UTF-8 字节，不是 token 或账单。

| 输入 / 页预算 / 需求 | 方法 | 恢复响应数 | 请求字节 | 恢复响应字节 | 总计 | 多读的新原文 | 重读首次原文 | 状态 |
|---|---|---:|---:|---:|---:|---:|---:|---|
| q01-recall / 2048 / none | legacy_block | 0 | 0 | 0 | 4,277 | 0 | 0 | local_recovery_complete |
| q01-recall / 2048 / none | batch_ids | 0 | 0 | 0 | 4,277 | 0 | 0 | local_recovery_complete |
| q01-recall / 2048 / none | all_deferred | 0 | 0 | 0 | 4,277 | 0 | 0 | local_recovery_complete |
| q01-recall / 2048 / none | snapshot | 0 | 0 | 0 | 4,277 | 0 | 0 | local_recovery_complete |
| q01-recall / 2048 / first | legacy_block | 3 | 419 | 3,211 | 7,907 | 0 | 0 | local_recovery_complete |
| q01-recall / 2048 / first | batch_ids | 3 | 421 | 3,329 | 8,027 | 0 | 0 | local_recovery_complete |
| q01-recall / 2048 / first | all_deferred | 8 | 1,769 | 15,012 | 21,058 | 9,024 | 0 | local_recovery_complete |
| q01-recall / 2048 / first | snapshot | 7 | 957 | 13,846 | 19,080 | 9,024 | 2,176 | local_recovery_complete |
| q01-recall / 2048 / spread3 | legacy_block | 5 | 719 | 4,584 | 9,580 | 0 | 0 | local_recovery_complete |
| q01-recall / 2048 / spread3 | batch_ids | 3 | 437 | 4,156 | 8,870 | 0 | 0 | local_recovery_complete |
| q01-recall / 2048 / spread3 | all_deferred | 8 | 1,769 | 15,012 | 21,058 | 8,309 | 0 | local_recovery_complete |
| q01-recall / 2048 / spread3 | snapshot | 7 | 957 | 13,846 | 19,080 | 8,309 | 2,176 | local_recovery_complete |
| q01-recall / 2048 / all | legacy_block | 34 | 5,069 | 22,386 | 31,732 | 0 | 0 | local_recovery_complete |
| q01-recall / 2048 / all | batch_ids | 10 | 4,127 | 17,700 | 26,104 | 0 | 0 | local_recovery_complete |
| q01-recall / 2048 / all | all_deferred | 8 | 1,769 | 15,012 | 21,058 | 0 | 0 | local_recovery_complete |
| q01-recall / 2048 / all | snapshot | 7 | 957 | 13,846 | 19,080 | 0 | 2,176 | local_recovery_complete |
| q01-recall / 1024 / all | legacy_block | 36 | 5,356 | 22,932 | 32,565 | 0 | 0 | local_recovery_complete |
| q01-recall / 1024 / all | batch_ids | 26 | 11,673 | 25,868 | 41,818 | 0 | 0 | local_recovery_complete |
| q01-recall / 1024 / all | all_deferred | 23 | 5,273 | 23,208 | 32,758 | 0 | 0 | local_recovery_complete |
| q01-recall / 1024 / all | snapshot | 17 | 2,327 | 17,086 | 23,690 | 0 | 2,176 | local_recovery_complete |
| q01-recall / 4096 / all | legacy_block | 33 | 4,934 | 22,163 | 31,374 | 0 | 0 | local_recovery_complete |
| q01-recall / 4096 / all | batch_ids | 5 | 2,019 | 15,434 | 21,730 | 0 | 0 | local_recovery_complete |
| q01-recall / 4096 / all | all_deferred | 4 | 841 | 12,958 | 18,076 | 0 | 0 | local_recovery_complete |
| q01-recall / 4096 / all | snapshot | 4 | 546 | 12,874 | 17,697 | 0 | 2,176 | local_recovery_complete |
| q02-source / 2048 / none | legacy_block | 0 | 0 | 0 | 4,219 | 0 | 0 | local_recovery_complete |
| q02-source / 2048 / none | batch_ids | 0 | 0 | 0 | 4,219 | 0 | 0 | local_recovery_complete |
| q02-source / 2048 / none | all_deferred | 0 | 0 | 0 | 4,219 | 0 | 0 | local_recovery_complete |
| q02-source / 2048 / none | snapshot | 0 | 0 | 0 | 4,219 | 0 | 0 | local_recovery_complete |
| q02-source / 2048 / first | legacy_block | 3 | 419 | 3,096 | 7,734 | 0 | 0 | local_recovery_complete |
| q02-source / 2048 / first | batch_ids | 3 | 421 | 3,214 | 7,854 | 0 | 0 | local_recovery_complete |
| q02-source / 2048 / first | all_deferred | 8 | 1,771 | 15,387 | 21,377 | 9,401 | 0 | local_recovery_complete |
| q02-source / 2048 / first | snapshot | 7 | 957 | 14,053 | 19,229 | 9,401 | 2,010 | local_recovery_complete |
| q02-source / 2048 / spread3 | legacy_block | 5 | 719 | 4,367 | 9,305 | 0 | 0 | local_recovery_complete |
| q02-source / 2048 / spread3 | batch_ids | 3 | 437 | 3,939 | 8,595 | 0 | 0 | local_recovery_complete |
| q02-source / 2048 / spread3 | all_deferred | 8 | 1,771 | 15,387 | 21,377 | 8,786 | 0 | local_recovery_complete |
| q02-source / 2048 / spread3 | snapshot | 7 | 957 | 14,053 | 19,229 | 8,786 | 2,010 | local_recovery_complete |
| q02-source / 2048 / all | legacy_block | 33 | 4,919 | 22,322 | 31,460 | 0 | 0 | local_recovery_complete |
| q02-source / 2048 / all | batch_ids | 10 | 4,064 | 17,959 | 26,242 | 0 | 0 | local_recovery_complete |
| q02-source / 2048 / all | all_deferred | 8 | 1,771 | 15,387 | 21,377 | 0 | 0 | local_recovery_complete |
| q02-source / 2048 / all | snapshot | 7 | 957 | 14,053 | 19,229 | 0 | 2,010 | local_recovery_complete |
| q02-source / 1024 / all | legacy_block | 34 | 5,054 | 22,545 | 31,818 | 0 | 0 | local_recovery_complete |
| q02-source / 1024 / all | batch_ids | 26 | 11,487 | 26,075 | 41,781 | 0 | 0 | local_recovery_complete |
| q02-source / 1024 / all | all_deferred | 23 | 5,266 | 23,280 | 32,765 | 0 | 0 | local_recovery_complete |
| q02-source / 1024 / all | snapshot | 17 | 2,327 | 17,293 | 23,839 | 0 | 2,010 | local_recovery_complete |
| q02-source / 4096 / all | legacy_block | 32 | 4,784 | 22,099 | 31,102 | 0 | 0 | local_recovery_complete |
| q02-source / 4096 / all | batch_ids | 5 | 1,987 | 15,643 | 21,849 | 0 | 0 | local_recovery_complete |
| q02-source / 4096 / all | all_deferred | 4 | 841 | 13,282 | 18,342 | 0 | 0 | local_recovery_complete |
| q02-source / 4096 / all | snapshot | 4 | 546 | 13,081 | 17,846 | 0 | 2,010 | local_recovery_complete |
| q03-unknown / 2048 / none | legacy_block | 0 | 0 | 0 | 4,337 | 0 | 0 | local_recovery_complete |
| q03-unknown / 2048 / none | batch_ids | 0 | 0 | 0 | 4,337 | 0 | 0 | local_recovery_complete |
| q03-unknown / 2048 / none | all_deferred | 0 | 0 | 0 | 4,337 | 0 | 0 | local_recovery_complete |
| q03-unknown / 2048 / none | snapshot | 0 | 0 | 0 | 4,337 | 0 | 0 | local_recovery_complete |
| q03-unknown / 2048 / first | legacy_block | 2 | 284 | 1,609 | 6,230 | 0 | 0 | local_recovery_complete |
| q03-unknown / 2048 / first | batch_ids | 2 | 286 | 1,727 | 6,350 | 0 | 0 | local_recovery_complete |
| q03-unknown / 2048 / first | all_deferred | 3 | 603 | 6,036 | 10,976 | 3,714 | 0 | local_recovery_complete |
| q03-unknown / 2048 / first | snapshot | 4 | 545 | 7,691 | 12,573 | 3,714 | 2,296 | local_recovery_complete |
| q03-unknown / 2048 / spread3 | legacy_block | 4 | 584 | 2,747 | 7,668 | 0 | 0 | local_recovery_complete |
| q03-unknown / 2048 / spread3 | batch_ids | 2 | 302 | 2,319 | 6,958 | 0 | 0 | local_recovery_complete |
| q03-unknown / 2048 / spread3 | all_deferred | 3 | 603 | 6,036 | 10,976 | 3,230 | 0 | local_recovery_complete |
| q03-unknown / 2048 / spread3 | snapshot | 4 | 545 | 7,691 | 12,573 | 3,230 | 2,296 | local_recovery_complete |
| q03-unknown / 2048 / all | legacy_block | 12 | 1,784 | 8,597 | 14,718 | 0 | 0 | local_recovery_complete |
| q03-unknown / 2048 / all | batch_ids | 4 | 1,016 | 7,008 | 12,361 | 0 | 0 | local_recovery_complete |
| q03-unknown / 2048 / all | all_deferred | 3 | 603 | 6,036 | 10,976 | 0 | 0 | local_recovery_complete |
| q03-unknown / 2048 / all | snapshot | 4 | 545 | 7,691 | 12,573 | 0 | 2,296 | local_recovery_complete |
| q03-unknown / 1024 / all | legacy_block | 13 | 1,936 | 8,918 | 15,191 | 0 | 0 | local_recovery_complete |
| q03-unknown / 1024 / all | batch_ids | 11 | 3,298 | 10,760 | 18,395 | 0 | 0 | local_recovery_complete |
| q03-unknown / 1024 / all | all_deferred | 10 | 2,234 | 9,809 | 16,380 | 0 | 0 | local_recovery_complete |
| q03-unknown / 1024 / all | snapshot | 10 | 1,366 | 9,626 | 15,329 | 0 | 2,296 | local_recovery_complete |
| q03-unknown / 4096 / all | legacy_block | 12 | 1,784 | 8,597 | 14,718 | 0 | 0 | local_recovery_complete |
| q03-unknown / 4096 / all | batch_ids | 3 | 692 | 6,523 | 11,552 | 0 | 0 | local_recovery_complete |
| q03-unknown / 4096 / all | all_deferred | 2 | 372 | 5,548 | 10,257 | 0 | 0 | local_recovery_complete |
| q03-unknown / 4096 / all | snapshot | 2 | 271 | 7,045 | 11,653 | 0 | 2,296 | local_recovery_complete |

legacy_block 和 batch_ids 在命名 ID 前读取延后目录；all_deferred 是明确取完原延后分区，不是自动猜测所需。snapshot 明确取全旧快照。
first / spread3 的需求来自固定位置；不说明这些块对任何真实任务必要。宽范围方法的多读必须保留在表内。none 不调用恢复。
没有采用事后最优方法拼接“总赢家”；方法在每条轨迹开头固定。72 条轨迹是相关的协议控制，不是 72 个独立任务。
