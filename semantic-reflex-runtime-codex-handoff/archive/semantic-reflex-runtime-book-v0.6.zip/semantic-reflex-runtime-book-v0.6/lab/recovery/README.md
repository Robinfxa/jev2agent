# v0.5 精确范围批量召回实验室

> Python 3.10+ 标准库，离线、单源、单接收方、本地信任场景。没有模型或真实宿主。不是生产鉴权、文件服务或代理插件。

## 1. 产物

[batch_recall.py](batch_recall.py) 在原 Reader 上增加 `batch_ids` 和 `all_deferred`。旧 baseline 源码、保存格式与诊断输入不改写。[test_batch_recall.py](test_batch_recall.py) 检查有限机械合同。[run_diagnostics.py](run_diagnostics.py) 固定旧视图和脚本需求，记录四种读法的请求、响应、原文范围和额外内容。

[可读报告](diagnostics/REPORT.md) 与 [机器报告](diagnostics/report.json) 保存全部相关配置，不只展示批量有利的案例。[复现记录](reproducibility.json) 与 [测试结果](check-results.json) 分别记录确定性重跑和测试执行。

## 2. 重跑

在资料包根目录执行：

```bash
python lab/recovery/run_checks.py
python lab/recovery/run_diagnostics.py --out /tmp/srr-v05-recovery-new
```

输出目录必须不存在。默认只读资料包的冻结 bundle，没有网络请求。命令行按一份明确请求返回一页：

```bash
python lab/recovery/batch_recall.py   --bundle lab/baseline/diagnostics/q01-recall/budget-4096-paged   --run-id q01-recall --recipient-id scripted-reader   --request lab/recovery/examples/all-deferred-request.json
```

下一页把返回的 next 放入同一请求的 cursor；`next=null` 是该请求结束，不是任务结束。传入请求文件的路径不是模型可任意读取路径的在线 API，它只是本地 CLI 输入。

## 3. 合同与限制

`batch_ids` 接受同一快照的唯一 ID 列表，按源顺序返回，不补 ID 之间的内容。未知 ID 拒绝整个调用，避免“部分返回却看起来完成”。重复 ID 显式拒绝。已经在首次视图中的块仍可请求。

`all_deferred` 读取保存的原 D，不跟踪“已读”或“已理解”。游标绑定 source、view、mode 和规范化 IDs，不绑定页预算，允许同一请求在另一个页大小下续读。游标是引用而非签名/权限证明；可重放不等于严格一次交付。

每页必须装下完整 JSON 元信息加至少一个 UTF-8 字符，或明确返回合法空范围的终点；装不下就报错，不返回永不前进的成功页。正整数预算、请求字节上限、显式 ID 数量都有机械检查。批量不支持跨源、跨租户或动态新搜索。

原 Reader 在打开时校验本地快照；长期存活的对象不实现实时撤权、retention、并发替换或再次认证。生产适配必须从宿主继承每次请求的当前权限。源和清单的普通哈希不抵抗可同时改写两者的攻击者。

代码仍会在内存中读取来源并构造候选完整响应，不能因最终响应有上限就声称解析内存和 CPU 已受完整资源治理。新进程续读只证明普通文件路径，不证明崩溃持久化或分布式事务。

## 4. 比较口径

三份旧 `4096/paged` 首次信封逐字节不变。单独增加同样的 368 字节能力描述，并明确不包含在旧首次预算。请求与响应采用本地 JSON 序列化；不是实际宿主工具 schema 或 provider 请求。初始搜索请求、模型推理、token/cache/费用未知。

固定需求并非自动发现需求。`first` 的一个块可能完全无用，`all` 也不代表真实 agent 总会读全。目录下载成本计入命名 ID 的两种方法；“取完原 D”不要求先逐项下载目录，但它可能多取很多内容。不能省略这种多读来宣布方法更好。

本轮命名 ID 的路径统一完整读取目录；没有实现“读到所需目录页即可停止”的候选。这是局部受控对照，不应把它当成已优化到尽头的强 B。
