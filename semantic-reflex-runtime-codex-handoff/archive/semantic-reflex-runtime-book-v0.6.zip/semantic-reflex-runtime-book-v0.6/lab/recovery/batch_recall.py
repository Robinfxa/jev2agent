#!/usr/bin/env python3
"""Exact-scope batched recall over immutable v0.4 local bundles.

Python 3.10+ standard library. NOT a host adapter or an authentication layer.
The caller context is trusted laboratory input. Hashes bind data, not authority.
No semantic calls, source refresh, implicit gap filling, or mutable 'already read' set.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
import sys
from typing import Any

sys.path.append(str(Path(__file__).resolve().parents[1] / 'baseline'))
from baseline_lab import ContractError, Reader, digest, require, wire

SCHEMA = 'local-batch-recall-v1'
MAX_IDS = 128
MAX_REQUEST_BYTES = 16384
CAPABILITIES = {
    'schema': 'local-recovery-comparison-capabilities-v1',
    'methods': ['legacy_block', 'batch_ids', 'all_deferred', 'snapshot'],
    'scope': 'one_saved_snapshot_one_recipient',
    'all_deferred': 'explicitly_request_original_deferred_partition_not_unread',
    'cursor': 'snapshot_view_and_request_bound_reference_not_authority',
    'note': 'local_protocol_descriptor_not_a_real_host_tool_schema',
}


@dataclass(frozen=True)
class Plan:
    mode: str
    ids: tuple[str, ...]
    plan_hash: str
    total_bytes: int


class BatchReader(Reader):
    """A read-only extension: legacy preparation and bundle files stay unchanged."""

    def __init__(self, bundle: Path, run_id: str, recipient_id: str) -> None:
        super().__init__(bundle, run_id, recipient_id)
        # The capture handle alone does not bind the original K/D view.
        self.view_hash = digest(wire(self.decision))
        self._lookup = {b.block_id: b for b in self.capture.blocks}

    def plan(self, mode: str, ids: list[str] | None = None) -> Plan:
        require(mode in {'batch_ids', 'all_deferred'}, 'unsupported exact-scope mode')
        if mode == 'all_deferred':
            require(ids is None, 'all_deferred rejects a conflicting explicit ID list')
            chosen = tuple(self.decision['deferred'])
        else:
            require(type(ids) is list and 0 < len(ids) <= MAX_IDS,
                    'explicit IDs must be a nonempty bounded list')
            require(all(type(x) is str and x for x in ids), 'invalid block ID type')
            require(len(set(ids)) == len(ids), 'duplicate ID rejected, not double billed')
            require(set(ids) <= set(self._lookup), 'unknown ID: whole request rejected')
            requested = set(ids)
            chosen = tuple(b.block_id for b in self.capture.blocks if b.block_id in requested)
        binding = {'schema': SCHEMA, 'handle': self.capture.handle,
                   'source_hash': self.capture.source_hash, 'view_hash': self.view_hash,
                   'mode': mode, 'ids': list(chosen)}
        return Plan(mode, chosen, digest(wire(binding)),
                    sum(self._lookup[x].end - self._lookup[x].start for x in chosen))

    def _position(self, plan: Plan, cursor: Any) -> tuple[int, int]:
        if cursor is None:
            return 0, 0
        require(type(cursor) is dict and set(cursor) == {'plan', 'index', 'offset'},
                'invalid cursor shape')
        require(cursor['plan'] == plan.plan_hash, 'cursor belongs to another source/view/request')
        i, offset = cursor['index'], cursor['offset']
        require(type(i) is int and type(offset) is int and i >= 0 and offset >= 0,
                'invalid cursor coordinate')
        require(i < len(plan.ids), 'cursor index outside request')
        b = self._lookup[plan.ids[i]]
        raw = self.capture.raw[b.start:b.end]
        require(offset < len(raw), 'cursor at block end must be canonical next block')
        try:
            raw[:offset].decode('utf-8')
        except UnicodeDecodeError as error:
            raise ContractError('cursor splits UTF-8 codepoint') from error
        return i, offset

    def reply(self, request: dict[str, Any]) -> bytes:
        require(type(request) is dict, 'request must be an object')
        require(set(request) <= {'schema', 'mode', 'handle', 'ids', 'cursor', 'max_response_bytes'},
                'unknown request field')
        require(len(wire(request)) <= MAX_REQUEST_BYTES, 'local request byte limit exceeded')
        require(request.get('schema') == SCHEMA, 'unsupported request schema')
        require(request.get('handle') == self.capture.handle, 'wrong snapshot handle')
        budget = request.get('max_response_bytes')
        require(type(budget) is int and budget > 0, 'positive response byte budget required')
        plan = self.plan(request.get('mode'), request.get('ids'))
        index, offset = self._position(plan, request.get('cursor'))
        remaining: list[tuple[str, int, str]] = []
        for i in range(index, len(plan.ids)):
            b = self._lookup[plan.ids[i]]
            start = offset if i == index else 0
            remaining.append((b.block_id, start, self.capture.raw[b.start+start:b.end].decode('utf-8')))
        total_chars = sum(len(s) for _, _, s in remaining)

        def render(nchars: int) -> bytes:
            left = nchars
            segments: list[dict[str, Any]] = []
            next_cursor = None
            for j, (bid, local_offset, suffix) in enumerate(remaining):
                if left == 0:
                    next_cursor = {'plan': plan.plan_hash, 'index': index+j, 'offset': local_offset}
                    break
                take = min(left, len(suffix))
                text = suffix[:take]
                b = self._lookup[bid]
                end = local_offset + len(text.encode('utf-8'))
                segments.append({'id': bid, 'start': b.start+local_offset,
                                 'end': b.start+end, 'text': text})
                left -= take
                if take < len(suffix):
                    next_cursor = {'plan': plan.plan_hash, 'index': index+j, 'offset': end}
                    break
            return wire({'schema': SCHEMA, 'mode': plan.mode,
                         'handle': self.capture.handle, 'source_hash': self.capture.source_hash,
                         'source_version': self.capture.source_version,
                         'plan': plan.plan_hash, 'snapshot_only': True,
                         'request_blocks': len(plan.ids), 'request_raw_bytes': plan.total_bytes,
                         'segments': segments, 'next': next_cursor})

        complete = render(total_chars)
        if len(complete) <= budget:
            return complete
        # Terminal `null` can be smaller: check it before binary search.
        # Adding a segment replaces a cursor offset with the next block's zero;
        # segment overhead exceeds any offset digit decrease in this bounded format.
        lo, hi, best = 1, total_chars - 1, None
        while lo <= hi:
            mid = (lo + hi) // 2
            candidate = render(mid)
            if len(candidate) <= budget:
                best = candidate
                lo = mid + 1
            else:
                hi = mid - 1
        require(best is not None, 'metadata plus one UTF-8 character does not fit; no progress')
        return best


def make_request(reader: BatchReader, mode: str, budget: int,
                 ids: list[str] | None = None, cursor: Any = None) -> dict:
    obj = {'schema': SCHEMA, 'mode': mode, 'handle': reader.capture.handle,
           'max_response_bytes': budget, 'cursor': cursor}
    if ids is not None:
        obj['ids'] = ids
    return obj


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--recipient-id', required=True)
    parser.add_argument('--request', type=Path, required=True)
    args = parser.parse_args()
    try:
        require(args.request.stat().st_size <= MAX_REQUEST_BYTES, 'request file too large')
        reader = BatchReader(args.bundle, args.run_id, args.recipient_id)
        request = json.loads(args.request.read_bytes())
        sys.stdout.buffer.write(reader.reply(request))
    except (ContractError, UnicodeError, KeyError, TypeError, OSError, json.JSONDecodeError) as error:
        print(f'LOCAL_BATCH_CONTRACT_ERROR: {error}', file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
