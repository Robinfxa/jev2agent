#!/usr/bin/env python3
"""Paired protocol diagnostics on frozen v0.4 views. No agent or model.

All methods receive the same scripted demand. Computing that demand is NOT measured
or solved. Initial legacy views are not reselected. A common separately measured
capability descriptor is included; not silently added within the old 4096-byte budget.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import json
import shutil
import tempfile

from batch_recall import (BatchReader, CAPABILITIES, ContractError, digest,
                         make_request, require, wire)

BASE = Path(__file__).resolve().parent
INPUT = BASE.parent / 'baseline' / 'diagnostics'
QUERIES = ('q01-recall', 'q02-source', 'q03-unknown')
METHODS = ('legacy_block', 'batch_ids', 'all_deferred', 'snapshot')
# Fixed diagnostic controls, not tuned to a task metric or a claim of relevance.
CONTROLS = ((2048, 'none'), (2048, 'first'), (2048, 'spread3'),
            (2048, 'all'), (1024, 'all'), (4096, 'all'))


def wanted_ids(ids: list[str], kind: str) -> list[str]:
    if kind == 'none': return []
    if kind == 'all': return ids.copy()
    if kind == 'first': return ids[:1]
    require(kind == 'spread3', 'unknown demand control')
    indexes = sorted(set((0, len(ids)//2, len(ids)-1))) if ids else []
    return [ids[i] for i in indexes]


def union_size(ranges: list[tuple[int, int]]) -> int:
    total, end = 0, 0
    for a, b in sorted(ranges):
        if b > end:
            total += b - max(end, a)
            end = b
    return total


def overlap_size(left: list[tuple[int, int]], right: list[tuple[int, int]]) -> int:
    intersections = [(max(a,c), min(b,d)) for a,b in left for c,d in right if max(a,c)<min(b,d)]
    return union_size(intersections)


def execute(reader: BatchReader, initial: bytes, demand: list[str], method: str,
            budget: int) -> tuple[dict, list[dict]]:
    c, d = reader.capture, reader.decision
    lookup = {b.block_id: b for b in c.blocks}
    target_ranges = [(lookup[x].start, lookup[x].end) for x in demand]
    returned: list[tuple[int, int]] = []
    trace = []

    def record(request: dict, response: bytes, phase: str = 'recall') -> dict:
        obj = json.loads(response)
        require(len(response) <= budget, 'response exceeds comparison page budget')
        trace.append({'phase': phase, 'request': request, 'request_bytes': len(wire(request)),
                      'response': obj, 'response_bytes': len(response)})
        segments = obj.get('segments', [])
        if 'text' in obj: segments = [{'start':obj['start'], 'end':obj['end'], 'text':obj['text']}]
        for segment in segments:
            a,b = segment['start'], segment['end']
            require(segment['text'].encode('utf-8') == c.raw[a:b], 'returned content differs from source')
            returned.append((a,b))
        return obj

    def send(request: dict, operation) -> dict:
        # A failed local call emits no successful response, but its attempted
        # request remains in the diagnostic ledger. No error-wire or fee is modeled.
        try:
            response = operation()
        except ContractError as exc:
            trace.append({'phase': 'failed_local_recall', 'request': request,
                          'request_bytes': len(wire(request)), 'response': None,
                          'response_bytes': 0, 'local_error': str(exc),
                          'error_transport_not_modeled': True})
            raise
        return record(request, response)

    def legacy(mode: str, bid: str | None = None) -> list[dict]:
        pages, cursor = [], 0
        while True:
            req = {'schema': 'local-recall-request-v1', 'mode': mode,
                   'handle': c.handle, 'cursor': cursor, 'max_response_bytes': budget}
            if bid is not None: req['block_id'] = bid
            page = send(req, lambda: reader.page(mode, cursor, budget, bid))
            pages.append(page)
            if page['next'] is None: break
            require(page['next'] > cursor, 'legacy cursor did not advance')
            cursor = page['next']
        return pages

    error = None
    try:
        if demand:
            if method in {'legacy_block', 'batch_ids'}:
                # No free access to server-side D when a client names explicit IDs.
                if d['directory_mode'] == 'inline':
                    entries = json.loads(initial)['directory']['entries']
                else:
                    entries = [e for page in legacy('manifest') for e in page['entries']]
                require([e['id'] for e in entries] == d['deferred'], 'directory changed')
                require(set(demand) <= {e['id'] for e in entries}, 'demand absent from visible directory')
            if method == 'legacy_block':
                for bid in demand: legacy('block', bid)
            elif method == 'snapshot':
                legacy('snapshot')
            else:
                cursor, seen = None, set()
                while True:
                    req = make_request(reader, method, budget,
                                       demand if method == 'batch_ids' else None, cursor)
                    page = send(req, lambda: reader.reply(req))
                    if page['next'] is None: break
                    fingerprint = wire(page['next'])
                    require(fingerprint not in seen, 'batch cursor did not advance')
                    seen.add(fingerprint)
                    cursor = page['next']
    except ContractError as exc:
        # Failure is retained, with incurred exchanges, rather than omitted.
        error = str(exc)
    useful = overlap_size(returned, target_ranges)
    unique = union_size(returned)
    kept_ranges = [(b.start, b.end) for b in c.blocks if b.block_id in d['kept']]
    initial_repeat = overlap_size(returned, kept_ranges)
    raw_total = sum(b-a for a,b in returned)
    descriptor_bytes = len(wire(CAPABILITIES))
    request_bytes = sum(x['request_bytes'] for x in trace)
    response_bytes = sum(x['response_bytes'] for x in trace)
    demanded_bytes = union_size(target_ranges)
    result = {
        'method': method, 'status': 'local_recovery_complete' if error is None and useful == demanded_bytes else 'local_failure',
        'error': error, 'demand_blocks': len(demand), 'demand_raw_bytes': demanded_bytes,
        'recall_response_count': sum(x['response'] is not None for x in trace),
        'attempted_request_count': len(trace), 'failed_local_calls': sum(x['response'] is None for x in trace),
        'request_bytes': request_bytes,
        'recall_response_bytes': response_bytes, 'initial_view_bytes': len(initial),
        'common_descriptor_bytes': descriptor_bytes,
        'initial_plus_descriptor_plus_recall_responses': len(initial)+descriptor_bytes+response_bytes,
        'initial_plus_descriptor_plus_request_and_response_bytes': len(initial)+descriptor_bytes+response_bytes+request_bytes,
        'recovery_returned_raw_bytes': raw_total, 'unique_recovered_raw_bytes': unique,
        'demand_covered_raw_bytes': useful, 'initially_displayed_raw_bytes_returned_again': initial_repeat,
        'extra_new_raw_bytes_outside_scripted_demand': unique-useful-initial_repeat,
        'duplicate_raw_bytes_within_recovery': raw_total-unique,
        'tokens': None, 'billable_cost': None, 'task_outcome': None,
        'model_calls': 0, 'semantic_calls': reader.semantic_calls,
        'demand_discovery_cost_measured': False,
    }
    require(result['extra_new_raw_bytes_outside_scripted_demand'] >= 0, 'bad scope accounting')
    return result, trace


def generate(output: Path) -> dict:
    require(not output.exists(), 'diagnostic output exists; choose a new path')
    output.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix='.recovery-', dir=output.parent))
    try:
        cases, inputs = [], []
        for query in QUERIES:
            bundle = INPUT / query / 'budget-4096-paged'
            reader = BatchReader(bundle, query, 'scripted-reader')
            initial = (bundle/'envelope.json').read_bytes()
            require(reader.decision['route']=='PREPARE_SELECTED_LOCAL', 'control view is not selected')
            inputs.append({'bundle': f'lab/baseline/diagnostics/{query}/budget-4096-paged',
                           'files': {p.name: digest(p.read_bytes()) for p in sorted(bundle.iterdir()) if p.is_file()}})
            for budget, kind in CONTROLS:
                demand = wanted_ids(reader.decision['deferred'], kind)
                for method in METHODS:
                    result, trace = execute(reader, initial, demand, method, budget)
                    case_id = f'{query}-{budget}-{kind}-{method}'
                    result.update({'case_id': case_id, 'query_id': query,
                                   'demand_control': kind, 'demand_ids': demand,
                                   'response_budget_bytes': budget,
                                   'source_hash': reader.capture.source_hash,
                                   'frozen_view_hash': reader.view_hash,
                                   'source_raw_bytes': len(reader.capture.raw),
                                   'legacy_local_full_display_bytes': reader.decision['native_bytes'],
                                   'trace_path': f'traces/{case_id}.jsonl'})
                    path = stage / result['trace_path']
                    path.parent.mkdir(exist_ok=True)
                    path.write_bytes(b''.join(wire(x) for x in trace))
                    cases.append(result)
        report = {'version':'0.5', 'kind':'fixed_view_fixed_scripted_demand_protocol_diagnostic',
                  'case_count':len(cases), 'independent_tasks':False,
                  'input_views':inputs, 'common_capabilities':CAPABILITIES,
                  'initial_view_policy':'frozen_v0.4_no_reselection',
                  'descriptor_policy':'separate_common_counted_local_message_not_in_old_4096_budget',
                  'limitations':['Demand sets are scripted, not relevance labels or model-discovered needs.',
                    'Local JSON request/response byte counts; not actual host schemas, tokenizer or bills.',
                    'Legacy local full display is unpaginated and is not a feasible actual-host A comparison.',
                    'All methods get the same demand, but overfetching methods may deliver more source.',
                    'No natural recall probabilities, task success, latency or semantic performance.'],
                  'cases':cases}
        (stage/'report.json').write_bytes(wire(report))
        lines = ['# v0.5 恢复协议局部诊断','',
                 '> 冻结 v0.4 的三个 4096/paged 视图。读取需求由脚本指定，不是 agent 需求发现、E2 强基线或 E4 任务实验。','',
                 '总量含旧首次视图、单独的公共能力描述、本地请求与响应；公共描述没有被偷偷塞进旧 4096 字节预算。原 v0.4 数字不改写。所有数值为 UTF-8 字节，不是 token 或账单。','',
                 '| 输入 / 页预算 / 需求 | 方法 | 恢复响应数 | 请求字节 | 恢复响应字节 | 总计 | 多读的新原文 | 重读首次原文 | 状态 |',
                 '|---|---|---:|---:|---:|---:|---:|---:|---|']
        for r in cases:
            lines.append(f"| {r['query_id']} / {r['response_budget_bytes']} / {r['demand_control']} | {r['method']} | "
                         f"{r['recall_response_count']} | {r['request_bytes']:,} | {r['recall_response_bytes']:,} | "
                         f"{r['initial_plus_descriptor_plus_request_and_response_bytes']:,} | "
                         f"{r['extra_new_raw_bytes_outside_scripted_demand']:,} | {r['initially_displayed_raw_bytes_returned_again']:,} | {r['status']} |")
        lines += ['', 'legacy_block 和 batch_ids 在命名 ID 前读取延后目录；all_deferred 是明确取完原延后分区，不是自动猜测所需。snapshot 明确取全旧快照。',
                  'first / spread3 的需求来自固定位置；不说明这些块对任何真实任务必要。宽范围方法的多读必须保留在表内。none 不调用恢复。',
                  '没有采用事后最优方法拼接“总赢家”；方法在每条轨迹开头固定。72 条轨迹是相关的协议控制，不是 72 个独立任务。', '']
        (stage/'REPORT.md').write_text('\n'.join(lines), encoding='utf-8')
        stage.rename(output)
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        raise
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    try:
        report = generate(args.out)
    except (ContractError, OSError) as exc:
        print(f'LOCAL_DIAGNOSTIC_ERROR: {exc}'); return 2
    print(json.dumps({'cases':report['case_count'], 'failures':sum(r['status']=='local_failure' for r in report['cases']),
                      'model_calls':0, 'task_outcome':None}, indent=2))
    return 0


if __name__ == '__main__': raise SystemExit(main())
