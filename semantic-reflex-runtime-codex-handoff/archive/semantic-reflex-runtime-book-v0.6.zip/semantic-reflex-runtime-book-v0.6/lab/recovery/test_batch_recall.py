"""Finite local protocol tests, not host or semantic quality validation."""
from dataclasses import replace
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from batch_recall import (BatchReader, ContractError, MAX_IDS, SCHEMA,
                          make_request, wire)
from baseline_lab import Block, Capture, prepare_bundle, select
from run_diagnostics import execute, overlap_size, union_size, wanted_ids


def fixture(chunks=None, **overrides):
    chunks = chunks if chunks is not None else [f'origin-{i}\n'+('原文😀 "\\\n'*80) for i in range(8)]
    blocks, parts, pos = [], [], 0
    for i, text in enumerate(chunks):
        raw = text.encode('utf-8')
        blocks.append(Block(f'b{i}',pos,pos+len(raw),f'file-{i}'))
        parts.append(raw); pos += len(raw)
    return Capture(b''.join(parts),tuple(blocks),(),(),'run','recipient','frozen',
                   {'kind':'constructed_test','literal':'原文'},**overrides)


class BatchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.c = fixture(); self.d = select(self.c, 2600)
        self.path = self.root/'bundle'
        prepare_bundle(self.c,self.d,self.path)
        self.r = BatchReader(self.path,'run','recipient')
        self.ids = list(self.d.deferred)
        self.assertTrue(self.ids)

    def pages(self, mode='all_deferred', ids=None, budget=1024, reader=None):
        r = reader or self.r
        cursor, pages, seen = None, [], set()
        while True:
            raw = r.reply(make_request(r,mode,budget,ids,cursor))
            self.assertLessEqual(len(raw),budget)
            p = json.loads(raw); pages.append(p)
            if p['next'] is None: return pages
            self.assertTrue(p['segments'])
            self.assertNotIn(wire(p['next']),seen); seen.add(wire(p['next']))
            cursor = p['next']
            self.assertLess(len(pages),1000)

    def reconstructed(self, pages):
        parts = {}
        for p in pages:
            for s in p['segments']:
                raw = s['text'].encode('utf-8')
                self.assertEqual(raw,self.c.raw[s['start']:s['end']])
                parts[s['id']] = parts.get(s['id'],b'')+raw
        return parts

    def test_all_deferred_exact_partition(self):
        pieces = self.reconstructed(self.pages())
        self.assertEqual(set(pieces),set(self.d.deferred))
        self.assertTrue(all(pieces[b.block_id]==self.c.raw[b.start:b.end] for b in self.c.blocks if b.block_id in pieces))

    def test_explicit_noncontiguous_no_gap_filling(self):
        ids = [self.ids[-1],self.ids[0]]
        pages = self.pages('batch_ids',ids)
        self.assertEqual(set(self.reconstructed(pages)),set(ids))
        order = [s['id'] for p in pages for s in p['segments']]
        self.assertEqual(order,sorted(order,key=lambda x:int(x[1:])))

    def test_already_included_block_can_be_recalled(self):
        ids = [self.d.kept[0]]
        self.assertEqual(set(self.reconstructed(self.pages('batch_ids',ids))),set(ids))

    def test_requested_ids_canonical_source_order(self):
        self.assertEqual(self.r.plan('batch_ids',self.ids).plan_hash,
                         self.r.plan('batch_ids',list(reversed(self.ids))).plan_hash)

    def test_no_mutable_unread_set(self):
        self.pages('batch_ids',[self.ids[0]])
        self.assertEqual(set(self.reconstructed(self.pages())),set(self.ids))

    def test_same_request_replays_same_bytes(self):
        req = make_request(self.r,'all_deferred',1024)
        self.assertEqual(self.r.reply(req),self.r.reply(req))

    def test_no_semantic_calls(self):
        with patch('baseline_lab.select',side_effect=AssertionError('selector called')):
            self.pages()
        self.assertEqual(self.r.semantic_calls,0)

    def test_unknown_id_rejects_entire_batch(self):
        with self.assertRaises(ContractError): self.r.reply(make_request(self.r,'batch_ids',2048,[self.ids[0],'missing']))

    def test_duplicate_id_rejected(self):
        with self.assertRaises(ContractError): self.r.plan('batch_ids',[self.ids[0]]*2)

    def test_invalid_ids_types_and_empty(self):
        for ids in ([], 'b0', ('b0',), [None], [True], [1]):
            with self.subTest(ids=ids),self.assertRaises(ContractError): self.r.plan('batch_ids',ids)

    def test_conflicting_all_deferred_ids_rejected(self):
        with self.assertRaises(ContractError): self.r.plan('all_deferred',self.ids)

    def test_explicit_id_count_bound(self):
        with self.assertRaises(ContractError): self.r.plan('batch_ids',[f'b{i}' for i in range(MAX_IDS+1)])

    def test_wrong_handle_and_schema(self):
        for field,value in [('schema','wrong'),('handle','wrong')]:
            req = make_request(self.r,'all_deferred',2048); req[field]=value
            with self.subTest(field=field),self.assertRaises(ContractError): self.r.reply(req)

    def test_unknown_field_cannot_select_new_scope(self):
        req = make_request(self.r,'all_deferred',2048); req['path']='../../private'
        with self.assertRaises(ContractError): self.r.reply(req)

    def test_invalid_response_budgets(self):
        for budget in (0,-1,True,1.5,'1024'):
            with self.subTest(budget=budget),self.assertRaises(ContractError):
                self.r.reply(make_request(self.r,'all_deferred',budget))

    def test_tiny_budget_errors_not_empty_progress(self):
        with self.assertRaises(ContractError): self.r.reply(make_request(self.r,'all_deferred',10))

    def test_request_size_bound(self):
        req = make_request(self.r,'batch_ids',2048,['x'*20000])
        with self.assertRaises(ContractError): self.r.reply(req)

    def test_cursor_bound_to_changed_id_set(self):
        p = json.loads(self.r.reply(make_request(self.r,'batch_ids',1024,self.ids)))
        with self.assertRaises(ContractError):
            self.r.reply(make_request(self.r,'batch_ids',1024,self.ids[:1],p['next']))

    def test_cursor_bound_to_mode(self):
        p = json.loads(self.r.reply(make_request(self.r,'all_deferred',1024)))
        with self.assertRaises(ContractError): self.r.reply(make_request(self.r,'batch_ids',1024,self.ids,p['next']))

    def test_cursor_bound_to_view_even_same_capture(self):
        d2=select(self.c,4400); self.assertNotEqual(d2.kept,self.d.kept)
        path=self.root/'second'; prepare_bundle(self.c,d2,path)
        r2=BatchReader(path,'run','recipient')
        self.assertEqual(r2.capture.handle,self.r.capture.handle)
        p=json.loads(self.r.reply(make_request(self.r,'batch_ids',1024,self.ids)))
        with self.assertRaises(ContractError): r2.reply(make_request(r2,'batch_ids',1024,self.ids,p['next']))

    def test_cursor_bound_to_source_revision(self):
        c2=replace(self.c,source_version='new-version')
        path=self.root/'newsource';prepare_bundle(c2,select(c2,2600),path)
        r2=BatchReader(path,'run','recipient')
        p=json.loads(self.r.reply(make_request(self.r,'all_deferred',1024)))
        with self.assertRaises(ContractError): r2.reply(make_request(r2,'all_deferred',1024,cursor=p['next']))

    def test_cursor_splits_unicode_rejected(self):
        bid=self.ids[0]; b=next(b for b in self.c.blocks if b.block_id==bid)
        raw=self.c.raw[b.start:b.end]; index=raw.find('原'.encode())+1
        cursor={'plan':self.r.plan('batch_ids',[bid]).plan_hash,'index':0,'offset':index}
        with self.assertRaises(ContractError): self.r.reply(make_request(self.r,'batch_ids',1024,[bid],cursor))

    def test_invalid_cursor_coordinates(self):
        ph=self.r.plan('all_deferred').plan_hash
        for i,o in [(-1,0),(True,0),(999,0),(0,-1),(0,999999),(0,True)]:
            with self.subTest(i=i,o=o),self.assertRaises(ContractError):
                self.r.reply(make_request(self.r,'all_deferred',1024,cursor={'plan':ph,'index':i,'offset':o}))

    def test_invalid_cursor_shape(self):
        for cursor in (0,[],{},'token',{'plan':'x','index':0,'offset':0,'extra':1}):
            with self.subTest(cursor=cursor),self.assertRaises(ContractError):
                self.r.reply(make_request(self.r,'all_deferred',1024,cursor=cursor))

    def test_resume_after_process_restart(self):
        req = make_request(self.r,'all_deferred',1024)
        first = json.loads(self.r.reply(req)); req['cursor']=first['next']
        p=self.root/'request.json';p.write_bytes(wire(req))
        result=subprocess.run([sys.executable,str(Path(__file__).with_name('batch_recall.py')),
            '--bundle',str(self.path),'--run-id','run','--recipient-id','recipient','--request',str(p)],
            capture_output=True,check=False)
        self.assertEqual(result.returncode,0,result.stderr.decode())
        self.assertEqual(result.stdout,self.r.reply(req))

    def test_cli_bad_request_no_success_stdout(self):
        p=self.root/'request.json';p.write_bytes(wire(make_request(self.r,'batch_ids',2048,['bad'])))
        result=subprocess.run([sys.executable,str(Path(__file__).with_name('batch_recall.py')),
            '--bundle',str(self.path),'--run-id','run','--recipient-id','recipient','--request',str(p)],capture_output=True)
        self.assertEqual(result.returncode,2);self.assertEqual(result.stdout,b'')

    def test_local_recipient_binding_checked_on_open(self):
        with self.assertRaises(ContractError): BatchReader(self.path,'run','other')

    def test_corrupt_source_rejected_on_open(self):
        (self.path/'source.txt').write_bytes(b'corrupt')
        with self.assertRaises(ContractError): BatchReader(self.path,'run','recipient')

    def test_files_not_changed_by_reading(self):
        before={p.name:p.read_bytes() for p in self.path.iterdir()}
        self.pages()
        self.assertEqual(before,{p.name:p.read_bytes() for p in self.path.iterdir()})

    def test_all_deferred_empty_on_full_view(self):
        c=replace(self.c,explicit_full=True);p=self.root/'full';prepare_bundle(c,select(c,2600),p)
        r=BatchReader(p,'run','recipient')
        page=json.loads(r.reply(make_request(r,'all_deferred',1024)))
        self.assertEqual(page['segments'],[]);self.assertIsNone(page['next'])

    def test_terminal_page_null_and_fits_exact_budget(self):
        req=make_request(self.r,'batch_ids',100000,[self.ids[0]])
        full=self.r.reply(req);req['max_response_bytes']=len(full)
        self.assertEqual(self.r.reply(req),full);self.assertIsNone(json.loads(full)['next'])

    def test_same_cursor_can_resume_at_different_budget(self):
        p=json.loads(self.r.reply(make_request(self.r,'all_deferred',1024)))
        req=make_request(self.r,'all_deferred',2048,cursor=p['next'])
        self.assertLessEqual(len(self.r.reply(req)),2048)

    def test_constructed_unicode_and_budget_sweep(self):
        rng=random.Random(5)
        # A finite generated property check; not a population sample.
        for trial in range(8):
            chunks=[''.join(rng.choice(['a','中','😀','"','\\','\n']) for _ in range(70+i*3)) for i in range(5)]
            c=fixture(chunks);d=select(c,1800);p=self.root/f'random-{trial}';prepare_bundle(c,d,p)
            r=BatchReader(p,'run','recipient')
            for budget in (768,1024,1600):
                with self.subTest(trial=trial,budget=budget):
                    pages=self.pages('batch_ids',['b4','b0','b2'],budget,r)
                    pieces={}
                    for page in pages:
                        for s in page['segments']:
                            self.assertEqual(s['text'].encode(),c.raw[s['start']:s['end']])
                            pieces[s['id']]=pieces.get(s['id'],b'')+s['text'].encode()
                    self.assertEqual(set(pieces),{'b0','b2','b4'})
                    for b in c.blocks:
                        if b.block_id in pieces:self.assertEqual(pieces[b.block_id],c.raw[b.start:b.end])

    def test_diagnostic_same_demand_with_scope_accounting(self):
        demand=[self.ids[0]]
        for method in ('legacy_block','batch_ids','all_deferred','snapshot'):
            with self.subTest(method=method):
                r,trace=execute(self.r,self.d.payload,demand,method,2048)
                self.assertEqual(r['status'],'local_recovery_complete')
                self.assertEqual(r['request_bytes'],sum(len(wire(x['request'])) for x in trace))
                self.assertEqual(r['recall_response_bytes'],sum(len(wire(x['response'])) for x in trace))
                self.assertIsNone(r['task_outcome']);self.assertIsNone(r['billable_cost'])
                if method in {'legacy_block','batch_ids'}:
                    self.assertEqual(r['extra_new_raw_bytes_outside_scripted_demand'],0)
                    self.assertEqual(r['initially_displayed_raw_bytes_returned_again'],0)
                elif method=='snapshot':self.assertGreater(r['initially_displayed_raw_bytes_returned_again'],0)
                else:self.assertGreater(r['extra_new_raw_bytes_outside_scripted_demand'],0)

    def test_no_demand_no_recovery_but_descriptor_still_counted(self):
        r,trace=execute(self.r,self.d.payload,[],'batch_ids',2048)
        self.assertEqual(trace,[]);self.assertGreater(r['common_descriptor_bytes'],0)
        self.assertEqual(r['initial_plus_descriptor_plus_request_and_response_bytes'],
                         len(self.d.payload)+r['common_descriptor_bytes'])

    def test_failed_call_request_not_dropped(self):
        r,trace=execute(self.r,self.d.payload,[self.ids[0]],'all_deferred',10)
        self.assertEqual(r['status'],'local_failure')
        self.assertEqual(r['failed_local_calls'],1)
        self.assertEqual(r['attempted_request_count'],1)
        self.assertEqual(r['recall_response_count'],0)
        self.assertGreater(r['request_bytes'],0)
        self.assertIsNone(trace[0]['response'])
        self.assertTrue(trace[0]['error_transport_not_modeled'])
        self.assertIsNone(r['billable_cost'])

    def test_union_and_overlap_accounting(self):
        self.assertEqual(union_size([(0,10),(5,15),(20,30)]),25)
        self.assertEqual(overlap_size([(0,10),(5,15)],[(8,22)]),7)
        self.assertEqual(wanted_ids(['a','b','c','d'],'spread3'),['a','c','d'])
        self.assertEqual(wanted_ids([],'spread3'),[])


if __name__=='__main__':unittest.main(verbosity=2)
