#!/usr/bin/env python3
"""Run real local text capture and scripted recovery; no model or host experiment.

The corpus is frozen v0.3 architecture text. Query/budget variants are dependent
mechanism probes, NOT independent tasks or a representative performance sample.
Only local response UTF-8 bytes are measured; no tokens, requests or cost claims.
"""
from __future__ import annotations
from pathlib import Path
import argparse
import json
import shutil
import tempfile

from baseline_lab import (Reader, capture_files, digest, native_view, prepare_bundle,
                          require, select, wire)

BASE = Path(__file__).resolve().parent
QUERIES = [('q01-recall','recall'), ('q02-source','原文'), ('q03-unknown','unknown')]
BUDGETS = (1024,4096,8192)
DIRECTORIES = ('inline','paged')
RECALL_BUDGET = 2048


def recover(reader: Reader, output: Path) -> dict:
    c = reader.capture
    d = reader.decision
    if not d['deferred']:
        return {'scripted_recovery':'not_needed_no_deferral', 'response_bytes':0,
                'reply_count':0, 'all_source_reconstructed':True}
    trace = []
    directory_ids=[]
    if d['directory_mode']=='inline':
        initial=json.loads((output/'envelope.json').read_bytes())
        directory_ids=[x['id'] for x in initial['directory']['entries']]
    else:
        cursor=0
        while True:
            response=reader.page('manifest',cursor,RECALL_BUDGET)
            p=json.loads(response)
            trace.append({'mode':'manifest','cursor':cursor,'reply':p,'wire_bytes':len(response)})
            directory_ids.extend(x['id'] for x in p['entries'])
            if p['next'] is None:break
            require(p['next']>cursor,'nonprogressing manifest cursor')
            cursor=p['next']
    require(directory_ids==d['deferred'],'directory differs from recorded deferred partition')
    collected={x: c.raw[b.start:b.end] for b in c.blocks for x in [b.block_id] if x in d['kept']}
    for block_id in directory_ids:
        cursor=0
        recovered=b''
        while True:
            response=reader.page('block',cursor,RECALL_BUDGET,block_id)
            p=json.loads(response)
            trace.append({'mode':'block','block_id':block_id,'cursor':cursor,
                          'reply':p,'wire_bytes':len(response)})
            recovered+=p['text'].encode('utf-8')
            if p['next'] is None:break
            require(p['next']>cursor,'nonprogressing block cursor')
            cursor=p['next']
        collected[block_id]=recovered
    assembled=b''.join(collected[b.block_id] for b in c.blocks)
    require(assembled==c.raw,'recovered display snapshot differs')
    (output/'scripted-recovery.jsonl').write_bytes(b''.join(wire(row) for row in trace))
    # A different explicit reader policy: request the whole saved snapshot, with
    # fewer repeated per-block headers but duplication of initially visible text.
    # It is an alternative path, NOT additional traffic on the previous path.
    cursor=0
    whole_trace=[]
    whole_bytes=b''
    while True:
        response=reader.page('snapshot',cursor,RECALL_BUDGET)
        p=json.loads(response)
        whole_trace.append({'mode':'snapshot','cursor':cursor,'reply':p,'wire_bytes':len(response)})
        whole_bytes+=p['text'].encode('utf-8')
        if p['next'] is None:break
        require(p['next']>cursor,'nonprogressing snapshot cursor')
        cursor=p['next']
    require(whole_bytes==c.raw,'full-snapshot recovery differs')
    (output/'alternative-snapshot-recovery.jsonl').write_bytes(b''.join(wire(row) for row in whole_trace))
    return {'scripted_recovery':'explicitly_read_every_deferred_block',
            'response_bytes':sum(row['wire_bytes'] for row in trace),
            'alternative_full_snapshot_response_bytes':sum(row['wire_bytes'] for row in whole_trace),
            'alternative_full_snapshot_reply_count':len(whole_trace),
            'reply_count':len(trace), 'all_source_reconstructed':True,
            'reconstructed_sha256':digest(assembled), 'semantic_calls':reader.semantic_calls}


def generate(output: Path) -> dict:
    require(not output.exists(),'diagnostic output already exists; choose a new directory')
    corpus=BASE/'corpus'
    manifest=json.loads((corpus/'CORPUS_MANIFEST.json').read_text())
    names=[e['file'] for e in manifest['files']]
    for e in manifest['files']:
        raw=(corpus/e['file']).read_bytes()
        require(digest(raw)==e['sha256'] and len(raw)==e['bytes'],'frozen corpus changed')
    output.parent.mkdir(parents=True,exist_ok=True)
    stage=Path(tempfile.mkdtemp(prefix='.diagnostic-stage-',dir=output.parent))
    results=[]
    try:
        for name,query in QUERIES:
            qdir=stage/name;qdir.mkdir()
            c=capture_files(corpus,names,query,context=1,
                            run_id=name,recipient_id='scripted-reader')
            (qdir/'capture.json').write_bytes(wire({'capture':c.metadata(),'raw_text':c.raw.decode()}))
            (qdir/'native-display.json').write_bytes(native_view(c))
            for budget in BUDGETS:
                for mode in DIRECTORIES:
                    d=select(c,budget,mode)
                    bundle=qdir/f'budget-{budget}-{mode}'
                    prepare_bundle(c,d,bundle)
                    r=Reader(bundle,c.run_id,c.recipient_id)
                    recovery=recover(r,bundle)
                    total=len(d.payload)+recovery['response_bytes']
                    results.append({'case_id':f'{name}/budget-{budget}-{mode}',
                        'data_kind':'local_document_search_and_scripted_reader',
                        'literal_query':query,'budget_bytes':budget,'directory_mode':mode,
                        'source_snapshot_bytes':len(c.raw),'native_display_bytes':len(native_view(c)),
                        'first_response_bytes':len(d.payload),'kept_blocks':len(d.kept),
                        'deferred_blocks':len(d.deferred),'route':d.route,'reason':d.reason,
                        'within_local_byte_budget':len(d.payload)<=budget,
                        'initial_response_reduction_fraction':1-len(d.payload)/len(native_view(c)),
                        'scripted_recovery':recovery,
                        'initial_plus_recovery_response_bytes':total,
                        'alternative_initial_plus_full_snapshot_response_bytes':
                           len(d.payload)+recovery.get('alternative_full_snapshot_response_bytes',0),
                        'initial_plus_recovery_vs_native_ratio':total/len(native_view(c)),
                        'tokens':None,'model_calls':0,'task_outcome':None,'billing_cost':None})
        report={'version':'0.4','kind':'offline_diagnostic_not_agent_benchmark',
            'corpus_files':len(names),'queries':[q for _,q in QUERIES],
            'frozen_budgets_bytes':list(BUDGETS),'recall_budget_bytes':RECALL_BUDGET,
            'case_count':len(results), 'cases_are_not_independent_tasks':True,
            'limitations':['No model decides what to recall. Script deliberately retrieves all deferred blocks.',
                'Response UTF-8 bytes only; excludes requests, later prompt rereads, model/tool latency and money.',
                'Native display is this local demonstrator, not a measured external host baseline.',
                'Copied architecture prose is not representative coding-task evidence.'],
            'cases':results}
        (stage/'report.json').write_bytes(wire(report))
        lines=['# v0.4 本地确定性 B 诊断记录','',
            '> 实际读取冻结的 v0.3 架构文档；随后由脚本取回全部延后块。不是模型实验，不是 E0/E2/E4 通过。','',
            '所有数值为本地响应 UTF-8 字节。不含请求、后续上下文重复读取或费用。A 是本样机的全量显示，不是外部宿主实测基线。','',
            '| 查询 / 预算 / 目录 | 全量显示 A | 首次响应 | 延后块 | 初次＋全量恢复响应 | 路径 |',
            '|---|---:|---:|---:|---:|---|']
        for row in results:
            lines.append(f"| {row['literal_query']} / {row['budget_bytes']} / {row['directory_mode']} | "
                f"{row['native_display_bytes']:,} | {row['first_response_bytes']:,} | {row['deferred_blocks']} | "
                f"{row['initial_plus_recovery_response_bytes']:,} | {row['route']} |")
        lines+=['','若首次响应比预算大，它是未交付的原生回退建议，须由真实宿主完整读取或明确分页处理；不是成功塞进上下文。',
                '所有延后案例都已逐页验证显示快照字节重建。可恢复性不代表 agent 会主动召回，也不代表任务质量合格。',
                '另一条脚本路径直接分页取全快照，记录于 alternative-snapshot-recovery.jsonl 与 report.json；它与逐块恢复是互斥的比较路径，不相加。',
                '目录 inline/paged 是两个离线配置，不按每次结果事后挑较优配置；真正比较需要事前冻结。','']
        (stage/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
        stage.rename(output)
    except Exception:
        shutil.rmtree(stage,ignore_errors=True)
        raise
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    report=generate(args.out)
    print(json.dumps({'cases':report['case_count'], 'selected':sum(
        x['route']=='PREPARE_SELECTED_LOCAL' for x in report['cases']),
        'model_calls':0, 'task_outcome':None, 'output':str(args.out)},ensure_ascii=False,indent=2))
    return 0

if __name__=='__main__':raise SystemExit(main())
