# v0.4 本地确定性 B 诊断记录

> 实际读取冻结的 v0.3 架构文档；随后由脚本取回全部延后块。不是模型实验，不是 E0/E2/E4 通过。

所有数值为本地响应 UTF-8 字节。不含请求、后续上下文重复读取或费用。A 是本样机的全量显示，不是外部宿主实测基线。

| 查询 / 预算 / 目录 | 全量显示 A | 首次响应 | 延后块 | 初次＋全量恢复响应 | 路径 |
|---|---:|---:|---:|---:|---|
| recall / 1024 / inline | 12,259 | 12,259 | 0 | 12,259 | USE_NATIVE_LOCAL |
| recall / 1024 / paged | 12,259 | 12,259 | 0 | 12,259 | USE_NATIVE_LOCAL |
| recall / 4096 / inline | 12,259 | 4,093 | 38 | 27,671 | PREPARE_SELECTED_LOCAL |
| recall / 4096 / paged | 12,259 | 3,909 | 32 | 26,295 | PREPARE_SELECTED_LOCAL |
| recall / 8192 / inline | 12,259 | 8,166 | 24 | 23,313 | PREPARE_SELECTED_LOCAL |
| recall / 8192 / paged | 12,259 | 7,624 | 20 | 22,329 | PREPARE_SELECTED_LOCAL |
| 原文 / 1024 / inline | 12,466 | 12,466 | 0 | 12,466 | USE_NATIVE_LOCAL |
| 原文 / 1024 / paged | 12,466 | 12,466 | 0 | 12,466 | USE_NATIVE_LOCAL |
| 原文 / 4096 / inline | 12,466 | 4,074 | 38 | 27,858 | PREPARE_SELECTED_LOCAL |
| 原文 / 4096 / paged | 12,466 | 3,851 | 31 | 26,173 | PREPARE_SELECTED_LOCAL |
| 原文 / 8192 / inline | 12,466 | 8,191 | 24 | 23,503 | PREPARE_SELECTED_LOCAL |
| 原文 / 8192 / paged | 12,466 | 7,739 | 20 | 22,518 | PREPARE_SELECTED_LOCAL |
| unknown / 1024 / inline | 7,085 | 7,085 | 0 | 7,085 | USE_NATIVE_LOCAL |
| unknown / 1024 / paged | 7,085 | 7,085 | 0 | 7,085 | USE_NATIVE_LOCAL |
| unknown / 4096 / inline | 7,085 | 3,867 | 12 | 12,611 | PREPARE_SELECTED_LOCAL |
| unknown / 4096 / paged | 7,085 | 3,969 | 11 | 12,566 | PREPARE_SELECTED_LOCAL |
| unknown / 8192 / inline | 7,085 | 7,085 | 0 | 7,085 | USE_NATIVE_LOCAL |
| unknown / 8192 / paged | 7,085 | 7,085 | 0 | 7,085 | USE_NATIVE_LOCAL |

若首次响应比预算大，它是未交付的原生回退建议，须由真实宿主完整读取或明确分页处理；不是成功塞进上下文。
所有延后案例都已逐页验证显示快照字节重建。可恢复性不代表 agent 会主动召回，也不代表任务质量合格。
另一条脚本路径直接分页取全快照，记录于 alternative-snapshot-recovery.jsonl 与 report.json；它与逐块恢复是互斥的比较路径，不相加。
目录 inline/paged 是两个离线配置，不按每次结果事后挑较优配置；真正比较需要事前冻结。
