#!/usr/bin/env python3
"""Offline deterministic admission demonstrator; Python 3.10+, standard library.

NOT a host plugin. Identity arguments are trusted lab fixtures, not authentication.
Writes one immutable local bundle; never sends to an agent or calls a model.
The local byte budget is NOT a token/context limit. No billing estimate is made.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from typing import Any, Iterable


class ContractError(ValueError):
    pass


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ContractError(message)


def wire(value: Any) -> bytes:
    """The exact UTF-8 representation measured by this local experiment."""
    return (json.dumps(value, ensure_ascii=False, sort_keys=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')


def digest(data: bytes) -> str:
    return sha256(data).hexdigest()


@dataclass(frozen=True)
class Block:
    block_id: str
    start: int
    end: int
    origin: str

    def entry(self) -> dict[str, Any]:
        return {'id': self.block_id, 'start': self.start,
                'end': self.end, 'origin': self.origin}


@dataclass(frozen=True)
class Capture:
    raw: bytes
    blocks: tuple[Block, ...]
    groups: tuple[tuple[str, ...], ...]
    protected: tuple[str, ...]
    run_id: str
    recipient_id: str
    source_version: str
    query_scope: dict[str, Any]
    capture_complete: bool = True
    producer_status: str = 'complete'
    soft: bool = True
    explicit_full: bool = False
    state_revision: str = 'local-state-1'

    def validate(self) -> None:
        require(type(self.raw) is bytes, 'raw is not bytes')
        self.raw.decode('utf-8')
        require(all(type(x) is str and x for x in
                    (self.run_id, self.recipient_id, self.source_version, self.state_revision)),
                'missing identity/version')
        require(all(type(x) is bool for x in
                    (self.capture_complete, self.soft, self.explicit_full)), 'boolean required')
        require(self.producer_status in {'complete', 'partial', 'unknown'}, 'producer status')
        require(type(self.query_scope) is dict and bool(self.query_scope), 'scope required')
        # JSON serialization validates the locally defined transport as well.
        wire(self.query_scope)
        cursor = 0
        ids: set[str] = set()
        for b in self.blocks:
            require(type(b.start) is int and type(b.end) is int and
                    b.start == cursor and b.start < b.end <= len(self.raw), 'bad partition')
            require(type(b.block_id) is str and b.block_id and b.block_id not in ids,
                    'bad/duplicate block ID')
            require(type(b.origin) is str and b.origin, 'missing origin')
            self.raw[b.start:b.end].decode('utf-8')
            ids.add(b.block_id)
            cursor = b.end
        require(cursor == len(self.raw), 'partition does not cover source')
        require(len(set(self.protected)) == len(self.protected) and
                set(self.protected) <= ids, 'unknown/duplicate protected ID')
        for group in self.groups:
            require(bool(group) and len(set(group)) == len(group) and set(group) <= ids,
                    'bad structural group')

    @property
    def source_hash(self) -> str:
        return digest(self.raw)

    @property
    def handle(self) -> str:
        # A reference only, deliberately not represented as an authorization token.
        binding = [self.run_id, self.recipient_id, self.state_revision,
                   self.source_version, self.source_hash, self.query_scope]
        return 'local_' + digest(wire(binding))[:24]

    def status(self) -> dict[str, Any]:
        return {'capture_complete': self.capture_complete,
                'producer_status': self.producer_status,
                'query_scope': self.query_scope, 'source_version': self.source_version,
                'task_sufficiency': 'not_assessed'}

    def metadata(self) -> dict[str, Any]:
        return {'schema': 'local-capture-v1',
                'blocks': [b.entry() for b in self.blocks],
                'groups': [list(g) for g in self.groups], 'protected': list(self.protected),
                'run_id': self.run_id, 'recipient_id': self.recipient_id,
                'source_version': self.source_version, 'query_scope': self.query_scope,
                'capture_complete': self.capture_complete, 'producer_status': self.producer_status,
                'soft': self.soft, 'explicit_full': self.explicit_full,
                'state_revision': self.state_revision}

    @classmethod
    def from_metadata(cls, meta: dict[str, Any], raw: bytes) -> 'Capture':
        require(meta.get('schema') == 'local-capture-v1', 'unknown capture schema')
        result = cls(raw=raw,
                     blocks=tuple(Block(x['id'], x['start'], x['end'], x['origin'])
                                  for x in meta['blocks']),
                     groups=tuple(tuple(x) for x in meta['groups']),
                     protected=tuple(meta['protected']),
                     **{k: meta[k] for k in ('run_id', 'recipient_id', 'source_version',
                         'query_scope', 'capture_complete', 'producer_status', 'soft',
                         'explicit_full', 'state_revision')})
        result.validate()
        return result


def native_view(c: Capture) -> bytes:
    """A deliberately unadorned full local display, not a claimed vendor-native wire."""
    return wire({'schema': 'local-full-display-v1', 'source_status': c.status(),
                 'presentation_kind': 'full_snapshot', 'text': c.raw.decode('utf-8')})


def components(c: Capture) -> list[frozenset[str]]:
    """Connected closure of declared groups; no semantic inference from source text."""
    parent = {b.block_id: b.block_id for b in c.blocks}

    def find(x: str) -> str:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for group in c.groups:
        for x in group[1:]:
            parent[find(x)] = find(group[0])
    result: dict[str, set[str]] = {}
    for b in c.blocks:
        result.setdefault(find(b.block_id), set()).add(b.block_id)
    return [frozenset(v) for v in result.values()]


def envelope(c: Capture, kept: frozenset[str], directory_mode: str) -> bytes:
    require(directory_mode in {'inline', 'paged'}, 'bad directory mode')
    ids = {b.block_id for b in c.blocks}
    require(kept <= ids and set(c.protected) <= kept, 'bad selection/protection')
    for group in components(c):
        require(not (group & kept) or group <= kept, 'split structural group')
    deferred = [b.entry() for b in c.blocks if b.block_id not in kept]
    result: dict[str, Any] = {
        'schema': 'local-admission-v1', 'source_status': c.status(),
        'presentation_kind': 'selected_snapshot' if deferred else 'full_snapshot',
        'source_hash': c.source_hash, 'source_bytes': len(c.raw),
        'binding': {'run': c.run_id, 'recipient': c.recipient_id,
                    'state_revision': c.state_revision},
        'included': [dict(b.entry(), text=c.raw[b.start:b.end].decode('utf-8'))
                     for b in c.blocks if b.block_id in kept],
        'deferred_count': len(deferred),
        'recall': {'handle': c.handle, 'modes': ['snapshot', 'block', 'manifest'],
                   'note': 'saved snapshot; no new search; reference is not authorization'},
        'directory': {'kind': directory_mode, 'entries': deferred} if directory_mode == 'inline'
                     else {'kind': 'paged', 'handle': c.handle, 'cursor': 0},
    }
    return wire(result)


@dataclass(frozen=True)
class Decision:
    route: str
    reason: str
    kept: tuple[str, ...]
    deferred: tuple[str, ...]
    protected_closure: tuple[str, ...]
    directory_mode: str
    max_wire_bytes: int
    payload: bytes
    native_bytes: int
    render_count: int

    def record(self) -> dict[str, Any]:
        return {'schema': 'local-decision-v1', 'route': self.route, 'reason': self.reason,
                'kept': list(self.kept), 'deferred': list(self.deferred),
                'protected_closure': list(self.protected_closure),
                'directory_mode': self.directory_mode, 'max_wire_bytes': self.max_wire_bytes,
                'wire_bytes': len(self.payload), 'native_bytes': self.native_bytes,
                'wire_sha256': digest(self.payload), 'render_count': self.render_count,
                'within_local_byte_budget': len(self.payload) <= self.max_wire_bytes,
                'delivery_state': 'PREPARED_LOCAL_NOT_SENT', 'model_calls': 0,
                'token_count': None, 'billing_cost': None,
                'host_action_required': 'unverified_host_handoff' if
                    len(self.payload) <= self.max_wire_bytes else 'full_read_or_native_pagination',
                'rule_version': 'source-order-first-fit-plus-prefix-v1'}


def select(c: Capture, max_wire_bytes: int, directory_mode: str = 'paged',
           max_components: int = 128) -> Decision:
    c.validate()
    require(type(max_wire_bytes) is int and max_wire_bytes > 0, 'positive byte budget required')
    require(type(max_components) is int and max_components > 0, 'bad component bound')
    require(directory_mode in {'inline', 'paged'}, 'bad directory mode')
    full = native_view(c)
    ordered_ids = tuple(b.block_id for b in c.blocks)
    comps = components(c)
    hard = frozenset().union(*(g for g in comps if g & set(c.protected)))
    hard_order = tuple(x for x in ordered_ids if x in hard)
    renders = 0

    def baseline(reason: str) -> Decision:
        return Decision('USE_NATIVE_LOCAL', reason, ordered_ids, (), hard_order,
                        directory_mode, max_wire_bytes, full, len(full), renders)

    if not c.soft or c.explicit_full:
        return baseline('not_soft_or_explicit_full')
    if not c.capture_complete or c.producer_status != 'complete':
        return baseline('source_incomplete_or_unknown')
    if not c.blocks:
        return baseline('empty_result')
    if len(full) <= max_wire_bytes:
        return baseline('native_already_fits_local_budget')
    if len(comps) > max_components:
        return baseline('candidate_work_bound')

    best: tuple[tuple[int, int], frozenset[str], bytes] | None = None
    examined: dict[frozenset[str], tuple[bool, bytes]] = {}

    def consider(k: frozenset[str]) -> bool:
        nonlocal renders, best
        if k in examined:
            return examined[k][0]
        candidate = envelope(c, k, directory_mode)
        renders += 1
        # No empty directory-only selected successes and no "all kept" wrapper.
        fits = bool(k) and len(k) < len(ordered_ids) and \
            len(candidate) <= max_wire_bytes and len(candidate) < len(full)
        examined[k] = (fits, candidate)
        if fits:
            score = (sum(b.end-b.start for b in c.blocks if b.block_id in k), -len(candidate))
            if best is None or score > best[0]:
                best = (score, k, candidate)
        return fits

    consider(hard)
    greedy = hard
    prefix = hard
    for group in comps:
        if group <= hard:
            continue
        proposal = greedy | group
        if consider(proposal):
            greedy = proposal
        # Inline directory length need not be monotone. An overlarge H view is
        # not a proof of infeasibility; evaluate a second bounded candidate path.
        prefix = prefix | group
        consider(prefix)
    if best is None:
        return baseline('no_admissible_candidate_under_frozen_rule')
    _, kept, payload = best
    return Decision('PREPARE_SELECTED_LOCAL', 'bounded_deterministic_selection',
                    tuple(x for x in ordered_ids if x in kept),
                    tuple(x for x in ordered_ids if x not in kept), hard_order,
                    directory_mode, max_wire_bytes, payload, len(full), renders)


def validate_decision(c: Capture, d: Decision) -> None:
    c.validate()
    require(d.route in {'USE_NATIVE_LOCAL', 'PREPARE_SELECTED_LOCAL'}, 'unknown route')
    ids = [b.block_id for b in c.blocks]
    require(len(set(d.kept)) == len(d.kept) and len(set(d.deferred)) == len(d.deferred),
            'duplicate view member')
    require(not (set(d.kept) & set(d.deferred)) and
            set(d.kept) | set(d.deferred) == set(ids), 'bad K/D partition')
    require(list(d.kept) == [x for x in ids if x in set(d.kept)] and
            list(d.deferred) == [x for x in ids if x in set(d.deferred)], 'source order changed')
    expected_h = frozenset().union(*(g for g in components(c) if g & set(c.protected)))
    require(set(d.protected_closure) == expected_h and expected_h <= set(d.kept),
            'invalid protected closure')
    require(type(d.max_wire_bytes) is int and d.max_wire_bytes > 0, 'invalid budget')
    require(d.native_bytes == len(native_view(c)), 'native byte measurement mismatch')
    if d.route == 'USE_NATIVE_LOCAL':
        require(not d.deferred and set(d.kept) == set(ids) and
                d.payload == native_view(c), 'invalid native passthrough')
    else:
        require(c.capture_complete and c.producer_status == 'complete' and
                c.soft and not c.explicit_full, 'ineligible selected source')
        require(bool(d.kept) and bool(d.deferred), 'selected view must be a nonempty proper subset')
        require(d.payload == envelope(c, frozenset(d.kept), d.directory_mode), 'invalid selected wire')
        require(len(d.payload) <= d.max_wire_bytes and len(d.payload) < d.native_bytes,
                'selected representation not within local budget or not smaller')


def prepare_bundle(c: Capture, d: Decision, output: Path) -> None:
    """Single-process, new-directory publication. Not durable distributed commit.

    No files are written into an existing output. READY is a local marker only;
    it is not a host receipt, authentication proof, or crash-consistency proof.
    """
    validate_decision(c, d)
    require(not output.exists(), 'refusing to replace an existing bundle')
    output.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix='.baseline-staging-', dir=output.parent))
    try:
        files = {'source.txt': c.raw, 'capture.json': wire(c.metadata()),
                 'decision.json': wire(d.record()), 'envelope.json': d.payload}
        for name, data in files.items():
            (staging/name).write_bytes(data)
        ready = {'schema': 'local-ready-v1', 'delivery_state': 'PREPARED_LOCAL_NOT_SENT',
                 'files': {n: digest(data) for n, data in files.items()}}
        (staging/'READY.json').write_bytes(wire(ready))
        # Intended for a trusted single-writer lab directory only.
        os.rename(staging, output)
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise


class Reader:
    """Local snapshot reader; caller context is a test fixture, not an ACL system."""

    def __init__(self, bundle: Path, run_id: str, recipient_id: str) -> None:
        ready = json.loads((bundle/'READY.json').read_text(encoding='utf-8'))
        require(ready.get('schema') == 'local-ready-v1', 'not a ready local bundle')
        names = {'source.txt', 'capture.json', 'decision.json', 'envelope.json'}
        require(set(ready.get('files', {})) == names, 'unexpected local file set')
        contents = {}
        for name in sorted(names):
            data = (bundle/name).read_bytes()
            require(digest(data) == ready['files'][name], 'corrupt local bundle: '+name)
            contents[name] = data
        self.capture = Capture.from_metadata(json.loads(contents['capture.json']), contents['source.txt'])
        require((run_id, recipient_id) == (self.capture.run_id, self.capture.recipient_id),
                'trusted lab context mismatch; not a production authorization check')
        self.decision = json.loads(contents['decision.json'])
        require(digest(contents['envelope.json']) == self.decision['wire_sha256'], 'wire hash mismatch')
        require(self.decision['delivery_state'] == 'PREPARED_LOCAL_NOT_SENT', 'unexpected delivery claim')
        d = self.decision
        validate_decision(self.capture, Decision(
            d['route'], d['reason'], tuple(d['kept']), tuple(d['deferred']),
            tuple(d['protected_closure']), d['directory_mode'], d['max_wire_bytes'],
            contents['envelope.json'], d['native_bytes'], d['render_count']))
        self.semantic_calls = 0

    def page(self, mode: str, cursor: int, max_wire_bytes: int,
             block_id: str | None = None) -> bytes:
        require(type(cursor) is int and cursor >= 0, 'invalid cursor')
        require(type(max_wire_bytes) is int and max_wire_bytes > 0, 'invalid byte budget')
        c = self.capture
        if mode == 'manifest':
            entries = [b.entry() for b in c.blocks if b.block_id in set(self.decision['deferred'])]
            require(cursor <= len(entries), 'manifest cursor out of range')

            def render_list(end: int) -> bytes:
                return wire({'schema': 'local-recall-v1', 'mode': mode, 'handle': c.handle,
                             'source_hash': c.source_hash, 'entries': entries[cursor:end],
                             'cursor': cursor, 'next': end if end < len(entries) else None,
                             'total_entries': len(entries)})

            entire = render_list(len(entries))
            if len(entire) <= max_wire_bytes:
                return entire
            last = None
            for end in range(cursor+1, len(entries)):
                candidate = render_list(end)
                if len(candidate) <= max_wire_bytes:
                    last = candidate
                else:
                    break
            require(last is not None, 'manifest item cannot fit; explicit host policy required')
            return last
        require(mode in {'snapshot', 'block'}, 'unknown recall mode')
        if mode == 'block':
            lookup = {b.block_id: b for b in c.blocks}
            require(block_id in lookup, 'unknown block ID')
            b = lookup[block_id]
            base, raw = b.start, c.raw[b.start:b.end]
        else:
            base, raw = 0, c.raw
        require(cursor <= len(raw), 'cursor beyond source')
        try:
            raw[:cursor].decode('utf-8')
            suffix = raw[cursor:].decode('utf-8')
        except UnicodeDecodeError as error:
            raise ContractError('cursor splits UTF-8 codepoint') from error

        def render_text(chars: int) -> bytes:
            text = suffix[:chars]
            end = cursor + len(text.encode('utf-8'))
            return wire({'schema': 'local-recall-v1', 'mode': mode, 'block_id': block_id,
                         'handle': c.handle, 'source_hash': c.source_hash,
                         'source_version': c.source_version, 'snapshot_only': True,
                         'start': base+cursor, 'end': base+end, 'range_bytes': len(raw),
                         'text': text, 'next': end if end < len(raw) else None})

        entire = render_text(len(suffix))
        if len(entire) <= max_wire_bytes:
            return entire
        # For nonterminal pages length grows monotonically with this serialization.
        # Test the terminal page above, whose null cursor can make it shorter.
        lo, hi, best = 1, len(suffix)-1, None
        while lo <= hi:
            mid = (lo+hi)//2
            candidate = render_text(mid)
            if len(candidate) <= max_wire_bytes:
                best = candidate
                lo = mid+1
            else:
                hi = mid-1
        require(best is not None, 'one UTF-8 character plus recall metadata cannot fit')
        return best


def capture_files(root: Path, files: Iterable[str], query: str, *, context: int = 1,
                  run_id: str = 'local-diagnostic', recipient_id: str = 'scripted-reader') -> Capture:
    """Read-only literal search over explicit UTF-8 files, no shell or network.

    Generated display snapshots are distinct from source files; recall restores the
    display, never reopens a live repository. This is NOT ripgrep or a host adapter.
    """
    require(bool(query), 'empty literal query')
    require(type(context) is int and context >= 0, 'bad context size')
    root = root.resolve()
    names = sorted(set(files))
    source_parts: list[bytes] = []
    blocks: list[Block] = []
    groups = []
    versions = []
    pos = 0
    for name in names:
        require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'unsafe relative path')
        original = root/name
        require(not original.is_symlink(), 'symlink not supported by this local capture')
        resolved = original.resolve()
        require(resolved.is_relative_to(root) and resolved.is_file(), 'file outside corpus')
        raw = resolved.read_bytes()
        text = raw.decode('utf-8')
        versions.append([name, digest(raw)])
        lines = text.splitlines(keepends=True)
        windows: list[list[int]] = []
        for i, line in enumerate(lines):
            if query in line:
                start, end = max(0, i-context), min(len(lines), i+context+1)
                if windows and start <= windows[-1][1]:
                    windows[-1][1] = max(windows[-1][1], end)
                else:
                    windows.append([start, end])
        ids = []
        for start, end in windows:
            # Labels are deterministic display formatting, not claimed raw file bytes.
            excerpt = ''.join(lines[start:end])
            chunk = (f'{name}:{start+1}-{end}\n' + excerpt +
                     ('' if excerpt.endswith('\n') else '\n') + '\n').encode('utf-8')
            block_id = f'b{len(blocks):04d}'
            blocks.append(Block(block_id, pos, pos+len(chunk), name))
            ids.append(block_id)
            pos += len(chunk)
            source_parts.append(chunk)
        if ids:
            groups.append(tuple(ids))  # conservative file grouping, not semantic completeness
    version = 'corpus_' + digest(wire(versions))[:24]
    capture = Capture(b''.join(source_parts), tuple(blocks), tuple(groups), (),
                      run_id, recipient_id, version,
                      {'kind': 'explicit_local_file_set', 'query': query,
                       'literal': True, 'context_lines': context, 'files': names})
    capture.validate()
    return capture


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    p = commands.add_parser('prepare', help='prepare a local bundle, never sends to a model')
    p.add_argument('--capture', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--budget', type=int, required=True)
    p.add_argument('--directory', choices=['inline', 'paged'], default='paged')
    p = commands.add_parser('recall', help='trusted-local-fixture reader; not an auth boundary')
    p.add_argument('--bundle', type=Path, required=True)
    p.add_argument('--run-id', required=True)
    p.add_argument('--recipient-id', required=True)
    p.add_argument('--mode', choices=['snapshot', 'block', 'manifest'], required=True)
    p.add_argument('--block-id')
    p.add_argument('--cursor', type=int, default=0)
    p.add_argument('--budget', type=int, default=4096)
    args = parser.parse_args()
    try:
        if args.command == 'prepare':
            obj = json.loads(args.capture.read_text(encoding='utf-8'))
            c = Capture.from_metadata(obj['capture'], obj['raw_text'].encode('utf-8'))
            d = select(c, args.budget, args.directory)
            prepare_bundle(c, d, args.out)
            sys.stdout.buffer.write(wire(d.record()))
        else:
            r = Reader(args.bundle, args.run_id, args.recipient_id)
            sys.stdout.buffer.write(r.page(args.mode, args.cursor, args.budget, args.block_id))
    except (ContractError, UnicodeError, KeyError, TypeError, OSError, json.JSONDecodeError) as error:
        print(f'LOCAL_CONTRACT_ERROR: {error}', file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
