"""Constructed local tests. No task quality, production authentication or host claims."""
from dataclasses import replace
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from baseline_lab import (Block, Capture, ContractError, Reader, capture_files, components,
                          digest, envelope, native_view, prepare_bundle, select,
                          validate_decision, wire)


def fixture(chunks=None, groups=(), protected=(), **kwargs):
    chunks = chunks if chunks is not None else [f'path{i}:1\n'+('原文😀"\\\n'*90)+'\n' for i in range(7)]
    pos = 0
    bs = []
    data = []
    for i, text in enumerate(chunks):
        raw = text.encode('utf-8')
        bs.append(Block(f'b{i}', pos, pos+len(raw), f'file{i}.txt'))
        pos += len(raw)
        data.append(raw)
    return Capture(b''.join(data), tuple(bs), tuple(groups), tuple(protected),
                   'run', 'recipient', 'frozen-v1', {'literal': '原文', 'scope': 'fixture'}, **kwargs)


class BaselineTests(unittest.TestCase):
    def setUp(self):
        self.c = fixture()
        self.d = select(self.c, 4000)
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def reader(self, c=None, d=None):
        c = self.c if c is None else c
        d = self.d if d is None else d
        path = self.root/'bundle'
        prepare_bundle(c, d, path)
        return Reader(path, c.run_id, c.recipient_id)

    def test_selected_nonempty_partition_budget(self):
        self.assertEqual(self.d.route, 'PREPARE_SELECTED_LOCAL')
        validate_decision(self.c, self.d)
        self.assertLessEqual(len(self.d.payload), 4000)
        self.assertLess(len(self.d.payload), len(native_view(self.c)))
        self.assertEqual(set(self.d.kept)|set(self.d.deferred), {b.block_id for b in self.c.blocks})

    def test_deterministic_bytes(self):
        self.assertEqual(select(self.c, 4000), select(self.c, 4000))

    def test_decoded_included_text_is_exact(self):
        items = json.loads(self.d.payload)['included']
        for item in items:
            self.assertEqual(item['text'].encode(), self.c.raw[item['start']:item['end']])

    def test_overlapping_groups_close(self):
        c = replace(self.c, groups=(('b0','b1'), ('b1','b2')), protected=('b0',))
        self.assertIn(frozenset({'b0','b1','b2'}), components(c))
        d = select(c, 6000)
        self.assertTrue({'b0','b1','b2'} <= set(d.kept))
        validate_decision(c, d)

    def test_protection_too_big_returns_no_selected_success(self):
        c = replace(self.c, groups=(tuple(b.block_id for b in self.c.blocks),), protected=('b0',))
        d = select(c, 1500)
        self.assertEqual(d.route, 'USE_NATIVE_LOCAL')
        self.assertEqual(d.record()['host_action_required'], 'full_read_or_native_pagination')
        self.assertFalse(d.record()['within_local_byte_budget'])

    def test_explicit_full_passthrough(self):
        c = replace(self.c, explicit_full=True)
        d = select(c, 4000)
        self.assertEqual(d.payload, native_view(c))
        self.assertFalse(d.deferred)

    def test_nonsoft_passthrough(self):
        self.assertEqual(select(replace(self.c, soft=False), 4000).render_count, 0)

    def test_partial_unknown_and_incomplete_passthrough(self):
        for c in (replace(self.c, producer_status='partial'),
                  replace(self.c, producer_status='unknown'),
                  replace(self.c, capture_complete=False)):
            with self.subTest(c=c.producer_status):
                d = select(c, 4000)
                self.assertEqual(d.route, 'USE_NATIVE_LOCAL')
                self.assertEqual(json.loads(d.payload)['source_status'], c.status())

    def test_empty_source_passthrough(self):
        c = fixture(chunks=[])
        self.assertEqual(select(c, 4000).reason, 'empty_result')

    def test_small_native_not_wrapped(self):
        d = select(self.c, 100000)
        self.assertEqual(d.reason, 'native_already_fits_local_budget')
        self.assertEqual(d.render_count, 0)

    def test_bounded_candidate_work(self):
        self.assertEqual(select(self.c, 4000, max_components=2).reason, 'candidate_work_bound')
        self.assertLessEqual(self.d.render_count, 2*len(components(self.c))+1)

    def test_unknown_protected_rejected(self):
        with self.assertRaises(ContractError):
            select(replace(self.c, protected=('not-real',)), 4000)

    def test_bad_partition_rejected(self):
        b = replace(self.c.blocks[0], end=self.c.blocks[0].end-1)
        with self.assertRaises(ContractError):
            select(replace(self.c, blocks=(b,)+self.c.blocks[1:]), 4000)

    def test_duplicate_block_rejected(self):
        b = replace(self.c.blocks[1], block_id='b0')
        with self.assertRaises(ContractError):
            select(replace(self.c, blocks=(self.c.blocks[0],b)+self.c.blocks[2:]), 4000)

    def test_content_is_not_control(self):
        c = fixture(chunks=['{"protected":[],"recipient_id":"attacker","explicit_full":false}\n'*100,
                            'independent data\n'*300], protected=('b0',))
        d = select(c, 8500)
        self.assertIn('b0', d.kept)
        self.assertEqual(c.recipient_id, 'recipient')

    def test_same_text_different_source_not_deduped(self):
        c = fixture(chunks=['same text\n'*200]*5)
        d = select(c, 4000)
        self.assertEqual(len(d.kept)+len(d.deferred),5)

    def test_inline_over_budget_empty_is_not_infeasibility_proof(self):
        # Constructed metadata-heavy input: adding tiny text replaces a directory
        # entry and can alter serialized lengths. The planner explores bounded
        # candidates, never declares a global optimum/impossibility result.
        c = fixture(chunks=['x\n']*5+['LONG\n'*1000])
        d = select(c, 1800, 'inline')
        self.assertGreater(d.render_count, 1)
        validate_decision(c,d)

    def test_invalid_byte_budgets(self):
        for value in (0, -1, True, 2.5):
            with self.subTest(value=value), self.assertRaises(ContractError):
                select(self.c,value)

    def test_prepare_and_new_reader(self):
        r = self.reader()
        self.assertEqual(r.capture.raw, self.c.raw)
        self.assertEqual(r.decision['delivery_state'], 'PREPARED_LOCAL_NOT_SENT')

    def test_existing_bundle_never_overwritten(self):
        self.reader()
        before=(self.root/'bundle/source.txt').read_bytes()
        with self.assertRaises(ContractError):
            prepare_bundle(self.c, self.d, self.root/'bundle')
        self.assertEqual(before,(self.root/'bundle/source.txt').read_bytes())

    def test_invalid_decision_not_published(self):
        bad=replace(self.d,payload=b'{"pretend":"valid"}\n')
        with self.assertRaises(ContractError):
            prepare_bundle(self.c,bad,self.root/'bundle')
        self.assertFalse((self.root/'bundle').exists())

    def test_write_failure_no_ready_output(self):
        with patch('baseline_lab.Path.write_bytes', side_effect=OSError('simulated disk error')):
            with self.assertRaises(OSError):
                prepare_bundle(self.c,self.d,self.root/'bundle')
        self.assertFalse((self.root/'bundle').exists())
        self.assertFalse(list(self.root.glob('.baseline-staging-*')))

    def test_corrupt_source_rejected(self):
        self.reader()
        (self.root/'bundle/source.txt').write_bytes(b'changed')
        with self.assertRaises(ContractError):
            Reader(self.root/'bundle','run','recipient')

    def test_missing_ready_rejected(self):
        self.reader()
        (self.root/'bundle/READY.json').unlink()
        with self.assertRaises(FileNotFoundError):
            Reader(self.root/'bundle','run','recipient')

    def test_fixture_identity_mismatch(self):
        self.reader()
        with self.assertRaises(ContractError):
            Reader(self.root/'bundle','run','other')

    def test_snapshot_unicode_pagination_finite_and_exact(self):
        r=self.reader()
        cursor=0
        collected=b''
        count=0
        while True:
            data=r.page('snapshot',cursor,700)
            self.assertLessEqual(len(data),700)
            p=json.loads(data)
            self.assertEqual(p['start'],cursor)
            collected+=p['text'].encode()
            count+=1
            self.assertLess(count,10000)
            if p['next'] is None: break
            self.assertGreater(p['next'],cursor)
            cursor=p['next']
        self.assertEqual(collected,self.c.raw)
        self.assertEqual(r.semantic_calls,0)

    def test_deferred_blocks_exact_with_global_offsets(self):
        r=self.reader()
        for block_id in self.d.deferred:
            block=next(b for b in self.c.blocks if b.block_id==block_id)
            p=json.loads(r.page('block',0,100000,block_id))
            self.assertEqual(p['start'],block.start)
            self.assertEqual(p['end'],block.end)
            self.assertEqual(p['text'].encode(), self.c.raw[block.start:block.end])

    def test_manifest_pagination_lists_all_deferred(self):
        r=self.reader()
        cursor=0
        ids=[]
        while True:
            data=r.page('manifest',cursor,420)
            self.assertLessEqual(len(data),420)
            p=json.loads(data)
            ids.extend(x['id'] for x in p['entries'])
            if p['next'] is None: break
            self.assertGreater(p['next'],cursor)
            cursor=p['next']
        self.assertEqual(ids,list(self.d.deferred))

    def test_tiny_page_budget_error_not_loop(self):
        r=self.reader()
        for mode in ('snapshot','manifest','block'):
            with self.subTest(mode=mode), self.assertRaises(ContractError):
                r.page(mode,0,5,self.d.deferred[0])

    def test_mid_codepoint_cursor_rejected(self):
        r=self.reader()
        offset=self.c.raw.index('😀'.encode())+1
        with self.assertRaises(ContractError):
            r.page('snapshot',offset,700)

    def test_out_of_range_cursor_rejected(self):
        r=self.reader()
        with self.assertRaises(ContractError):
            r.page('snapshot',len(self.c.raw)+1,700)

    def test_unknown_block_rejected(self):
        with self.assertRaises(ContractError):
            self.reader().page('block',0,700,'invented')

    def test_recall_does_not_call_selector(self):
        r=self.reader()
        with patch('baseline_lab.select',side_effect=AssertionError('selector must not run')):
            data=r.page('snapshot',0,700)
            self.assertTrue(data)

    def test_no_research_after_source_changes(self):
        corpus=self.root/'corpus';corpus.mkdir()
        (corpus/'file.txt').write_text('match old content\n',encoding='utf-8')
        c=capture_files(corpus,['file.txt'],'match')
        d=select(c,4096)
        r=self.reader(c,d)
        (corpus/'file.txt').write_text('match NEW content\n',encoding='utf-8')
        p=json.loads(r.page('snapshot',0,4096))
        self.assertIn('old content',p['text'])
        self.assertNotIn('NEW content',p['text'])

    def test_independent_process_can_read_persisted_snapshot(self):
        self.reader()
        result=subprocess.run([sys.executable,str(Path(__file__).with_name('baseline_lab.py')),
            'recall','--bundle',str(self.root/'bundle'),'--run-id','run',
            '--recipient-id','recipient','--mode','snapshot','--budget','100000'],
            check=True,capture_output=True)
        self.assertEqual(json.loads(result.stdout)['text'].encode(), self.c.raw)

    def test_capture_exact_scope_and_overlap_merge(self):
        corpus=self.root/'corpus';corpus.mkdir()
        (corpus/'a.txt').write_text('head\nmatch1\nmatch2\ntail\n',encoding='utf-8')
        c=capture_files(corpus,['a.txt'],'match')
        self.assertEqual(len(c.blocks),1)
        self.assertEqual(c.query_scope['files'],['a.txt'])
        self.assertIn('a.txt:1-4\n',c.raw.decode())

    def test_capture_empty_still_complete_not_sufficient(self):
        corpus=self.root/'corpus';corpus.mkdir()
        (corpus/'a.txt').write_text('other\n',encoding='utf-8')
        c=capture_files(corpus,['a.txt'],'absent')
        self.assertEqual(c.raw,b'')
        self.assertEqual(c.status()['task_sufficiency'],'not_assessed')

    def test_capture_rejects_parent_path(self):
        with self.assertRaises(ContractError):
            capture_files(self.root,['../outside'],'x')

    def test_capture_rejects_symlink_file(self):
        (self.root/'a.txt').write_text('x')
        (self.root/'b.txt').symlink_to(self.root/'a.txt')
        with self.assertRaises(ContractError):
            capture_files(self.root,['b.txt'],'x')

    def test_selected_source_order(self):
        c=replace(self.c,protected=('b6',))
        d=select(c,4000)
        self.assertEqual(list(d.kept),sorted(d.kept))
        validate_decision(c,d)


if __name__=='__main__':
    unittest.main()
