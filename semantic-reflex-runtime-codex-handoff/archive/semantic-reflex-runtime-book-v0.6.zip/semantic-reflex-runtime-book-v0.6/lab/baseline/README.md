# 确定性 B 离线贯通实验室

> Python 3.10+ 标准库。本地只读文档搜索、选择、保存与脚本召回。没有 agent、语义模型、真实宿主、网络请求或付费调用。

这不是可安装生产插件。`--run-id` / `--recipient-id` 是**可信测试场景参数，不是认证**；本地摘要不是签名；新目录重命名不是跨崩溃、跨进程并发或跨宿主的事务保证。不要用本 CLI 处理非可信多租户读取。

## 1. 文件入口

| 文件 | 用途 |
|---|---|
| [baseline_lab.py](baseline_lab.py) | 规则候选、完整表示计量、局部保存、原文与目录分页 |
| [test_baseline_lab.py](test_baseline_lab.py) | 构造的机械合同与普通文件/子进程检查 |
| [run_checks.py](run_checks.py) | 重跑并写入实际检查记录 |
| [run_diagnostics.py](run_diagnostics.py) | 冻结语料上的只读查询和两条脚本恢复策略 |
| [语料清单](corpus/CORPUS_MANIFEST.json) | v0.3 模块文档原字节与来源哈希，不是外部研究 |
| [诊断表](diagnostics/REPORT.md) | 全部 18 个相关配置；不是 18 个独立任务 |
| [机器报告](diagnostics/report.json) | 第一响应、两条恢复路径、未知 token/费用/结果 |

## 2. 重跑

在资料包根目录执行：

```bash
python lab/baseline/run_checks.py
python lab/baseline/run_diagnostics.py --out /tmp/srr-v04-diagnostics-new
```

诊断输出必须是一个不存在的新目录，避免把旧产物当新结果。依赖只有标准库，不下载模型、不安装软件、不读取语料目录以外的默认文件。实际 source capture 只读取显式给定的相对 UTF-8 文件。

手工准备一个固定输入的局部信封：

```bash
python lab/baseline/baseline_lab.py prepare \
  --capture lab/baseline/diagnostics/q01-recall/capture.json \
  --out /tmp/srr-v04-prepared-new --budget 4096 --directory paged
```

从包内已有诊断产物读取第一页。身份参数仅匹配实验绑定：

```bash
python lab/baseline/baseline_lab.py recall \
  --bundle lab/baseline/diagnostics/q01-recall/budget-4096-paged \
  --run-id q01-recall --recipient-id scripted-reader \
  --mode manifest --cursor 0 --budget 2048
```

读取完整旧快照的第一页：

```bash
python lab/baseline/baseline_lab.py recall \
  --bundle lab/baseline/diagnostics/q01-recall/budget-4096-paged \
  --run-id q01-recall --recipient-id scripted-reader \
  --mode snapshot --cursor 0 --budget 2048
```

继续读取用返回的 `next` 作为游标；`null` 才是该范围终点。block 模式另传 `--block-id`。游标切在 UTF-8 码点中间、项目无法装入页、引用损坏或范围非法会明确失败，不返回永不前进的页面。不会因范围错误重跑搜索。

## 3. 选择算法的有限承诺

输入块是显示快照的完整字节分区；声明的结构组求连接闭包，保护闭包先保留。规则检查源序 first-fit 与一个源序前缀候选路径，每个配置最多考察约两倍结构组数；默认上限 128 组，超过则退出。

候选都用实际 JSON UTF-8 编码测量：包含状态、引用、目录、原文和换行。比较只针对这份本地表示，不能按“一字节等于一个 token”换算。合法但不可容纳的情形不寻找语义后端补救。

局部代码不是最优装箱器，没有证明分块语义充分；同一文档组只是保守的诊断选择。复杂度上界限制候选数，不等于输入字节、解析内存或单次序列化耗时完全受生产资源治理。生产适配另需真实大小/超时/容量门。

## 4. 保存与交付的边界

`prepare_bundle` 写 source、capture、decision、envelope 和 READY 校验记录到一个新目录，不覆盖已有输出。正常文件重开和子进程读取已测试。READY 表示本地准备状态，永远不是宿主交付回执。

关闭新 prepare 不影响读取已存在目录，但本样机没有生产 Feature Flag、实时撤权、retention 服务、加密、多写者锁、fsync 持久化协议或租户 ACL。用户提供的同机自报身份不可直接用于线上认证。

所有文件的 SHA256 只检测相对本地清单的字节变化，无法阻止有写权限的人同时篡改文件和清单。捕获器不是操作系统 sandbox，也没有证明对恶意文件树并发变化安全。

## 5. 恢复与测量

诊断的第一路径明确遍历延后目录，并逐块取回所有延后内容；第二路径明确分页取全快照。后者可能重复首次已显示内容，两条路径不相加。

恢复记录有精确响应字节和页数，但没有实际请求 token、未来 prompt 复读、KV/prompt cache、模型推理、网络、计费或任务标签。脚本知道自己的读取计划，不能代替 agent 是否会意识到遗漏的研究。

多块批量请求是架构允许的接口语义，当前本地代码只有单块与全快照；不得因为有这些模式就声称批量读取实现已完整。宿主原生等价能力优先复用。

## 6. 当前进度

这是 W0 的实际代码/文件诊断和 W3 的前置候选。不是 E0 真实模型请求证明，不是 E2 强基线选择，不是 E4 完整任务实验。40 项新检查与旧合同/分析测试分别记录，不能加总成生产覆盖率。
