# §04 State Capsule、证据与原文管理

> 状态：最小协议 Draft。约定逻辑归属，不锁数据库、语言或传输标准。

## 0. 定位与来源

材料提出 State Capsule、Hard Context / Soft Context 与可恢复披露；ValueHermes 提供状态/过程证据分工和大对象 handle 的参考。本章采用这些思想，但不继承其业务表或三库实现。[D1](../../../references/discussions/D1-excerpts.md)；[D2](../../../references/discussions/D2-runtime-kernel-cache.md)；[V3](../../../references/valuehermes/03-domain-state-store.md)；[V4 §1.3](../../../references/valuehermes/11-aci-telemetry.md)

## 1. 四类对象不能混淆

| 对象 | 意义 | 不能替代 |
|---|---|---|
| Source Snapshot | 在某时点捕获的、经既有权限/消毒后可交付内容 | 当前文件的新版本、隐藏的更高权限原始数据 |
| Source Block | 对同一快照中一段精确原文的定位 | 模型生成摘要或“意思相同”的另一段文字 |
| State Capsule | 当时已知的任务、接收方、明确约束和覆盖状态 | 主模型隐藏思考、未来验收答案 |
| Recipient View | 某个接收方实际获交付的块与版本 | 系统全部知道的东西或其他 agent 看过的内容 |

源快照建议保存宿主原本允许交付的返回表示，不能绕过既有保密消毒去保存更多。哈希描述该固定表示；换编码、换结构化序列化版本必须显式说明，不能把不同表示误判为同一内容。

## 2. Source Snapshot 的最小字段族（主定义）

`source_id`：稳定身份；`origin_call_id`：来源调用；`run_id / scope_ref`：任务和授权归属；`captured_at / source_version`：捕获时间与底层版本；`representation`：内容类型/编码/结构化序列化标识；`content_hash`：该表示的内容哈希；`byte_length`：字节规模；`capture_complete / producer_status / query_scope`：按 §8 分别表达捕获、生产方和查询范围，另有 `incompleteness_reason`；`retention_state`：当前可用状态。旧 `complete` 仅作为历史样例字段保留。

首版文本块用 `(source_id, block_id, byte_start, byte_end)`，区间为半开 `[start,end)`，UTF-8 切分不能落在码点中间；显示行号仅作辅助。保留工具结构、标题和相邻约束，不能逐行拆散一个错误或引用上下文。分块算法和表示版本一起记录。

哈希只能检查字节一致性，不证明内容事实正确；同一个哈希也不赋予读取权限。

## 3. State Capsule 的最小字段族（主定义）

必需：`run_id / event_id / recipient_id / state_revision`、当前任务合同引用与已有简要目标、工具名及实际查询参数、源快照引用、显式保护规则引用、当前已知接收视图、可观察覆盖状态。

可选：宿主或 agent 已明确给出的 subgoal、open question、近期有限窗口的确定性事实。缺失记为 unknown，不每次再叫一个模型补出漂亮状态摘要。

输入当前猜测时必须标记其为 hypothesis，而不是源事实；不能让分类器只按该猜测过滤。构造状态有独立预算，超预算或必要状态缺失可回基线。

评测用的最终修复文件、隐藏验收测试、事后标签不得进入在线 State Capsule。

## 4. Hard / Soft 的声明权

Hard Context 来自用户、宿主权限规则、Director / Task Brief 的明确合同，不来自筛选模型自己的高分。既有 Required Reads、当前失败证据、明确点名或要求全文的内容不能被 selector 降级。

本切片只接受明确标记为 soft 的搜索结果范围。没有 Hard 标记不等于已证明不重要；它只是允许在试验约束下考虑延后，不是语义安全证书。

若无法区分结果是否包含不可省略内容，旁路筛选。若保护内容超过预算，返回明确溢出/完整读取路径，不为了满足预算裁掉硬内容。

## 5. 延后必须先有可恢复来源

准备顺序：保存并确认源快照 → 确定分块 → 保存本次划分与最小决策记录 → 交付信封。不能先省略再“稍后尽量保存”。

首版推荐单 run 范围保留：有效 run 内源不可被普通容量淘汰；容量不足时新事件回基线。任务终止后可按显式规则失效，handle 不能宣称永久有效。权限撤回优先于保留承诺；失效应能报告真实原因。

源对象存储与普通 telemetry 轮转分开管理：完整过程日志可减少，但不能在 live handle 仍有效时删除对应源。保留实验所需快照仍受权限与数据保留要求限制；不能为了复现无限保存敏感材料。

## 6. 版本与接收方隔离

Recall 取旧快照，不自动读当前文件。`source_version` 已过时时应把“历史快照”事实告诉接收方；要查新状态走新工具请求，而不是把新内容伪装成旧召回。

去重至少绑定来源版本和接收视图。文本相同但来自不同测试运行、不同来源或不同时间，不自动视为冗余。可以折叠同一来源的重叠字节窗口，但必须保留命中位置/次数的语义，不能抹掉独立验证证据。

## 7. 验证与未决

硬测试包括原文精确取回、Unicode 区间、不可见来源拒绝、权限撤回、快照过期、不同接收方不串读、缺失源不静默重跑、不能把截断结果标完整、保留期内不淘汰 live handle。

Q04–Q06：谁在实际宿主声明 Hard/Soft；状态版本如何取；源存储可否直接复用；任务结束、compaction 和权限更新如何通知，均待接入验证。这里确定的是需要这些语义，不是已知宿主字段。

## 8. v0.2：拆开五种完整性，避免 complete 语义过载

| 维度 | 主记录位置 | 允许表达 | 禁止推导 |
|---|---|---|---|
| 捕获完整性 `capture_complete` | Source Snapshot | 完整捕获这次可交付返回，没有截断其字节 | 工具发现了所有匹配项 |
| 生产方完整性 `producer_status` | Source Snapshot 的工具状态 | 工具声明 complete / partial / unknown，并保留限制 | 工具声明一定正确 |
| 查询范围 `query_scope` | Snapshot / Capsule | 实际目录、过滤、权限、游标与限额 | 全仓库或所有相关资源均已搜索 |
| 当前展示 `presentation_kind` | §08 Envelope | full_snapshot / selected_snapshot | 当前展示足够完成任务 |
| 任务充分性 | 原任务验收，不由本层授予 | 外部验证的证据与尚未解决的问题 | 因为前三项 complete 就足够 |

v0.1 的 `complete` 在旧样例中仅表示捕获完整性，v0.2 不用它同时表示五层含义。新推荐 wire 名 `capture_complete`，生产方状态单列。旧 `full/selected` 可映射到新显式名称，但跨版本须记录表示版本，不能静默改变老字段意思。

本轮首发筛选要求 `capture_complete=true` 且生产方状态可确认为该查询的完整返回；unknown/partial 保留限制并旁路。不保证查询参数已经涵盖所有相关文件。抓到的是搜索片段时，recall 只能恢复该片段，读取完整文件是新的工具动作。

## 9. v0.2：暴露、使用与理解不是同一字段

`Recipient View` 推荐改称交付视图，其事实状态只有 prepared、delivery_confirmed、delivery_unknown 等。工具调用/后续显式引用可以记录为 use evidence，但不能把提交回执写成“已理解”。

后续 novelty 或重复判断不得用 delivery_unknown 当已读；也不得把另一个 agent 的 delivery_confirmed 当本接收方可省略的理由。即使该接收方确实获得过内容，compaction 后是否仍在可用上下文中也须有宿主证据，不能把历史暴露自动当当前可用。

## 10. v0.2：保留与释放的条件

源在发布句柄之前准备好。交付未知的记录保守保留到宿主完成核对或到明示合同允许的失效点；不为释放容量擅自认定未交付。失效原因、权限拒绝与源不存在在内部区分，对未授权调用方可按既有政策隐藏存在性。

run 范围保留不是无限期保留：上限、任务结束判据及例外必须写进部署合同。权限撤回可令读取立即不可用；保留字节本身是否合法仍服从宿主数据要求，本章不替代数据政策。

## 11. v0.3：字节块与结构关联组

Source Block 提供原文定位和字节保真；Selection Group 表达本次不可拆的确定性结构关联。组可包含多个块，重叠关系需求闭包，不能把一个块既作为单体延期又作为保护组的一部分。

明确保护集合 H 的来源仍是授权任务合同，语义后端无权减少它。块级 abstain 是本次策略保守约束，不把它升级为永久任务 Hard Context；下一事件仍按新状态与合同判断。具体选择和溢出分流归 §06/§08。

本版没有实现通用 AST 或全仓库依赖图。无法可靠确定组边界时，可以退出筛选，而不是假定相邻文本互不依赖。
