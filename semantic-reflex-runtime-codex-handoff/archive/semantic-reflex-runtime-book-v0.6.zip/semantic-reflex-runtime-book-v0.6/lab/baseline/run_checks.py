"""Persist actual local baseline test results. Not an E0/E2 quality pass."""
from pathlib import Path
import io
import json
import platform
import unittest

root=Path(__file__).resolve().parent
suite=unittest.defaultTestLoader.discover(str(root),pattern='test_*.py')
stream=io.StringIO()
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
(root/'check-results.txt').write_text(stream.getvalue(),encoding='utf-8')
report={'kind':'offline_deterministic_baseline_and_local_file_checks',
        'python':platform.python_version(),'tests_run':result.testsRun,
        'failures':len(result.failures),'errors':len(result.errors),
        'successful':result.wasSuccessful(),
        'not_tested':['real_host','semantic_quality','actual_permissions','crash_durability',
                     'real_tokens','cache_billing','task_success','production_security']}
(root/'check-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(stream.getvalue())
print(json.dumps(report,indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
