"""Finite, in-memory model of the architecture draft; NOT a Runtime implementation.

No host integration, network, model calls, durable writes, or OS authorization.
All identity and authorization inputs are trusted test fixtures. Python 3.10+.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from hashlib import sha256
import math
from typing import Any, Iterable
from uuid import uuid4


class ContractError(ValueError):
    """A modeled contract was violated."""


class AccessDenied(ContractError):
    pass


class SourceUnavailable(ContractError):
    pass


class DeliveryUnknown(ContractError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ContractError(message)


@dataclass(frozen=True)
class Block:
    block_id: str
    start: int
    end: int


@dataclass(frozen=True)
class Snapshot:
    source_id: str
    run_id: str
    raw: bytes
    blocks: tuple[Block, ...]
    capture_complete: bool = True
    producer_status: str = 'complete'
    query_scope: str = 'fixture only'
    content_hash: str = field(init=False)

    def __post_init__(self) -> None:
        require(bool(self.source_id and self.run_id), 'missing source identity')
        require(isinstance(self.raw, bytes), 'source must be immutable bytes')
        require(self.producer_status in {'complete', 'partial', 'unknown'}, 'bad producer status')
        require(len({b.block_id for b in self.blocks}) == len(self.blocks), 'duplicate block IDs')
        cursor = 0
        for block in self.blocks:
            require(type(block.start) is int and type(block.end) is int, 'noninteger range')
            require(bool(block.block_id) and block.start == cursor and
                    block.start < block.end <= len(self.raw), 'invalid partition')
            try:
                self.raw[block.start:block.end].decode('utf-8')
            except UnicodeDecodeError as error:
                raise ContractError('invalid UTF-8 boundary') from error
            cursor = block.end
        require(cursor == len(self.raw), 'partition does not cover snapshot')
        object.__setattr__(self, 'content_hash', sha256(self.raw).hexdigest())

    def block_bytes(self, block_id: str) -> bytes:
        for block in self.blocks:
            if block.block_id == block_id:
                return self.raw[block.start:block.end]
        raise ContractError('unknown block')


@dataclass(frozen=True)
class Identity:
    run_id: str
    recipient_id: str
    authorization_revision: int


class MemoryAccess:
    """A fake authorization oracle, not a real identity/ACL integration."""

    def __init__(self) -> None:
        self.revisions: dict[str, int] = {}
        self.grants: set[tuple[str, str, str]] = set()

    def grant(self, source_id: str, identity: Identity) -> None:
        self.revisions[identity.run_id] = identity.authorization_revision
        self.grants.add((identity.run_id, identity.recipient_id, source_id))

    def allowed(self, source_id: str, identity: Identity) -> bool:
        return (self.revisions.get(identity.run_id) == identity.authorization_revision and
                (identity.run_id, identity.recipient_id, source_id) in self.grants)

    def revoke(self, source_id: str, identity: Identity) -> None:
        self.grants.discard((identity.run_id, identity.recipient_id, source_id))
        self.revisions[identity.run_id] = self.revisions.get(identity.run_id, 0) + 1


@dataclass(frozen=True)
class Binding:
    run_id: str
    call_id: str
    recipient_id: str
    source_id: str
    source_hash: str
    decision_context_revision: str
    authorization_revision: int
    config_revision: str

    @property
    def identity(self) -> Identity:
        return Identity(self.run_id, self.recipient_id, self.authorization_revision)


@dataclass(frozen=True)
class Envelope:
    binding: Binding
    kept: tuple[tuple[str, str], ...]
    deferred: tuple[str, ...]
    protected: frozenset[str]
    presentation_kind: str

    def validate(self, snapshot: Snapshot) -> None:
        require(snapshot.capture_complete and snapshot.producer_status == 'complete',
                'this selected path requires complete capture and producer response')
        require(self.binding.source_id == snapshot.source_id and
                self.binding.source_hash == snapshot.content_hash and
                self.binding.run_id == snapshot.run_id, 'source binding mismatch')
        universe = {b.block_id for b in snapshot.blocks}
        kept_ids = [item[0] for item in self.kept]
        require(len(kept_ids) == len(set(kept_ids)), 'duplicate kept block')
        require(len(self.deferred) == len(set(self.deferred)), 'duplicate deferred block')
        kept, deferred = set(kept_ids), set(self.deferred)
        require(not (kept & deferred) and kept | deferred == universe, 'invalid view partition')
        require(self.protected <= kept, 'protected block deferred or nonexistent')
        require(self.presentation_kind == ('selected_snapshot' if deferred else 'full_snapshot'),
                'dishonest presentation kind')
        for block_id, text in self.kept:
            require(text == snapshot.block_bytes(block_id).decode('utf-8'), 'rewritten excerpt')


class Phase(str, Enum):
    CAPTURED = 'CAPTURED'
    PREPARED = 'PREPARED'
    COMMITTING = 'COMMITTING'
    DELIVERED = 'DELIVERED'
    CANCELLED = 'CANCELLED'
    DELIVERY_UNKNOWN = 'DELIVERY_UNKNOWN'


class DeliverySlot:
    """Single-thread finite model: no distributed exactly-once guarantee."""

    def __init__(self, binding: Binding) -> None:
        self.binding = binding
        self.phase = Phase.CAPTURED
        self.send_attempts = 0

    def prepare(self, *, source_ready: bool, decision_saved: bool) -> None:
        require(self.phase == Phase.CAPTURED, 'prepare in wrong state')
        require(source_ready and decision_saved, 'not recoverable before publishing')
        self.phase = Phase.PREPARED

    def begin_send(self, current: Binding, access: MemoryAccess, *, enabled: bool = True) -> bool:
        if self.phase == Phase.DELIVERY_UNKNOWN:
            raise DeliveryUnknown('host reconciliation required; do not resend')
        if self.phase == Phase.DELIVERED:
            return False
        require(self.phase == Phase.PREPARED, 'send in wrong state')
        require(enabled, 'new admission disabled')
        require(current == self.binding, 'stale decision binding')
        if not access.allowed(current.source_id, current.identity):
            raise AccessDenied('authorization changed')
        self.send_attempts += 1
        self.phase = Phase.COMMITTING
        return True

    def confirm_delivered(self) -> None:
        if self.phase == Phase.DELIVERED:
            return
        require(self.phase in {Phase.COMMITTING, Phase.DELIVERY_UNKNOWN}, 'invalid confirmation')
        self.phase = Phase.DELIVERED

    def cancel(self) -> None:
        if self.phase in {Phase.CAPTURED, Phase.PREPARED}:
            self.phase = Phase.CANCELLED
        elif self.phase == Phase.COMMITTING:
            self.phase = Phase.DELIVERY_UNKNOWN
        # A cancellation cannot undo a confirmed or ambiguous external delivery.

    def confirmation_lost(self) -> None:
        require(self.phase == Phase.COMMITTING, 'no pending external send')
        self.phase = Phase.DELIVERY_UNKNOWN


@dataclass(frozen=True)
class Page:
    data: bytes
    first_block: int
    next_block: int
    next_cursor: str | None
    source_hash: str


class MemoryRecall:
    """In-memory reference resolver. Tokens model opaque cursors, not production security."""

    def __init__(self, access: MemoryAccess) -> None:
        self.access = access
        self.sources: dict[str, Snapshot] = {}
        self.handles: dict[str, str] = {}
        self.expired: set[str] = set()
        self.active: set[str] = set()
        self.cursors: dict[str, tuple[str, Identity, int, int]] = {}
        self.admission_enabled = True
        self.selector_calls = 0

    def register(self, snapshot: Snapshot) -> str:
        require(snapshot.source_id not in self.sources, 'source IDs immutable')
        self.sources[snapshot.source_id] = snapshot
        self.active.add(snapshot.source_id)
        handle = 'h_' + uuid4().hex
        self.handles[handle] = snapshot.source_id
        return handle

    def resolve(self, handle: str, identity: Identity) -> Snapshot:
        source_id = self.handles.get(handle)
        if source_id is None or not self.access.allowed(source_id, identity):
            raise AccessDenied('unavailable to this caller')
        source = self.sources.get(source_id)
        if source is None or source_id in self.expired:
            raise SourceUnavailable('expired or missing authorized source')
        if source.run_id != identity.run_id:
            raise AccessDenied('wrong run')
        return source

    def recall_block(self, handle: str, identity: Identity, block_id: str) -> bytes:
        return self.resolve(handle, identity).block_bytes(block_id)

    def page(self, handle: str, identity: Identity, *, page_blocks: int = 1,
             cursor: str | None = None) -> Page:
        source = self.resolve(handle, identity)
        require(type(page_blocks) is int and page_blocks > 0, 'invalid page size')
        position = 0
        if cursor is not None:
            value = self.cursors.get(cursor)
            require(value is not None, 'unknown cursor')
            expected_handle, expected_identity, position, expected_size = value
            require(expected_handle == handle and expected_identity == identity and
                    expected_size == page_blocks, 'cursor scope changed')
        end = min(position + page_blocks, len(source.blocks))
        data = b''.join(source.block_bytes(b.block_id) for b in source.blocks[position:end])
        next_cursor = None
        if end < len(source.blocks):
            next_cursor = 'c_' + uuid4().hex
            self.cursors[next_cursor] = (handle, identity, end, page_blocks)
        return Page(data, position, end, next_cursor, source.content_hash)

    def expire(self, source_id: str) -> None:
        self.expired.add(source_id)
        self.active.discard(source_id)

    def evict(self, source_id: str) -> None:
        require(source_id not in self.active, 'cannot evict active source')
        self.sources.pop(source_id, None)


def validate_signal(payload: dict[str, Any], input_ids: set[str]) -> None:
    allowed = {'label', 'evidence_refs', 'score'}
    require(set(payload) <= allowed and {'label', 'evidence_refs'} <= set(payload),
            'unexpected or missing signal fields')
    require(payload['label'] in {'prefer', 'defer_candidate', 'abstain'}, 'unknown label')
    refs = payload['evidence_refs']
    require(isinstance(refs, list) and all(isinstance(ref, str) for ref in refs), 'bad references')
    require(set(refs) <= input_ids, 'reference outside input')
    if 'score' in payload:
        score = payload['score']
        require(type(score) in {int, float} and math.isfinite(score) and 0 <= score <= 1,
                'invalid illustrative score; not a calibrated probability')


@dataclass(frozen=True)
class Attempt:
    outcome: str
    cost: float | None

    def __post_init__(self) -> None:
        require(self.outcome in {'success', 'failure', 'unknown'}, 'invalid outcome')
        if self.cost is not None:
            require(type(self.cost) in {int, float} and math.isfinite(self.cost) and
                    self.cost >= 0, 'invalid cost')


def account(attempts: Iterable[Attempt]) -> dict[str, int | float | None]:
    rows = list(attempts)
    successes = sum(row.outcome == 'success' for row in rows)
    unknowns = sum(row.outcome == 'unknown' for row in rows)
    missing = sum(row.cost is None for row in rows)
    total = None if missing else sum(row.cost for row in rows if row.cost is not None)
    return {'attempts': len(rows), 'successes': successes, 'unknown_outcomes': unknowns,
            'missing_costs': missing, 'total_cost': total,
            'cost_per_verified_success': total / successes if total is not None and successes else None}
