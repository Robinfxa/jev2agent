"""Run the local finite-model tests and persist their actual results."""
from pathlib import Path
import io
import json
import platform
import unittest

base = Path(__file__).resolve().parent
suite = unittest.defaultTestLoader.discover(str(base), pattern='test_*.py')
stream = io.StringIO()
result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
text = stream.getvalue()
(base/'check-results.txt').write_text(text, encoding='utf-8')
report = {'kind':'constructed_in_memory_contract_checks', 'python':platform.python_version(),
          'tests_run':result.testsRun, 'failures':len(result.failures), 'errors':len(result.errors),
          'skipped':len(result.skipped), 'successful':result.wasSuccessful(),
          'not_tested':['real_host','semantic_model','real_authorization','disk_crash_consistency',
                        'network_races','token_cache_billing','task_success','production_security']}
(base/'check-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(text)
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
