#!/usr/bin/env python3
"""Run offline reporting checks and two synthetic CLI examples."""
from pathlib import Path
import io,json,platform,subprocess,sys,unittest
from datetime import datetime,timezone

base=Path(__file__).resolve().parent
sys.path.insert(0,str(base))
suite=unittest.defaultTestLoader.discover(str(base),pattern='test_experiment_analysis.py')
stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
text=stream.getvalue();cli=[]
for name in ('package_cost','missing_outcome'):
    p=base/'fixtures'/name
    proc=subprocess.run([sys.executable,str(base/'experiment_analysis.py'),
        '--manifest',str(p/'manifest.json'),'--cohort',str(p/'cohort.json'),
        '--results',str(p/'results.jsonl'),'--output',str(p/'report.json')],
        capture_output=True,text=True,timeout=15)
    cli.append({'fixture':name,'returncode':proc.returncode,'stdout':proc.stdout.strip(),'stderr':proc.stderr.strip()})
report={'version':'0.3','kind':'offline_descriptive_analysis_contract_checks',
        'executed_at_utc':datetime.now(timezone.utc).isoformat(),'python':platform.python_version(),
        'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skipped':len(result.skipped),'synthetic_cli_runs':cli,
        'successful':result.wasSuccessful() and all(row['returncode']==0 for row in cli),
        'not_tested':['real_agent_outcomes','real_billing','semantic_model','host_integration',
                      'authority_of_evidence_refs','sampling_confidence_intervals','automatic_promotion']}
(base/'check-results.txt').write_text(text+'\n'+json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(base/'check-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(text);print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if report['successful'] else 1)
