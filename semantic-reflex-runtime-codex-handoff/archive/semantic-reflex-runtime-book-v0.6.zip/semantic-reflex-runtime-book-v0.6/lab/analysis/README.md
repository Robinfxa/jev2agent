# 离线实验分析实验室

**v0.3｜Python 3.10+ 标准库｜描述性分析工具，不是 agent Runtime 或统计验收器。**

## 用途

检查冻结名册和结果是否一一对应；内部重试只计费用，不增加成功单位；未知验收保留识别范围；未结算费用不伪装完整；分别报告 B/A、C/B、C/A。拒绝缺行、重复行、额外行、混币种、非有限金额、缺验收引用和错配起点。

所有示例均为手工 synthetic 数据，金额单位 `ILLUSTRATIVE_UNITS`，不是实际货币。fixture 配置和验收引用只是字符串，不证明真实验收独立。程序无网络、模型 API、秘密密钥或自动生产动作。

## 运行

在资料包根目录：

```bash
python lab/analysis/run_checks.py
```

该命令运行 42 项 unittest 方法（部分含多个输入 subtest），并用 CLI 生成两份描述报告；本轮已经实际执行。结果见 [检查 JSON](check-results.json) 与 [逐项日志](check-results.txt)。测试数量不是可靠性百分比。

单独分析一个包：

```bash
python lab/analysis/experiment_analysis.py \
  --manifest lab/analysis/fixtures/package_cost/manifest.json \
  --cohort lab/analysis/fixtures/package_cost/cohort.json \
  --results lab/analysis/fixtures/package_cost/results.jsonl \
  --output lab/analysis/fixtures/package_cost/report.json
```

需要重新生成手工数据时运行 `python lab/analysis/generate_fixtures.py`；该命令只重建已声明的两个 synthetic 目录，不运行 agent。

## 两个反例

[整包成本反例](fixtures/package_cost/report.json)：每臂 10 个构造任务均成功，A 总费 10、B 14、C 12；C/B 成本改善约 14.29%，C/A 则 −20%。这些是说明比较对象的重要性，不是项目收益。

[验收未知反例](fixtures/missing_outcome/report.json)：B=8 success+2 unknown，C=8 success+2 failure；已验证比例相同，C−B 的有限样本缺失识别范围为 [−0.2,0]。不是 95% 区间，也没有总体非劣结论。

## 文件合同与限制

参考 [E4 名册与分析合同](../../docs/experiments/E4-cohort-and-analysis.md)。严格输入字段见 `experiment_analysis.py`；未知字段拒绝，避免把自报 arm 或额外字段偷偷纳入。金额是有限非负 Decimal 字符串，null 表示未知，精度有明确边界；工具不换汇、不定价。hash 绑定名册字节，不证明冻结发生在运行之前。

仅支持平衡 case/replicate A/B/C、等权执行单位。多个相关实例和重复运行仍有簇相关性；工具只报告簇数，不估计总体置信区间、功效或多重性。报告把小数以字符串保留计算精度，不表示相应统计精确度。

始终输出 `promotion_eligible=false`，包括输入标为 measured/frozen 时。尾延迟、实际授权、真实验收、关键遗漏、维护成本和统计推断须另有证据。输入被拒绝返回非零退出码；下游必须检查退出码与 input_hashes，不能把原路径留存的旧报告当作新运行结果。
