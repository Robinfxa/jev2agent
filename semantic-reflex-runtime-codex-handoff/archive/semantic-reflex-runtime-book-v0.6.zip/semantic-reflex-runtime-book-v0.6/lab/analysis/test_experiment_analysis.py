"""Targeted contract and arithmetic checks, not empirical significance tests."""
from copy import deepcopy
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
import unittest

from experiment_analysis import AnalysisError,analyze,parse_json

BASE=Path(__file__).resolve().parent/'fixtures'


def load(name='package_cost'):
    folder=BASE/name; raw=(folder/'cohort.json').read_bytes()
    return (parse_json((folder/'manifest.json').read_text()),parse_json(raw.decode()),
            [parse_json(line) for line in (folder/'results.jsonl').read_text().splitlines()],raw)


def rebind(m,c):
    raw=(json.dumps(c,ensure_ascii=False,indent=2)+'\n').encode();m['cohort_sha256']=sha256(raw).hexdigest()
    return raw


def comparison(report,candidate,reference):
    return next(c for c in report['comparisons'] if c['candidate']==candidate and c['reference']==reference)


class AnalysisChecks(unittest.TestCase):
    def setUp(self): self.m,self.c,self.rows,self.raw=load()
    def run_report(self):return analyze(self.m,self.c,self.rows,self.raw)
    def refused(self):
        with self.assertRaises(AnalysisError):self.run_report()

    def test_package_incremental_win_is_not_total_win(self):
        r=self.run_report()
        self.assertGreater(Decimal(comparison(r,'C','B')['cost_gain_using_verified_success']),0)
        self.assertEqual(Decimal(comparison(r,'C','A')['cost_gain_using_verified_success']),Decimal('-.2'))

    def test_two_sided_unknown_assignment_can_mask_noninferiority_failure(self):
        r=analyze(*load('missing_outcome'));x=comparison(r,'C','B')
        self.assertEqual(x['verified_success_difference'],'0')
        self.assertEqual(x['quality_difference_missing_outcome_bounds'],['-0.2','0'])
        self.assertEqual(r['arms']['B']['quality_missing_outcome_bounds'],['0.8','1'])

    def test_never_automatic_promotion(self):self.assertFalse(self.run_report()['promotion_eligible'])
    def test_no_confidence_interval_claim(self):self.assertFalse(self.run_report()['missing_bounds_are_confidence_intervals'])
    def test_synthetic_and_draft_are_blockers(self):
        b=self.run_report()['limitations_and_blockers']
        self.assertIn('synthetic_data_not_effect_evidence',b);self.assertIn('manifest_not_frozen',b)

    def test_measured_frozen_label_still_cannot_promote(self):
        self.m.update(data_origin='measured',status='frozen',preregistration_ref='fixture-ref',freeze_ref='fixture-time')
        self.assertFalse(self.run_report()['promotion_eligible'])

    def test_missing_result_detected_against_plan(self):self.rows.pop();self.refused()
    def test_duplicate_result_rejected(self):self.rows.append(deepcopy(self.rows[0]));self.refused()
    def test_extra_result_rejected(self):
        r=deepcopy(self.rows[0]);r['unit_id']='unplanned';self.rows.append(r);self.refused()
    def test_duplicate_roster_identity(self):
        self.c.append(deepcopy(self.c[0]));self.raw=rebind(self.m,self.c);self.refused()
    def test_duplicate_slot_under_different_id(self):
        r=deepcopy(self.c[0]);r['unit_id']='different';self.c.append(r);self.raw=rebind(self.m,self.c);self.refused()
    def test_missing_arm_rejected_even_with_matching_results(self):
        uid=self.c.pop()['unit_id'];self.rows=[r for r in self.rows if r['unit_id']!=uid]
        self.raw=rebind(self.m,self.c);self.refused()
    def test_cohort_hash_binding(self):self.m['cohort_sha256']='0'*64;self.refused()
    def test_in_memory_cohort_must_match_frozen_bytes(self):self.c[0]['case_id']='modified';self.refused()
    def test_initial_snapshot_mismatch_rejected(self):
        self.c[0]['initial_state_ref']='other';self.raw=rebind(self.m,self.c);self.refused()
    def test_cluster_mismatch_rejected(self):
        self.c[0]['task_cluster']='other';self.raw=rebind(self.m,self.c);self.refused()
    def test_mixed_arm_config_rejected(self):
        self.c[0]['config_ref']='other';self.raw=rebind(self.m,self.c);self.refused()
    def test_boolean_replicate_rejected(self):
        self.c[0]['replicate']=True;self.raw=rebind(self.m,self.c);self.refused()
    def test_results_cannot_override_assigned_arm(self):self.rows[0]['assigned_arm']='C';self.refused()
    def test_success_without_verification_ref(self):self.rows[0]['acceptance_ref']=None;self.refused()
    def test_unknown_requires_reason(self):self.rows[0]['outcome']='unknown';self.refused()
    def test_not_started_cannot_be_success(self):self.rows[0]['execution_status']='not_started';self.refused()
    def test_not_started_zero_requires_closed_ledger(self):
        self.rows[0].update(execution_status='not_started',outcome='unknown',outcome_reason='not launched',
                            acceptance_ref=None,cost_segments=[],cost_status='complete')
        r=self.run_report()['arms']['A']
        self.assertEqual(r['assigned_units'],10);self.assertEqual(r['not_started'],1)
        self.assertEqual(r['unknown_outcomes'],1);self.assertEqual(r['total_cost'],'9')
    def test_incomplete_empty_ledger_is_not_zero(self):
        self.rows[0].update(cost_status='incomplete',cost_segments=[],reconciliation_ref=None)
        self.assertIsNone(self.run_report()['arms']['A']['total_cost'])
    def test_complete_missing_amount_rejected(self):self.rows[0]['cost_segments'][0]['amount']=None;self.refused()
    def test_missing_amount_retains_unknown_total_and_known_subtotal(self):
        self.rows[0]['cost_segments'][0]['amount']=None;self.rows[0]['cost_status']='incomplete'
        r=self.run_report()['arms']['A'];self.assertIsNone(r['total_cost']);self.assertEqual(r['known_cost_subtotal'],'9')
    def test_closed_ledger_needs_reconciliation(self):self.rows[0]['reconciliation_ref']=None;self.refused()
    def test_known_amount_needs_source(self):self.rows[0]['cost_segments'][0]['evidence_ref']=None;self.refused()
    def test_double_counting_segment_rejected(self):
        self.rows[1]['cost_segments'][0]['segment_id']=self.rows[0]['cost_segments'][0]['segment_id'];self.refused()
    def test_internal_retry_adds_cost_not_success(self):
        self.rows[0]['cost_segments'].append({'segment_id':'retry-extra','kind':'internal_retry','amount':'2','evidence_ref':'fixture'})
        r=self.run_report()['arms']['A'];self.assertEqual(r['total_cost'],'12');self.assertEqual(r['verified_success'],10)
    def test_zero_success_is_undefined(self):
        for row in self.rows:
            if row['unit_id'].endswith('-C'):row['outcome']='failure'
        r=self.run_report();self.assertIsNone(r['arms']['C']['cost_per_verified_success'])
        self.assertIsNone(comparison(r,'C','B')['cost_gain_using_verified_success'])
    def test_zero_reference_cost_does_not_invent_ratio(self):
        for row in self.rows:
            if row['unit_id'].endswith('-B'):row['cost_segments'][0]['amount']='0'
        self.assertIsNone(comparison(self.run_report(),'C','B')['cost_gain_using_verified_success'])
    def test_decimal_exact_subtotals(self):
        for row in self.rows:row['cost_segments'][0]['amount']='0.1'
        self.assertEqual(self.run_report()['arms']['A']['total_cost'],'1')
    def test_mixed_currency_rejected(self):self.rows[0]['currency']='OTHER';self.refused()
    def test_bad_amounts_rejected(self):
        for value in ['NaN','Infinity','-1','1e999','bad',1.2,True]:
            with self.subTest(value=value):
                self.rows[0]['cost_segments'][0]['amount']=value;self.refused()
    def test_incomplete_cost_removes_cost_comparison(self):
        self.rows[0]['cost_status']='incomplete';r=self.run_report()
        self.assertIsNone(comparison(r,'C','A')['cost_gain_using_verified_success'])
    def test_duplicate_json_key_rejected(self):
        with self.assertRaises(AnalysisError):parse_json('{"x":1,"x":2}')
    def test_json_nan_rejected(self):
        with self.assertRaises(AnalysisError):parse_json('{"x":NaN}')
    def test_unfrozen_label_cannot_fake_frozen(self):self.m['status']='frozen';self.refused()
    def test_bad_enum_type_rejected_cleanly(self):self.m['status']=[];self.refused()
    def test_row_order_does_not_change_descriptive_metrics(self):
        before=self.run_report();self.rows.reverse();self.assertEqual(before,self.run_report())
    def test_whole_cohort_replication_preserves_point_metrics_not_cluster_count(self):
        before=self.run_report();old_c=deepcopy(self.c);old_r=deepcopy(self.rows)
        for row in old_c:row['unit_id']+='-rep1';row['replicate']=1
        for row in old_r:
            row['unit_id']+='-rep1'
            for seg in row['cost_segments']:seg['segment_id']+='-rep1'
        self.c+=old_c;self.rows+=old_r;self.raw=rebind(self.m,self.c);after=self.run_report()
        self.assertEqual(before['comparisons'],after['comparisons'])
        self.assertEqual(before['arms']['A']['task_clusters'],after['arms']['A']['task_clusters'])
        self.assertEqual(after['arms']['A']['assigned_units'],20)


if __name__=='__main__':unittest.main()
