#!/usr/bin/env python3
"""Generate explicitly synthetic accounting counterexamples; never agent results."""
from pathlib import Path
from hashlib import sha256
import json
from decimal import Decimal

ROOT=Path(__file__).resolve().parent/'fixtures'


def build(name: str, missing: bool = False) -> None:
    folder=ROOT/name; folder.mkdir(parents=True,exist_ok=True)
    cohort=[];results=[]
    for case in range(10):
        for arm in ('A','B','C'):
            unit=f'case-{case:02d}-{arm}'
            cohort.append({'unit_id':unit,'case_id':f'case-{case:02d}',
                'task_cluster':f'synthetic-cluster-{case:02d}','replicate':0,'assigned_arm':arm,
                'initial_state_ref':f'synthetic-start-{case:02d}','config_ref':f'fixture-config-{arm}'})
            outcome='success'
            if missing and case>=8:
                outcome='unknown' if arm=='B' else 'failure'
            results.append({'unit_id':unit,'execution_status':'completed','outcome':outcome,
                'acceptance_ref':None if outcome=='unknown' else f'synthetic-verifier:{unit}',
                'outcome_reason':'synthetic_missing_acceptance' if outcome=='unknown' else None,
                'cost_status':'complete','currency':'ILLUSTRATIVE_UNITS',
                'cost_segments':[{'segment_id':f'synthetic-cost:{unit}','kind':'illustrative_total',
                  'amount':{'A':'1','B':'1.4','C':'1.2'}[arm],
                  'evidence_ref':f'synthetic-price-not-bill:{unit}'}],
                'reconciliation_ref':f'synthetic-closed:{unit}'})
    raw=(json.dumps(cohort,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    (folder/'cohort.json').write_bytes(raw)
    manifest={'schema_version':'analysis-draft-0.3','experiment_id':f'synthetic-{name}',
        'data_origin':'synthetic','status':'draft','currency':'ILLUSTRATIVE_UNITS',
        'arms':['A','B','C'],'analysis_scope':'balanced_case_replicate',
        'cohort_sha256':sha256(raw).hexdigest(),'preregistration_ref':None,'freeze_ref':None,
        'notes':'Hand-authored arithmetic counterexample, not an experiment, model output, or invoice.'}
    (folder/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (folder/'results.jsonl').write_text(''.join(json.dumps(row,ensure_ascii=False)+'\n' for row in results),encoding='utf-8')


if __name__=='__main__':
    build('package_cost')
    build('missing_outcome',missing=True)
    print('Generated two SYNTHETIC accounting fixtures; no model or agent executed.')
