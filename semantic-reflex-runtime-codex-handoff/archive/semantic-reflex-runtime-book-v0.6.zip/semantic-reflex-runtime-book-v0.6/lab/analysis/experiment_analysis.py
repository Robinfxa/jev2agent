#!/usr/bin/env python3
"""Offline descriptive analysis for the v0.3 architecture draft.

Python 3.10+, standard library only. No host, model, current prices, network,
confidence intervals, authority verification, or automatic promotion.
This deliberately supports only balanced case/replicate A/B/C cohorts.
"""
from __future__ import annotations

import argparse
from collections import Counter
from decimal import Decimal, InvalidOperation, localcontext
from hashlib import sha256
import json
from pathlib import Path
import sys
from typing import Any


class AnalysisError(ValueError):
    """Malformed, incomplete, or incompatible analysis inputs."""


def check(ok: bool, message: str) -> None:
    if not ok:
        raise AnalysisError(message)


def text(value: Any, name: str) -> str:
    check(isinstance(value, str) and bool(value.strip()), f'{name}: expected nonempty string')
    return value


def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        check(key not in result, f'duplicate JSON key: {key}')
        result[key] = value
    return result


def reject_constant(value: str) -> None:
    raise AnalysisError(f'nonstandard JSON constant: {value}')


def parse_json(raw: str) -> Any:
    try:
        return json.loads(raw, object_pairs_hook=unique_object, parse_constant=reject_constant)
    except (json.JSONDecodeError, UnicodeError) as error:
        raise AnalysisError(f'invalid JSON: {error}') from error


def fields(obj: Any, required: set[str], optional: set[str], name: str) -> dict[str, Any]:
    check(isinstance(obj, dict), f'{name}: expected object')
    check(required <= set(obj), f'{name}: missing fields {sorted(required-set(obj))}')
    check(set(obj) <= required | optional, f'{name}: unknown fields {sorted(set(obj)-required-optional)}')
    return obj


def amount(value: Any) -> Decimal | None:
    if value is None:
        return None
    check(isinstance(value, str) and len(value) <= 100, 'amount must be a bounded decimal string or null')
    try:
        result = Decimal(value)
    except InvalidOperation as error:
        raise AnalysisError('bad decimal amount') from error
    check(result.is_finite() and result >= 0, 'amount must be finite and nonnegative')
    # The draft tool is not a currency engine; reject unreasonable precision/exponents.
    check(len(result.as_tuple().digits) <= 28 and -12 <= result.as_tuple().exponent <= 12,
          'amount precision outside descriptive tool limits')
    return result


def display(value: Decimal | None) -> str | None:
    if value is None:
        return None
    if value == 0:
        return '0'
    return format(value, 'f').rstrip('0').rstrip('.') if '.' in format(value, 'f') else format(value, 'f')


def validate_manifest(manifest: Any, cohort_bytes: bytes) -> dict[str, Any]:
    m = fields(manifest, {'schema_version','experiment_id','data_origin','status','currency',
                         'arms','analysis_scope','cohort_sha256','preregistration_ref','freeze_ref'},
               {'notes'}, 'manifest')
    check(m['schema_version'] == 'analysis-draft-0.3', 'unsupported analysis schema')
    text(m['experiment_id'], 'experiment_id'); text(m['currency'], 'currency')
    check(isinstance(m['data_origin'],str) and m['data_origin'] in {'synthetic','measured'}, 'invalid data origin')
    check(isinstance(m['status'],str) and m['status'] in {'draft','frozen'}, 'invalid manifest status')
    check(m['arms'] == ['A','B','C'], 'tool only supports A/B/C balanced design')
    check(m['analysis_scope'] == 'balanced_case_replicate', 'unsupported analysis scope')
    check(m['cohort_sha256'] == sha256(cohort_bytes).hexdigest(), 'cohort hash mismatch')
    for key in ('preregistration_ref','freeze_ref'):
        check(m[key] is None or isinstance(m[key],str), f'{key}: invalid type')
        if m['status'] == 'frozen':
            text(m[key], key)
    return m


def validate_cohort(cohort: Any) -> dict[str, dict[str, Any]]:
    check(isinstance(cohort,list) and len(cohort)>0, 'cohort must be nonempty list')
    index: dict[str, dict[str, Any]] = {}
    pairs: dict[tuple[str,int], set[str]] = {}
    case_metadata: dict[str, tuple[str,str]] = {}
    arm_configs: dict[str,str] = {}
    required={'unit_id','case_id','task_cluster','replicate','assigned_arm','initial_state_ref','config_ref'}
    for row in cohort:
        fields(row,required,set(),'cohort row')
        for key in required-{'replicate'}: text(row[key],key)
        check(type(row['replicate']) is int and row['replicate'] >= 0, 'replicate must be nonnegative integer')
        check(row['assigned_arm'] in {'A','B','C'}, 'invalid assigned arm')
        check(row['unit_id'] not in index, 'duplicate unit ID')
        key=(row['case_id'],row['replicate']); arm=row['assigned_arm']
        check(arm not in pairs.setdefault(key,set()), 'duplicate case/replicate/arm slot')
        pairs[key].add(arm)
        metadata=(row['task_cluster'],row['initial_state_ref'])
        check(case_metadata.setdefault(row['case_id'],metadata)==metadata,
              'case cluster or initial state mismatch')
        check(arm_configs.setdefault(arm,row['config_ref'])==row['config_ref'],
              'mixed config versions within arm; new experiment required')
        index[row['unit_id']]=row
    check(all(arms=={'A','B','C'} for arms in pairs.values()), 'unbalanced or missing paired arms')
    return index


def validate_results(rows: Any, roster: dict[str,dict[str,Any]], currency: str) -> dict[str,dict[str,Any]]:
    check(isinstance(rows,list),'results must be list')
    index: dict[str,dict[str,Any]]={}; segment_ids: set[str]=set()
    req={'unit_id','execution_status','outcome','acceptance_ref','outcome_reason',
         'cost_status','currency','cost_segments','reconciliation_ref'}
    for row in rows:
        fields(row,req,set(),'result row')
        unit=text(row['unit_id'],'unit_id')
        check(unit in roster,'result outside frozen cohort')
        check(unit not in index,'duplicate result for unit; aggregate retries inside the unit')
        check(isinstance(row['execution_status'],str) and row['execution_status'] in {'completed','aborted','not_started'},'invalid execution status')
        check(isinstance(row['outcome'],str) and row['outcome'] in {'success','failure','unknown'},'invalid outcome')
        check(row['acceptance_ref'] is None or isinstance(row['acceptance_ref'],str),'invalid acceptance reference')
        check(row['outcome_reason'] is None or isinstance(row['outcome_reason'],str),'invalid outcome reason')
        if row['outcome'] in {'success','failure'}:
            check(row['execution_status']=='completed','non-completed unit must retain unknown outcome')
            text(row['acceptance_ref'],'independent acceptance reference')
        else:
            text(row['outcome_reason'],'unknown outcome reason')
        check(isinstance(row['cost_status'],str) and row['cost_status'] in {'complete','incomplete'},'invalid cost status')
        check(row['currency']==currency,'mixed currency; no implicit conversion')
        check(isinstance(row['cost_segments'],list),'cost segments must be list')
        missing=0; subtotal=Decimal(0)
        for segment in row['cost_segments']:
            fields(segment,{'segment_id','kind','amount','evidence_ref'},set(),'cost segment')
            sid=text(segment['segment_id'],'segment_id')
            check(sid not in segment_ids,'duplicate cost segment across ledger')
            segment_ids.add(sid)
            text(segment['kind'],'cost kind')
            val=amount(segment['amount'])
            check(segment['evidence_ref'] is None or isinstance(segment['evidence_ref'],str),
                  'invalid cost evidence reference')
            if val is None:
                missing+=1
            else:
                text(segment['evidence_ref'],'known cost evidence reference')
                subtotal+=val
        if row['cost_status']=='complete':
            check(missing==0,'complete ledger contains missing cost')
            text(row['reconciliation_ref'],'cost closure reference')
        else:
            check(row['reconciliation_ref'] is None or isinstance(row['reconciliation_ref'],str),
                  'invalid reconciliation reference')
        index[unit]={**row,'_known_subtotal':subtotal,'_missing_segments':missing}
    check(set(index)==set(roster),f'missing planned results: {sorted(set(roster)-set(index))}')
    return index


def _analyze(manifest: dict[str,Any], cohort: Any, rows: Any, cohort_bytes: bytes) -> dict[str,Any]:
    m=validate_manifest(manifest,cohort_bytes)
    # Cross-check the supplied object against the exact bytes whose hash was frozen.
    check(parse_json(cohort_bytes.decode('utf-8'))==cohort,'cohort object/bytes mismatch')
    roster=validate_cohort(cohort)
    results=validate_results(rows,roster,m['currency'])
    summary: dict[str,dict[str,Any]]={}; numeric: dict[str,dict[str,Any]]={}
    for arm in m['arms']:
        ids=[uid for uid,entry in roster.items() if entry['assigned_arm']==arm]
        data=[results[uid] for uid in ids]; n=len(data)
        counts=Counter(row['outcome'] for row in data); statuses=Counter(row['execution_status'] for row in data)
        s=counts['success']; u=counts['unknown']; incomplete=sum(row['cost_status']!='complete' for row in data)
        partial=sum((row['_known_subtotal'] for row in data),Decimal(0))
        total=partial if incomplete==0 else None
        qlo=Decimal(s)/n; qhi=Decimal(s+u)/n
        k=total/s if total is not None and s else None
        klo=total/(s+u) if total is not None and s+u else None
        numeric[arm]={'qlo':qlo,'qhi':qhi,'k':k,'klo':klo,'khi':k}
        summary[arm]={
            'assigned_units':n,'task_clusters':len({roster[uid]['task_cluster'] for uid in ids}),
            'cases':len({roster[uid]['case_id'] for uid in ids}),
            'completed':statuses['completed'],'aborted':statuses['aborted'],'not_started':statuses['not_started'],
            'verified_success':s,'verified_failure':counts['failure'],'unknown_outcomes':u,
            'verified_success_fraction':display(qlo),
            'quality_missing_outcome_bounds':[display(qlo),display(qhi)],
            'incomplete_cost_units':incomplete,
            'missing_cost_segments':sum(row['_missing_segments'] for row in data),
            'known_cost_subtotal':display(partial),'total_cost':display(total),
            'cost_per_verified_success':display(k),
            'potential_success_cost_bounds':[display(klo),display(k)],
        }
    comparisons=[]
    for candidate,reference in [('B','A'),('C','B'),('C','A')]:
        c=numeric[candidate]; b=numeric[reference]
        gain=Decimal(1)-c['k']/b['k'] if c['k'] is not None and b['k'] is not None and b['k']>0 else None
        g_bounds=None
        if all(v is not None for v in [c['klo'],c['khi'],b['klo'],b['khi']]) and b['klo']>0:
            g_bounds=[display(Decimal(1)-c['khi']/b['klo']),display(Decimal(1)-c['klo']/b['khi'])]
        comparisons.append({'candidate':candidate,'reference':reference,
            'verified_success_difference':display(c['qlo']-b['qlo']),
            'quality_difference_missing_outcome_bounds':[display(c['qlo']-b['qhi']),display(c['qhi']-b['qlo'])],
            'cost_gain_using_verified_success':display(gain),
            'cost_gain_missing_outcome_bounds':g_bounds})
    blockers=['descriptive_only_no_sampling_intervals','real_E0_not_checked',
              'authority_and_evidence_refs_not_verified','latency_hard_incidents_and_maintenance_not_analyzed',
              'no_automatic_promotion']
    if m['data_origin']=='synthetic':blockers.append('synthetic_data_not_effect_evidence')
    if m['status']!='frozen':blockers.append('manifest_not_frozen')
    if any(a['unknown_outcomes'] for a in summary.values()):blockers.append('outcomes_missing')
    if any(a['incomplete_cost_units'] for a in summary.values()):blockers.append('costs_not_closed')
    return {'schema_version':'analysis-report-draft-0.3','experiment_id':m['experiment_id'],
            'data_origin':m['data_origin'],'manifest_status':m['status'],'currency':m['currency'],
            'scope':'balanced case/replicate, equal unit weight, descriptive finite sample only',
            'input_integrity':'passed_local_contract_checks',
            'arms':summary,'comparisons':comparisons,
            'missing_bounds_are_confidence_intervals':False,
            'promotion_eligible':False,'limitations_and_blockers':blockers}


def analyze(manifest: dict[str,Any],cohort: Any,rows: Any,cohort_bytes: bytes) -> dict[str,Any]:
    # Currency arithmetic is decimal; this precision is sufficient for allowed fixture inputs.
    with localcontext() as context:
        context.prec=64
        return _analyze(manifest,cohort,rows,cohort_bytes)


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--cohort',type=Path,required=True)
    parser.add_argument('--results',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    try:
        check(args.output.resolve() not in {args.manifest.resolve(),args.cohort.resolve(),args.results.resolve()},
              'output must not overwrite an input')
        cohort_bytes=args.cohort.read_bytes()
        manifest=parse_json(args.manifest.read_text(encoding='utf-8'))
        cohort=parse_json(cohort_bytes.decode('utf-8'))
        raw_results=args.results.read_text(encoding='utf-8')
        rows=[]
        for number,line in enumerate(raw_results.splitlines(),1):
            if not line.strip():continue
            try:rows.append(parse_json(line))
            except AnalysisError as error:raise AnalysisError(f'results line {number}: {error}') from error
        report=analyze(manifest,cohort,rows,cohort_bytes)
        report['input_hashes']={name:sha256(path.read_bytes()).hexdigest() for name,path in
                                [('manifest',args.manifest),('cohort',args.cohort),('results',args.results)]}
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
        print(f'Descriptive report written: {args.output}; promotion_eligible=false')
        return 0
    except (AnalysisError,OSError,UnicodeError) as error:
        print(f'Analysis refused: {error}',file=sys.stderr)
        return 2


if __name__=='__main__':
    raise SystemExit(main())
