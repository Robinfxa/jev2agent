#!/usr/bin/env python3
"""Validate and compile the local draft. No external retrieval.

Use --export to also write the standalone Markdown and ZIP beside the project.
Reference copies are intentionally partial; their internal dependencies are not checked.
"""
from __future__ import annotations
import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
from urllib.parse import unquote, urlsplit
import zipfile

ROOT=Path(__file__).resolve().parents[1]
VERSION='0.6'
DATE='2026-09-18'
LINK=re.compile(r'(?<!!)\[([^\]\n]+)\]\(([^)\n]+)\)')


def own_documents() -> list[Path]:
    return sorted(p for p in ROOT.rglob('*.md')
                  if 'references' not in p.relative_to(ROOT).parts and
                  'corpus' not in p.relative_to(ROOT).parts and p.name!='BOOK.md')


def local_target(source: Path, raw: str) -> tuple[Path | None,str]:
    raw=raw.strip()
    # Our authored targets use no optional link titles; retain external URLs unchanged.
    if raw.startswith(('#','http://','https://','mailto:','sandbox:','data:')):
        return None,raw
    parts=urlsplit(raw)
    return (source.parent/unquote(parts.path)).resolve(),parts.fragment


def check_documents() -> dict:
    errors=[];links=0;tables=0;docs=own_documents()
    for p in docs:
        text=p.read_text(encoding='utf-8')
        fence=False;expected=None;numbered=[]
        for number,line in enumerate(text.splitlines(),1):
            if line.lstrip().startswith('```'):
                fence=not fence;expected=None;continue
            if fence:continue
            for match in LINK.finditer(line):
                try:target,_=local_target(p,match.group(2))
                except ValueError as error:
                    errors.append(f'{p.relative_to(ROOT)}:{number}: invalid link: {error}');continue
                if target is not None:
                    links+=1
                    if not target.exists():errors.append(f'{p.relative_to(ROOT)}:{number}: missing {match.group(2)}')
            if line.startswith('|'):
                cells=len(re.findall(r'(?<!\\)\|',line))-1
                if expected is None:expected=cells;tables+=1
                elif cells!=expected:errors.append(f'{p.relative_to(ROOT)}:{number}: table {cells} vs {expected} columns')
            else:expected=None
            heading=re.match(r'^## (\d+)\.',line)
            if heading:numbered.append(heading.group(1))
        if fence:errors.append(f'{p.relative_to(ROOT)}: unclosed code fence')
        if p.parent.name=='modules' and len(numbered)!=len(set(numbered)):
            errors.append(f'{p.relative_to(ROOT)}: duplicate numeric section')
    return {'project_markdown_files_checked':len(docs),'relative_link_targets_checked':links,
            'tables_checked':tables,'errors':errors}


def parts() -> list[Path]:
    rels=['CURRENT.md','CHANGELOG.md','docs/architecture/00-master-design-book.md',
          'docs/research/2026-09-18-offline-bull-bear-round-6.md']
    rels += [str(p.relative_to(ROOT)) for p in sorted((ROOT/'docs/architecture/modules').glob('*.md'))]
    rels += ['docs/experiments/E0-integration-contract.md',
             'docs/experiments/E1-cost-and-coverage.md',
             'docs/experiments/E2-deterministic-baseline.md',
             'docs/experiments/E2-recovery-protocols.md',
             'docs/experiments/E2-local-walkthrough.md',
             'docs/experiments/E3-semantic-shadow.md',
             'docs/experiments/E3-discovery-counterexamples.md',
             'docs/experiments/E4-pre-registration.md',
             'docs/experiments/E4-cohort-and-analysis.md',
             'docs/experiments/diagnostic-cases.md']
    rels += [str(p.relative_to(ROOT)) for p in sorted((ROOT/'docs/architecture/appendices').glob('*.md'))]
    rels += ['docs/plans/implementation-handoff-v0.6.md',
             'lab/discovery/README.md','lab/discovery/diagnostics/REPORT.md',
             'docs/plans/implementation-handoff-v0.5.md',
             'lab/recovery/README.md','lab/recovery/diagnostics/REPORT.md',
             'docs/plans/implementation-handoff-v0.4.md',
             'lab/baseline/README.md', 'lab/baseline/diagnostics/REPORT.md',
             'docs/plans/2026-09-18-architecture-book.md','lab/analysis/README.md',
             'lab/README.md','examples/README.md','VALIDATION.md',
             'docs/research/2026-09-18-offline-bull-bear-round-5.md',
             'docs/research/2026-09-18-offline-bull-bear-round-4.md',
             'docs/research/2026-09-18-offline-bull-bear-round-3.md',
             'docs/plans/implementation-handoff-v0.3.md',
             'docs/research/2026-09-18-offline-bull-bear-round-2.md',
             'docs/research/2026-09-18-offline-bull-bear.md']
    return [ROOT/rel for rel in rels]


def compile_book(export_prefix: str='') -> tuple[str,int]:
    paths=parts();anchors={p.resolve():f'book-part-{i:02d}' for i,p in enumerate(paths,1)}
    titles={p:re.search(r'^# (.+)$',p.read_text(),re.M).group(1) for p in paths}
    header=f'''# Semantic Reflex Runtime｜架构书 v0.6：需求发现与验收隔离

> {DATE}｜Draft｜继承书稿＋本轮手写反例的本地执行；没有网页研究、真实宿主、agent 或语义模型实验。

本轮不再优化恢复微格式，增加四个行为族的相同观察／证据位置诊断。13 对／26 个构造世界，52 份不同候选×世界检查记录；32 项新有限检查、158 份同输入重跑文件一致。读取路径由脚本指定，不证明自然需求发现。

首发仍为一种只读搜索结果 ADMIT＋原文 recall。区分捕获外缺口、候选内选择与任务结果；保护 H 不由隐藏答案补写；接收方、selector、来源服务与验收输入分流。旧 37/40/42/71/11 检查分别回归，数量不转换为生产可靠性。

本轮相同观察采用诊断会话别名和有限候选菜单，不是 v0.5 wire hash 碰撞，也不是所有程序的不可能性。所有反例已公开，只能作开发材料，不能冒充留出。DEC01–DEC42 Proposed，E0–E5 未晋升。

正文链接跳转本册章节；源码与原始记录使用相邻的 `semantic-reflex-runtime-book-v0.6` 解压目录。当前快照在前，历史论证在后。

## 本册目录

'''
    header+='\n'.join(f'{i}. [{titles[p]}](#{anchors[p.resolve()]})' for i,p in enumerate(paths,1))+'\n'
    chunks=[header]
    for p in paths:
        text=p.read_text(encoding='utf-8')
        def sub(match):
            label,raw=match.group(1),match.group(2)
            target,fragment=local_target(p,raw)
            if target is None:return match.group(0)
            if target in anchors:return f'[{label}](#{anchors[target]})'
            try:relative=target.relative_to(ROOT).as_posix()
            except ValueError:raise ValueError(f'outside package local target {target}')
            suffix=('#'+fragment) if fragment else ''
            return f'[{label}]({export_prefix}{relative}{suffix})'
        text=LINK.sub(sub,text)
        chunks.append(f'\n\n---\n\n<a id="{anchors[p.resolve()]}"></a>\n\n'+text.rstrip()+'\n')
    return ''.join(chunks),len(paths)


def validate_compilation(text: str) -> None:
    anchors=set(re.findall(r'<a id="([^"]+)"></a>',text))
    for target in re.findall(r'\]\(#(book-part-\d+)\)',text):
        if target not in anchors:raise ValueError(f'broken book anchor {target}')


def package_files() -> list[Path]:
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and
                  '__pycache__' not in p.parts and p.suffix!='.pyc')


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--export',action='store_true')
    args=parser.parse_args()
    # Create targets before validation so links to build artifacts resolve.
    (ROOT/'BUILD_REPORT.json').write_text('{}\n',encoding='utf-8')
    book,count=compile_book();validate_compilation(book)
    (ROOT/'BOOK.md').write_text(book,encoding='utf-8')
    doccheck=check_documents()
    if doccheck['errors']:
        print('\n'.join(doccheck['errors']));return 1
    manifest=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())
    for item in manifest['sources']:
        raw=(ROOT/item['path']).read_bytes()
        if len(raw)!=item['bytes'] or sha256(raw).hexdigest()!=item['sha256']:
            raise ValueError(f'reference changed: {item["path"]}')
    json_files=list(ROOT.rglob('*.json'))
    for p in json_files:json.loads(p.read_text())
    jsonl_rows=0
    for p in ROOT.rglob('*.jsonl'):
        for line in p.read_text().splitlines():
            if line.strip():json.loads(line);jsonl_rows+=1
    corpus_manifest=json.loads((ROOT/'lab/baseline/corpus/CORPUS_MANIFEST.json').read_text())
    for item in corpus_manifest['files']:
        data=(ROOT/'lab/baseline/corpus'/item['file']).read_bytes()
        if len(data)!=item['bytes'] or sha256(data).hexdigest()!=item['sha256']:
            raise ValueError('diagnostic corpus changed: '+item['file'])
    baseline=json.loads((ROOT/'lab/baseline/check-results.json').read_text())
    diagnostics=json.loads((ROOT/'lab/baseline/diagnostics/report.json').read_text())
    reproducibility=json.loads((ROOT/'lab/baseline/reproducibility.json').read_text())
    if not baseline['successful'] or not reproducibility['identical']:
        raise ValueError('baseline checks/reproduction failed')
    analysis=json.loads((ROOT/'lab/analysis/check-results.json').read_text())
    legacy=json.loads((ROOT/'lab/check-results.json').read_text())
    if not analysis['successful'] or not legacy['successful']:raise ValueError('check results not successful')
    if 'Total: 11 constructed checks passed.' not in (ROOT/'examples/check-results.txt').read_text():
        raise ValueError('legacy example output not found')
    recovery=json.loads((ROOT/'lab/recovery/check-results.json').read_text())
    recovery_data=json.loads((ROOT/'lab/recovery/diagnostics/report.json').read_text())
    recovery_repeat=json.loads((ROOT/'lab/recovery/reproducibility.json').read_text())
    inherited=json.loads((ROOT/'lab/recovery/input-provenance.json').read_text())
    if not recovery['successful'] or not recovery_repeat['identical']:
        raise ValueError('recovery checks/reproduction failed')
    for item in inherited['files']:
        raw=(ROOT/item['path']).read_bytes()
        if len(raw)!=item['bytes'] or sha256(raw).hexdigest()!=item['sha256']:
            raise ValueError('inherited input or baseline code changed: '+item['path'])
    for entry in recovery_data['input_views']:
        for name,expected in entry['files'].items():
            if sha256((ROOT/entry['bundle']/name).read_bytes()).hexdigest()!=expected:
                raise ValueError('fixed diagnostic bundle changed')
    # Reconcile actual JSONL byte counts to every diagnostic row, including none.
    for row in recovery_data['cases']:
        trace_path=ROOT/'lab/recovery/diagnostics'/row['trace_path']
        trace=[json.loads(x) for x in trace_path.read_text().splitlines() if x.strip()]
        local_wire=lambda x: (json.dumps(x,ensure_ascii=False,sort_keys=True,
                             separators=(',',':'),allow_nan=False)+'\n').encode('utf-8')
        for t in trace:
            if len(local_wire(t['request']))!=t['request_bytes']:
                raise ValueError('request count mismatch')
            measured=len(local_wire(t['response'])) if t['response'] is not None else 0
            if measured!=t['response_bytes']:raise ValueError('response count mismatch')
        if sum(t['request_bytes'] for t in trace)!=row['request_bytes'] or \
           sum(t['response_bytes'] for t in trace)!=row['recall_response_bytes']:
            raise ValueError('diagnostic ledger mismatch')
        if row['task_outcome'] is not None or row['billable_cost'] is not None:
            raise ValueError('protocol diagnostic contains task/fee claim')
    # v0.6 authored discovery evidence: verify actual outputs, not modeled success.
    discovery=json.loads((ROOT/'lab/discovery/check-results.json').read_text())
    discovery_report=json.loads((ROOT/'lab/discovery/diagnostics/report.json').read_text())
    discovery_repeat=json.loads((ROOT/'lab/discovery/reproducibility.json').read_text())
    inherited_v06=json.loads((ROOT/'lab/discovery/inherited-inputs.json').read_text())
    regressions_v06=json.loads((ROOT/'lab/discovery/regression-results.json').read_text())
    if not discovery['successful'] or not discovery_repeat['identical'] or not regressions_v06['all_passed']:
        raise ValueError('v0.6 checks not passed')
    if discovery_report['model_calls']!=0 or discovery_report['natural_demand_discovery'] is not None:
        raise ValueError('finite diagnostic must not contain agent effect claim')
    for item in inherited_v06['files']:
        raw=(ROOT/item['path']).read_bytes()
        if len(raw)!=item['bytes'] or sha256(raw).hexdigest()!=item['sha256']:
            raise ValueError('v0.6 inherited input changed: '+item['path'])
    for item in discovery_repeat['files']:
        raw=(ROOT/'lab/discovery/diagnostics'/item['path']).read_bytes()
        if len(raw)!=item['bytes'] or sha256(raw).hexdigest()!=item['sha256']:
            raise ValueError('v0.6 diagnostic changed after reproduction: '+item['path'])
    standalone,_=compile_book(export_prefix=ROOT.name+'/');validate_compilation(standalone)
    report={'version':VERSION,'date':DATE,'status':'draft',
            'new_discovery_tests':discovery,
            'discovery_pairs':discovery_report['pairs'], 'discovery_worlds':discovery_report['worlds'],
            'finite_candidate_world_records':discovery_report['candidate_world_records'],
            'discovery_reproducible_files':discovery_repeat['file_count'],
            'inherited_v05_files_verified':inherited_v06['file_count'],
            'legacy_recovery_tests':recovery, 'recovery_diagnostic_cases':recovery_data['case_count'],
            'recovery_diagnostic_reproducibility':recovery_repeat,
            'unchanged_inherited_input_files_verified':inherited['file_count'],
            'legacy_baseline_tests':baseline, 'historical_diagnostic_cases':diagnostics['case_count'],
            'selected_local_views':sum(row['route']=='PREPARE_SELECTED_LOCAL' for row in diagnostics['cases']),
            'diagnostic_reproducibility':reproducibility,
            'legacy_analysis_tests':analysis,'legacy_finite_model_tests':legacy,
            'legacy_constructed_checks':11,
            'unchanged_reference_files_verified':len(manifest['sources']),
            'frozen_corpus_files_verified':len(corpus_manifest['files']),
            **{k:v for k,v in doccheck.items() if k!='errors'},'relative_link_errors':0,
            'compiled_parts':count,'compiled_anchor_errors':0,
            'json_files_parsed':len(json_files),'jsonl_rows_parsed':jsonl_rows,
            'compiled_book_bytes':len(book.encode()),'standalone_book_bytes':len(standalone.encode()),
            'reference_internal_dependencies_checked':False,
            'stage_claim':'authored W0 counterexamples and prior local W3 candidates only; real E0-E5 not passed',
            'not_claimed':['real_semantic_effect','actual_billing','sampling_intervals',
                           'real_authorization','production_readiness']}
    (ROOT/'BUILD_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    files=[p for p in package_files() if p.name!='SHA256SUMS.txt']
    (ROOT/'SHA256SUMS.txt').write_text(''.join(f'{sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}\n' for p in files))
    if args.export:
        standalone_path=ROOT.parent/f'semantic-reflex-runtime-architecture-book-v{VERSION}.md'
        standalone_path.write_text(standalone,encoding='utf-8')
        zpath=ROOT.parent/f'semantic-reflex-runtime-book-v{VERSION}.zip'
        with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for p in package_files():z.write(p,arcname=ROOT.name+'/'+p.relative_to(ROOT).as_posix())
        with zipfile.ZipFile(zpath) as z:
            bad=z.testzip()
            if bad:raise ValueError(f'bad zip entry {bad}')
        print(f'Exported {standalone_path.name} and {zpath.name}; ZIP integrity passed')
    print(json.dumps({k:v for k,v in report.items() if k not in {'new_discovery_tests','legacy_recovery_tests','legacy_baseline_tests','legacy_analysis_tests','legacy_finite_model_tests'}},ensure_ascii=False,indent=2))
    return 0


if __name__=='__main__':raise SystemExit(main())
